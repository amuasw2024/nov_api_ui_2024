package nbcu.automation.ui.stepdefs.ncxUnifiedTool;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.ncxUnifiedTool.EditRequestFormPage;
import nbcu.automation.ui.pages.ncxUnifiedTool.EditSelfReportingRequestFormPage;
import nbcu.automation.ui.pages.ncxUnifiedTool.ProducerDashboardGeneralPage;
import nbcu.framework.utils.cucumber.CucumberUtils;

public class EditSelfReportingRequestFormPageSteps {

	EditRequestFormPage editRequestFormPage = new EditRequestFormPage();
	EditSelfReportingRequestFormPage editSelfReportingRequestFormPage = new EditSelfReportingRequestFormPage();

	@When("user enters General info in Edit Self Reporting request form")
	public void fillShowInfoInEditSelfReporting(DataTable dataTable) throws Exception {
		editRequestFormPage.addShowInfoInECM(CucumberUtils.getValuesFromDataTable(dataTable, "Show Unit"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Budget Code"));
	}

	@When("user enters Show info in Edit Self Reporting request form")
	public void fillShowInfoInLongEdit(DataTable dataTable) throws Exception {
		editSelfReportingRequestFormPage.addAirDateTimeInfoInESR(
				CucumberUtils.getValuesFromDataTable(dataTable, "Air Date"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Edit Date"));
	}

	@When("user enters Edit Type info in Edit Self Reporting request form")
	public void fillShowLengthSectionInStandardEdit(DataTable dataTable) throws Exception {
		editSelfReportingRequestFormPage
				.selectWhoIsEditing(CucumberUtils.getValuesFromDataTable(dataTable, "Who Is Editing"));
		editRequestFormPage.fillTypeOfEditDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Type of Edit"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Type of Edit Quantity"));
	}

	@When("user enters Location info in Edit Self Reporting request form")
	public void fillShowLengthSectionInEditSelfReporting(DataTable dataTable) throws Exception {
		editSelfReportingRequestFormPage.fillLocationInfoInESR(
				CucumberUtils.getValuesFromDataTable(dataTable, "Location"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Room"));
	}

	@When("user enters comments info in Edit Self Reporting request form")
	public void fillCommentsSection(DataTable dataTable) throws Exception {
		editSelfReportingRequestFormPage
				.fillCommentInEditSelfReporting(CucumberUtils.getValuesFromDataTable(dataTable, "Comments"));
	}
	
	@Then("user get the Edit Self Reporting Request ID with Request Type from Success message")
	public void getRequestIDFromSuccessMessage() throws Exception {
		editSelfReportingRequestFormPage.getRequestID();
	}
}