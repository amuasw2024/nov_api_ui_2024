
package nbcu.automation.ui.pages.ncxUnifiedTool;

import java.lang.reflect.Array;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import nbcu.automation.ui.constants.ncxUnifiedTool.Constants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.Other.DateFunctions;
import nbcu.framework.utils.ui.Waits;
import nbcu.framework.utils.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.utils.ui.WebAction;

public class EditRequestFormPage {

	String editType = "//*[@forminputname='editType']//span[contains(text(),'<<editTypeName>>')]";

	String showTitleString = "(//input[@placeholder='Show Unit or Project Name'])[<<showUnitNo>>]";

	String budgetCodeTitleString = "(//input[@placeholder='Search Budget Code'])[<<budgetCodeNo>>]";

	@FindBy(xpath = "//*[text()=' Show Unit ']")
	WebElement showTitleAddButton;

	@FindBy(xpath = "//*[@role='menuitem']/div")
	List<WebElement> SearchList;

	String dropDownvaluesXpath = "//div[@class='cdk-virtual-scroll-content-wrapper']/nz-option-item";

	@FindBy(xpath = "//div[@class='cdk-virtual-scroll-content-wrapper']/nz-option-item | //nz-option-item ")
	List<WebElement> dropDownvalues;

	@FindBy(xpath = "//*[@forminputname='airDate']//input")
	WebElement airDate;

	@FindBy(xpath = "//*[@formcontrolname='airDateTBD']//input")
	WebElement airDateTBDCheckBox;

	@FindBy(xpath = "//*[@forminputname='airTime']//input")
	WebElement airTime;

	@FindBy(xpath = "//*[@formcontrolname='airTimeFlexible']//input")
	WebElement airTimeFlexibleCheckBox;

	@FindBy(xpath = "//*[@forminputname='dateOfFirstScreening']//input")
	WebElement dateOfFirstScreening;

	@FindBy(xpath = "//*[@forminputname='pieceVersions']//input")
	WebElement lengthOfShowPieceNoOfActs;

	@FindBy(xpath = "//*[@forminputname='pieceHours']//input")
	WebElement lengthOfShowPieceHours;

	@FindBy(xpath = "//*[@forminputname='pieceMinutes']//input")
	WebElement lengthOfShowPieceMinutes;

	@FindBy(xpath = "//*[@forminputname='pieceSeconds']//input")
	WebElement lengthOfShowPieceSeconds;

	@FindBy(xpath = "//*[@forminputname='locationofEdit']//input")
	WebElement locationofEdit;

	String ediusOrAvid = "//*[@forminputname='ediusOrAvid']//label[@label-value='<<ediusOrAvidName>>']";

	@FindBy(xpath = "//*[@forminputname='editStartDate']//input")
	WebElement editStartDate;

	@FindBy(xpath = "//*[@forminputname='requestedEditSection']//input")
	WebElement reqStartTime;

	@FindBy(xpath = "//*[@forminputname='numberOfEditors']//input")
	WebElement noOfEditors;

	@FindBy(xpath = "//*[@forminputname='craftEditWeeks']//input")
	WebElement editTimeNeededWeeks;

	@FindBy(xpath = "//*[@forminputname='craftEditDays']//input")
	WebElement editTimeNeededDays;

	@FindBy(xpath = "//*[@forminputname='craftEditHours']//input")
	WebElement editTimeNeededHours;

	@FindBy(xpath = "//*[@forminputname='craftEditMinutes']//input")
	WebElement editTimeNeededMinutes;

	@FindBy(xpath = "//*[@formcontrolname='craftTimeFlexible']//input")
	WebElement editTimeNeededFlexible;

	@FindBy(xpath = "//*[contains(text(),'Type of Edit')]/parent::button | //*[contains(text(),'Type')]/parent::button")
	WebElement typeOfEditAddButton;

	String typeOfEdit = "(//*[@placeholder='Select Type of Edits']//input)[<<typeOfEditNo>>]";

	String typeOfEditQuantity = "(//*[@label='Quantity']//input)[<<typeOfEditQuantityNo>>]";

	@FindBy(xpath = "//input[@placeholder='Enter Other' or @placeholder='Other type of edit']")
	WebElement typeOfEditXpathOtherInputBox;

	@FindBy(xpath = "//*[@forminputname='pieceVersions']//input")
	WebElement howManyVersions;

	String additionalRequirements = "//*[@forminputname='addionalRequirement']//span[text()='<<AdditionalRequirementsName>>']/ancestor::div[1]//input[@type='checkbox']";

	@FindBy(xpath = "//*[@forminputname='arOtherText']//input")
	WebElement additionalRequirementsOtherText;

	String finalDelivery = "//*[@forminputname='finalDelivery']//span[text()='<<finalDeliveryName>>']/ancestor::div[1]//input[@type='checkbox']";

	@FindBy(xpath = "//*[@forminputname='fdOtherText']//input")
	WebElement finalDeliveryOtherText;

	String sourceMaterial = "//*[@forminputname='sourceMaterial']//span[text()='<<SourceMaterialName>>']/ancestor::div[1]//input[@type='checkbox']";

	@FindBy(xpath = "//*[@forminputname='sourceMaterialOther']//input")
	WebElement sourceMaterialOtherText;

	@FindBy(xpath = "//label[contains(text(),'Crash Edit Needed')]/ancestor::div[2]//input[@type='checkbox']")
	WebElement isCrashEdit_Yes;

	@FindBy(xpath = "//*[@forminputname='lfComments' or @forminputname='craftEditComments']//textarea")
	WebElement commentTextArea;

	@FindBy(xpath = "//*[contains(text(),'Req same as Assistant Producer')]//ancestor::div[2]//input[@type='checkbox']")
	WebElement asstProducerSameasRequestor_Options;

	@FindBy(xpath = "//*[@label='Assistant Producer']//input")
	WebElement asstProducerSameAsRequestInputBox;

	@FindBy(xpath = "//*[contains(text(),'Additional Recipient')]")
	WebElement addRecipientButton;

	String additionalRecipientsInputBox = "(//*[@placeholder='Enter Recipient Email' or @placeholder='Enter Additional Reciptant']//input)[<<additionalRecipientsInputBoxNo>>]";

	@FindBy(xpath = "//*[@forminputname='fIStatus' or @forminputname='feedOutStatus' or @forminputname='erRequestStatus' or @forminputname='fulFillerStatus']//input")
	WebElement requestStatusDropDown;

	@FindBy(xpath = "//label[contains(text(),'FULFILLMENT COMMENTS')]//ancestor::div[1]//span[contains(text(),'ADD')]")
	WebElement fulfillmentCommentAddButton;

	@FindBy(xpath = "//label[contains(text(),'FULFILLMENT COMMENTS')]//ancestor::div[1]//textarea")
	WebElement fulfillmentCommentTextArea;

	@FindBy(xpath = "//*[@label='Editor Information']//input[@placeholder='Search for Editor']")
	public WebElement editorNameTextbox;

	@FindBy(xpath = "//*[@label='Editor Information']//parent::div//*[@forminputname='phoneNumber']//input")
	public WebElement editorPhoneNumberTextbox;

	@FindBy(xpath = "//*[@label='Room']//input")
	public WebElement editorSearchRoomTextbox;

	@FindBy(xpath = "//*[@formcontrolname='sessionAssignedFromDateToDate']//input[@placeholder='Start date']")
	WebElement sessionEditorStartDate;

	@FindBy(xpath = "//*[@formcontrolname='sessionAssignedFromDateToDate']//input[@placeholder='End date']")
	WebElement sessionEditorEndDate;

	@FindBy(xpath = "//*[@forminputname='sessionAssignedFromTime']//input[@placeholder='Select time']")
	WebElement sessionEditorStartTime;

	@FindBy(xpath = "//*[@forminputname='sessionAssignedToTime']//input[@placeholder='Select time']")
	WebElement sessionEditorEndTime;

	@FindBy(xpath = "//label[@formcontrolname='differentRoom']//input")
	public WebElement editorDifferentRoomCheckbox;

	@FindBy(xpath = "//label[@formcontrolname='differentRoom']//ancestor::div[3]//*[@label='Room']//input")
	public WebElement editorDifferentSearchRoomTextbox;

	@FindBy(xpath = "//label[contains(text(),'EDITOR CONTROLS')]//ancestor::div[1]//span[contains(text(),'Editor')]")
	public WebElement addEditorButton;

	public EditRequestFormPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To fill edit Type
	 * 
	 * @throws Exception
	 */
	public void selectEditType(String editTypeText) throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			String selectEditTypeButtonXpath = "";
			switch (editTypeText.toUpperCase()) {
			case "STANDARD":
				selectEditTypeButtonXpath = editType.replace("<<editTypeName>>", "Standard");
				break;
			case "LONG FORM":
				selectEditTypeButtonXpath = editType.replace("<<editTypeName>>", "Long");
				break;
			}
			WebAction.click(driver.findElement(By.xpath(selectEditTypeButtonXpath)));

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void addShowInfoInECM(String showTitleText, String budgetCodeText) throws Exception {
		try {
			WebDriver driver = DriverFactory.getCurrentDriver();
			// To select show unit
			if (showTitleText != null) {
				String showTitleTextArrayList[] = showTitleText.split(",");
				for (int i = 0; i < showTitleTextArrayList.length; i++) {
					String showTitleXpath = showTitleString.replace("<<showUnitNo>>", Integer.toString(i + 1));
					WebElement showTitle = driver.findElement(By.xpath(showTitleXpath));
					Waits.waitForElement(showTitle, WAIT_CONDITIONS.CLICKABLE);
					WebAction.sendKeys(showTitle, showTitleTextArrayList[i].trim());
					Waits.waitUntilElementSizeGreater(SearchList, 0);
					Thread.sleep(1000);
					WebAction.click(SearchList.get(0));
					Thread.sleep(1000);
					if (i < (showTitleTextArrayList.length - 1)) {
						Waits.waitForElement(showTitleAddButton, WAIT_CONDITIONS.CLICKABLE);
						WebAction.click(showTitleAddButton);
					}
				}
			} else if (budgetCodeText != null) {
				String[] budgetCodeTextArrayList = budgetCodeText.split(",");
				for (int i = 0; i < budgetCodeTextArrayList.length; i++) {
					String budgetCodeTitleXpath = budgetCodeTitleString.replace("<<budgetCodeNo>>",
							Integer.toString(i + 1));
					WebElement budgetCode = driver.findElement(By.xpath(budgetCodeTitleXpath));
					Waits.waitForElement(budgetCode, WAIT_CONDITIONS.CLICKABLE);
					WebAction.sendKeys(budgetCode, budgetCodeTextArrayList[i].trim());
					Waits.waitUntilElementSizeGreater(SearchList, 0);
					Thread.sleep(1000);
					WebAction.click(SearchList.get(0));
					Thread.sleep(1000);
					if (i < (budgetCodeTextArrayList.length - 1)) {
						Waits.waitForElement(showTitleAddButton, WAIT_CONDITIONS.CLICKABLE);
						WebAction.click(showTitleAddButton);
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To generate date based on input. Date should like CurrebDate+1,
	 * CurrentDate-2, etc.,
	 * 
	 * @param date   - date
	 * @param format - date format
	 * @throws Exception
	 */
	public String generateDate(String date, String format) throws Exception {
		String updateddate = "";
		try {
			if (date.trim() != null) {
				if (date.toUpperCase().contains("CURRENTDATE")) {
					String days = date.replaceAll("[a-zA-Z]", "").trim();
					if (days.length() == 0) {
						days = "0";
					}
					updateddate = DateFunctions.addOrMinusDateFromCurrentDate(format, days);
				} else
					throw new Exception("Please provide date in valid format");
			} else
				throw new Exception("Date is empty");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return updateddate;
	}

	/**
	 * To generate time based on input. Time should like CurrentTime+1,
	 * CurrentTime-2, etc.,
	 * 
	 * @param time   - time
	 * @param format - time format
	 * @return
	 * @throws Exception
	 */
	public String generateTime(String time, String format) throws Exception {
		String updatedTime = "";
		try {
			if (time.trim() != null) {
				if (time.toUpperCase().contains("CURRENTTIME")) {
					String hours = time.replaceAll("[a-zA-Z]", "").trim();
					if (hours.length() == 0) {
						hours = "0";
					}
					updatedTime = DateFunctions.addOrMinusTimeFromCurrentTime(format, hours);
				} else
					updatedTime = time;
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return updatedTime;
	}

	public int daysBetween(Date d1, Date d2) {
		return (int) ((d2.getTime() - d1.getTime()) / (1000 * 60 * 60 * 24));
	}

	/**
	 * To fill Air date & Time in general details section
	 * 
	 * @param commentText - slug for this form
	 * @throws Exception
	 */

	public void addAirDateTimeInfo(String airDateText, String airTimeText) throws Exception {

		try {
			// WebAction.scrollIntoView(airDate);
			// To fill air Date
			if (airDateText != null) {
				// WebAction.click(dates.get(0));
				WebAction.click(airDate);
				WebAction.sendKeys(airDate, generateDate(airDateText, "MM-dd-yyyy"));
				WebAction.keyPress(airDate, "Enter");
			} else {
				WebAction.clickUsingJs(airDateTBDCheckBox);
			}

			// To fill air time
			if (airTimeText != null) {
				WebAction.click(airTime);
				WebAction.sendKeys(airTime, generateTime(airTimeText, "hh:mm a"));
			} else {
				WebAction.clickUsingJs(airTimeFlexibleCheckBox);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}

	public void fillDateofFirstScreening(String dateofFirstScreeningText) throws Exception {
		// To fill date of First Screening
		if (dateofFirstScreeningText != null) {
			WebAction.click(dateOfFirstScreening);
			WebAction.sendKeys(dateOfFirstScreening, generateDate(dateofFirstScreeningText, "MM/dd/yyyy"));
			WebAction.keyPress(dateOfFirstScreening, "Enter");
		}
	}

	public void filllengthOfShowInfoNoOfActs(String lengthOfShowNoOfActsText) throws Exception {
		// To fill length of show
		if (lengthOfShowNoOfActsText != null) {
			WebAction.sendKeys(lengthOfShowPieceNoOfActs, lengthOfShowNoOfActsText);
		}
	}

	public void filllengthOfShowInfoHours(String lengthOfShowHoursText) throws Exception {
		// To fill length of show
		if (lengthOfShowHoursText != null) {
			WebAction.sendKeys(lengthOfShowPieceHours, lengthOfShowHoursText);
		}
	}

	public void filllengthOfShowInfoMinutes(String lengthOfShowMinutesText) throws Exception {
		// To fill length of show
		if (lengthOfShowMinutesText != null) {
			WebAction.sendKeys(lengthOfShowPieceMinutes, lengthOfShowMinutesText);
		}
	}

	public void filllengthOfShowInfoSeconds(String lengthOfShowSecondsText) throws Exception {
		// To fill length of show
		if (lengthOfShowSecondsText != null) {
			WebAction.sendKeys(lengthOfShowPieceSeconds, lengthOfShowSecondsText);
		}
	}

	public void fillLocationOfEdit(String locationText) throws Exception {
		try {
			// WebAction.scrollIntoView(locationofEdit);
			// To select location
			if (locationText != null) {
				boolean valuePresent = false;
				WebAction.click(locationofEdit);
				Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
				for (WebElement ele : dropDownvalues) {
					if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(locationText)) {
						WebAction.click(ele);
						valuePresent = true;
						break;
					}
				}
				if (valuePresent == false)
					throw new Exception("'" + locationText + "' value is not present in the location drop down");
			}

			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill edit Type
	 * 
	 * @throws Exception
	 */
	public void selectediusOrAvid(String ediusOrAvidText) throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			String ediusOrAvidButtonXpath = "";
			switch (ediusOrAvidText.toUpperCase()) {
			case "EDIUS":
				ediusOrAvidButtonXpath = ediusOrAvid.replace("<<ediusOrAvidName>>", "Edius");
				break;
			case "AVID":
				ediusOrAvidButtonXpath = ediusOrAvid.replace("<<ediusOrAvidName>>", "Avid");
				break;
			}
			WebAction.click(driver.findElement(By.xpath(ediusOrAvidButtonXpath)));

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void fillEditStartDate(String editStartDateText) throws Exception {
		// To fill edit Start Date
		if (editStartDateText != null) {
			WebAction.click(editStartDate);
			WebAction.sendKeys(editStartDate, generateDate(editStartDateText, "MM/dd/yyyy"));
			WebAction.keyPress(editStartDate, "Enter");
		}
	}

	public void fillReqStartTime(String reqStartTimeText) throws Exception {
		// To fill req start time
		if (reqStartTimeText != null) {
			WebAction.click(reqStartTime);
			WebAction.sendKeys(reqStartTime, generateTime(reqStartTimeText, "hh:mm:ss"));
		}
	}

	public void fillNoOfEditors(String noOfEditorsText) throws Exception {

		// To fill no of editors
		if (noOfEditorsText != null) {
			WebAction.sendKeys(noOfEditors, noOfEditorsText);
		}
	}

	public void fillEditTimeNeededInfoInStandard(String editTimeNeededDaysText, String editTimeNeededHoursText,
			String editTimeNeededMinutesText) throws Exception {
		try {
			// To fill edit Time Needed
			if (editTimeNeededDaysText != null || editTimeNeededHoursText != null
					|| editTimeNeededMinutesText != null) {
				WebAction.sendKeys(editTimeNeededDays, editTimeNeededDaysText);
				WebAction.sendKeys(editTimeNeededHours, editTimeNeededHoursText);
				WebAction.sendKeys(editTimeNeededMinutes, editTimeNeededMinutesText);
			} else {
				WebAction.clickUsingJs(editTimeNeededFlexible);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void fillEditTimeNeededInfoInLong(String editTimeNeededWeeksText, String editTimeNeededDaysText,
			String editTimeNeededHoursText) throws Exception {
		try {
			// To fill edit Time Needed
			if (editTimeNeededWeeksText != null || editTimeNeededDaysText != null || editTimeNeededHoursText != null) {
				WebAction.sendKeys(editTimeNeededWeeks, editTimeNeededWeeksText);
				WebAction.sendKeys(editTimeNeededDays, editTimeNeededDaysText);
				WebAction.sendKeys(editTimeNeededHours, editTimeNeededHoursText);
			} else {
				WebAction.clickUsingJs(editTimeNeededFlexible);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void fillTypeOfEditDetails(String typeOfEditText, String typeOfEditQuantityText) throws Exception {
		try {
			WebDriver driver = DriverFactory.getCurrentDriver();
			// To select Type Of Edit
			if (typeOfEditText != null) {
				String[] typeOfEditTextArrayList = typeOfEditText.split(",");
				String[] typeOfEditQuantityTextArrayList = null;
				if (typeOfEditQuantityText != null) {
					typeOfEditQuantityTextArrayList = typeOfEditQuantityText.split(",");
				}
				int j = 1;
				for (int i = 0; i < typeOfEditTextArrayList.length; i++) {
					String typeOfEditXpath = typeOfEdit.replace("<<typeOfEditNo>>", Integer.toString(i + 1));
					WebElement typeOfEditWebElement = driver.findElement(By.xpath(typeOfEditXpath));
					Waits.waitForElement(typeOfEditWebElement, WAIT_CONDITIONS.CLICKABLE);

					String typeOfEditQuantityXpath = typeOfEditQuantity.replace("<<typeOfEditQuantityNo>>",
							Integer.toString(i + 1));
					WebElement typeOfEditQuantityWebElement = driver.findElement(By.xpath(typeOfEditQuantityXpath));
					Waits.waitForElement(typeOfEditQuantityWebElement, WAIT_CONDITIONS.CLICKABLE);

					boolean valuePresent = false;
					WebAction.click(typeOfEditWebElement);
					Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
					for (WebElement ele : dropDownvalues) {
						if (typeOfEditTextArrayList[i].trim().toUpperCase().contains("OTHER")
								&& WebAction.getAttribute(ele, "title").equalsIgnoreCase("Other")) {
							WebAction.click(ele);
							if (typeOfEditQuantityText != null) {
								WebAction.sendKeys(typeOfEditQuantityWebElement, "\u0008");
								WebAction.sendKeys(typeOfEditQuantityWebElement, typeOfEditQuantityTextArrayList[i]);
							}
							WebAction.sendKeys(typeOfEditXpathOtherInputBox, typeOfEditTextArrayList[i]);
							break;
						}
						if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(typeOfEditTextArrayList[i].trim())) {
							WebAction.click(ele);
							if (typeOfEditQuantityText != null) {
								WebAction.sendKeys(typeOfEditQuantityWebElement, "\u0008");
								WebAction.sendKeys(typeOfEditQuantityWebElement, typeOfEditQuantityTextArrayList[i]);
							}
							valuePresent = true;
							break;
						}
					}
					Thread.sleep(1000);
					if (j <= typeOfEditTextArrayList.length - 1
							&& typeOfEditAddButton.getAttribute("class").contains("ant-btn-dashed")) {
						Waits.waitForElement(typeOfEditAddButton, WAIT_CONDITIONS.CLICKABLE);
						WebAction.click(typeOfEditAddButton);
						j++;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill How Many Versions? section
	 * 
	 * @param How Many Versions?
	 * @throws Exception
	 */
	public void fillHowManyVersions(String HowManyVersionsText) throws Exception {
		try {
			// To enter How Many Versions
			if (HowManyVersionsText != null) {
				WebAction.sendKeys(howManyVersions, HowManyVersionsText);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill Additional Requirements
	 * 
	 * @throws Exception
	 */
	public void fillAdditionalRequirementsDetails(String additionalRequirementsText) throws Exception {
		try {
			WebDriver driver = DriverFactory.getCurrentDriver();
			// To select final Delivery
			if (additionalRequirementsText != null) {
				String[] additionalRequirementsTextArrayList = additionalRequirementsText.split(",");
				for (int i = 0; i < additionalRequirementsTextArrayList.length; i++) {
					String additionalRequirementsXpath = additionalRequirements
							.replace("<<AdditionalRequirementsName>>", additionalRequirementsTextArrayList[i]);
					try {
						WebAction.clickUsingJs(driver.findElement(By.xpath(additionalRequirementsXpath)));
					} catch (Exception e) {
						WebAction.sendKeys(additionalRequirementsOtherText, additionalRequirementsTextArrayList[i]);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill Is this a Crash Edit section
	 * 
	 * @param Is this a Crash Edit?
	 * @throws Exception
	 */
	public void fillIsthisaCrashEditDetails(String isthisaCrashEditText) throws Exception {
		// To select Is this a Crash Edit?
		if (isthisaCrashEditText != null && isthisaCrashEditText.equalsIgnoreCase("Yes"))
			WebAction.clickUsingJs(isCrashEdit_Yes);
	}

	/**
	 * To fill final delivery
	 * 
	 * @throws Exception
	 */
	public void fillFinalDeliveryDetails(String finalDeliveryText) throws Exception {
		try {
			WebDriver driver = DriverFactory.getCurrentDriver();
			// To select final Delivery
			if (finalDeliveryText != null) {
				String[] finalDeliveryTextArrayList = finalDeliveryText.split(",");
				for (int i = 0; i < finalDeliveryTextArrayList.length; i++) {
					String finalDeliveryXpath = finalDelivery.replace("<<finalDeliveryName>>",
							finalDeliveryTextArrayList[i]);
					try {
						WebAction.clickUsingJs(driver.findElement(By.xpath(finalDeliveryXpath)));
					} catch (Exception e) {
						WebAction.sendKeys(finalDeliveryOtherText, finalDeliveryTextArrayList[i]);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void fillsourceMaterialDetails(String sourceMaterialText) throws Exception {
		try {
			WebDriver driver = DriverFactory.getCurrentDriver();
			// To select source Material
			if (sourceMaterialText != null) {
				String[] sourceMaterialTextArrayList = sourceMaterialText.split(",");
				for (int i = 0; i < sourceMaterialTextArrayList.length; i++) {
					String sourceMaterialXpath = sourceMaterial.replace("<<SourceMaterialName>>",
							sourceMaterialTextArrayList[i]);
					try {
						WebAction.clickUsingJs(driver.findElement(By.xpath(sourceMaterialXpath)));
					} catch (Exception e) {
						WebAction.sendKeys(sourceMaterialOtherText, sourceMaterialTextArrayList[i]);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void fillCommentInEdit(String commentText) throws Exception {
		try {
			if (commentText != null) {
				Waits.waitForElement(commentTextArea, WAIT_CONDITIONS.CLICKABLE);
				WebAction.sendKeys(commentTextArea, commentText);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill Request Status details in Request Info section
	 * 
	 * @param commentText - division for this form
	 * @throws Exception
	 */
	public void fillRequestStatus(String requestStatusText) throws Exception {
		try {
			WebAction.scrollIntoView(requestStatusDropDown);
			// To fill Request Status
			if (requestStatusText != null) {
				boolean valuePresent = false;
				Thread.sleep(1000);
				// Waits.waitForElement(requestStatusDropDown, WAIT_CONDITIONS.CLICKABLE);
				WebAction.clickUsingJs(requestStatusDropDown);
				Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
				for (WebElement ele : dropDownvalues) {
					System.out.println("title " + WebAction.getAttribute(ele, "title"));
					if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(requestStatusText)) {
						Waits.waitForElement(ele, WAIT_CONDITIONS.CLICKABLE);
						WebAction.click(ele);
						valuePresent = true;
						break;
					}
				}
				if (valuePresent == false)
					throw new Exception(
							"'" + requestStatusText + "' status is not present in the request Status drop down");
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void fillFulfillmentComment(String fulfillmentCommentText) throws Exception {
		try {
			if (fulfillmentCommentText != null) {
				WebAction.click(fulfillmentCommentAddButton);
				Waits.waitForElement(fulfillmentCommentTextArea, WAIT_CONDITIONS.CLICKABLE);
				WebAction.sendKeys(fulfillmentCommentTextArea, fulfillmentCommentText);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void fillEditorControlsSection(String EditorName, String EditorPhoneNumber, String roomText,
			String sessionAssignedFromDateText, String sessionAssignedToDateText, String sessionAssignedToTimeText,
			String sessionAssignedFromTimeText, String differentRoomText) throws Exception {
		if (EditorName != null) {
			WebAction.click(addEditorButton);
			try {
				if (EditorName != null) {
					Waits.waitForElement(editorNameTextbox, WAIT_CONDITIONS.CLICKABLE);
					WebAction.sendKeys(editorNameTextbox, EditorName);
					Thread.sleep(1000);
					Waits.waitUntilElementSizeGreater(SearchList, 0);
					Thread.sleep(1000);
					WebAction.click(SearchList.get(0));
				}
				if (EditorPhoneNumber != null) {
					Waits.waitForElement(editorPhoneNumberTextbox, WAIT_CONDITIONS.CLICKABLE);
					WebAction.sendKeys(editorPhoneNumberTextbox, EditorPhoneNumber);

				}
				if (roomText != null) {
					Waits.waitForElement(editorSearchRoomTextbox, WAIT_CONDITIONS.CLICKABLE);
					WebAction.sendKeys(editorSearchRoomTextbox, roomText);
					Thread.sleep(1000);
					Waits.waitUntilElementSizeGreater(SearchList, 0);
					Thread.sleep(1000);
					WebAction.click(SearchList.get(0));
				}
				selectEditorDate(sessionAssignedFromDateText, sessionAssignedToDateText);
				selectEditorEndTime(sessionAssignedToTimeText);
				selectEditorStartTime(sessionAssignedFromTimeText);
				if (differentRoomText != null) {
					WebAction.clickUsingJs(editorDifferentRoomCheckbox);
					Waits.waitForElement(editorDifferentSearchRoomTextbox, WAIT_CONDITIONS.CLICKABLE);
					WebAction.sendKeys(editorDifferentSearchRoomTextbox, differentRoomText);
					Thread.sleep(1000);
					Waits.waitUntilElementSizeGreater(SearchList, 0);
					Thread.sleep(1000);
					WebAction.click(SearchList.get(0));
				}
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
	}

	public void selectEditorDate(String sessionAssignedFromDateText, String sessionAssignedToDateText)
			throws Exception, InterruptedException {
		if (sessionAssignedFromDateText != null && sessionAssignedToDateText != null) {
			WebAction.click(sessionEditorStartDate);
			WebAction.sendKeys(sessionEditorStartDate, generateDate(sessionAssignedFromDateText, "MM/dd/yyyy"));
			WebAction.keyPress(sessionEditorStartDate, "Enter");
			Thread.sleep(2000);
			WebAction.sendKeys(sessionEditorEndDate, generateDate(sessionAssignedToDateText, "MM/dd/yyyy"));
			WebAction.keyPress(sessionEditorEndDate, "Enter");
		}
	}

	public void selectEditorEndTime(String sessionAssignedToTimeText) throws Exception {
		// To fill end Time
		if (sessionAssignedToTimeText != null) {
			WebAction.click(sessionEditorEndTime);
			WebAction.sendKeys(sessionEditorEndTime, generateTime(sessionAssignedToTimeText, "hh:mm a"));
			WebAction.keyPress(sessionEditorEndTime, "Enter");
		}
	}

	public void selectEditorStartTime(String sessionAssignedFromTimeText) throws Exception {
		// To fill start Time
		if (sessionAssignedFromTimeText != null) {
			WebAction.click(sessionEditorStartTime);
			WebAction.sendKeys(sessionEditorStartTime, generateTime(sessionAssignedFromTimeText, "hh:mm a"));
			WebAction.keyPress(sessionEditorStartTime, "Enter");
		}
	}

	public void fillAsstProducerInfoSection(String isAsstProducerSameasRequestorValue) throws Exception {
		try {
			if (isAsstProducerSameasRequestorValue != null) {
				// To select 'Asst Producer / Field Contact Same as Requester? ' value
				if (isAsstProducerSameasRequestorValue.toUpperCase().equalsIgnoreCase("YES")) {
					WebAction.clickUsingJs(asstProducerSameasRequestor_Options);
				} else {
					WebAction.sendKeys(asstProducerSameAsRequestInputBox, isAsstProducerSameasRequestorValue);
					Thread.sleep(500);
					WebAction.sendKeys_WithoutClear(asstProducerSameAsRequestInputBox, " ");
					Waits.waitUntilElementSizeGreater(SearchList, 0);
					Thread.sleep(1000);
					WebAction.click(SearchList.get(0));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill Additional Recipients
	 * 
	 * @param Additional Recipients for this form
	 * @throws Exception
	 */
	public void fillAdditionalRecipients(String additionalRecipientsText) throws Exception {
		try {
			WebDriver driver = DriverFactory.getCurrentDriver();
			// To enter Additional Recipients
			int j = 0;
			if (additionalRecipientsText != null) {
				Waits.waitForElement(addRecipientButton, WAIT_CONDITIONS.CLICKABLE);
				WebAction.click(addRecipientButton);
				String[] additionalRecipientsTextArrayList = additionalRecipientsText.split(",");
				for (int k = 0; k < additionalRecipientsTextArrayList.length; k++) {
					String additionalRecipientsTextXpath = additionalRecipientsInputBox
							.replace("<<additionalRecipientsInputBoxNo>>", Integer.toString(k + 1));
					WebElement additionalRecipientsTextWebElement = driver
							.findElement(By.xpath(additionalRecipientsTextXpath));
					WebAction.sendKeys(additionalRecipientsTextWebElement, additionalRecipientsTextArrayList[k]);
					j++;
					if (j < additionalRecipientsTextArrayList.length) {
						Waits.waitForElement(addRecipientButton, WAIT_CONDITIONS.CLICKABLE);
						WebAction.click(addRecipientButton);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

}