package nbcu.automation.ui.stepdefs.ncxUnifiedTool;

import java.util.List;
import java.util.Map;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.ncxUnifiedTool.ProdExtendorBridgeCrewRequestFormPage;
import nbcu.automation.ui.pages.ncxUnifiedTool.ProdRockCenterRequestFormPage;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.utils.cucumber.CucumberUtils;
import nbcu.framework.utils.propertyfilereader.ExcelReader;

public class ProdExtendorBridgeCrewRequestFormPageSteps {

	ProdExtendorBridgeCrewRequestFormPage prodExtendorBridgeCrewRequestFormPage = new ProdExtendorBridgeCrewRequestFormPage();

	@Then("Verify error message is displayed for all mandatory fields in show info section for Extend or Bridge Crew Production form")
	public void verifyShowInfoMissingFieldError(DataTable dataTable) throws Exception {
		prodExtendorBridgeCrewRequestFormPage.verifyShowInfoMissingFieldError(
				CucumberUtils.getValuesFromDataTable(dataTable, "Request For Error"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Air Platform Error"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Show Unit Error"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Budget Code Error"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Start Date Error"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Start Time Error"),
				CucumberUtils.getValuesFromDataTable(dataTable, "End Time Error"));

	}

	@Then("Verify error message is displayed for all mandatory fields in Control Room & Crew section for Extend or Bridge Crew Production form")
	public void verifyControlRoomAndCrewMissingFieldErrorInProductionSection(DataTable dataTable) throws Exception {
		prodExtendorBridgeCrewRequestFormPage.verifyControlRoomAndCrewMissingFieldError(
				CucumberUtils.getValuesFromDataTable(dataTable, "Control Room And Crew Error"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Control Room Location Error"),
				CucumberUtils.getValuesFromDataTable(dataTable, "control Room Error"));
	}

	@When("user enters show information in Extend or Bridge Crew Production form")
	public void fillShowInfo(DataTable dataTable) throws Exception {
		prodExtendorBridgeCrewRequestFormPage.addShowInfoExtendorBridgeCrewProduction(
				CucumberUtils.getValuesFromDataTable(dataTable, "Request For"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Air Platform"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Show or Project Name"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Start Date"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Start Time"),
				CucumberUtils.getValuesFromDataTable(dataTable, "End Time"));
	}

	@When("user enters control room and crew information in Extend or Bridge Crew Production form")
	public void fillControlRoomInfoInRockCenterProduction(DataTable dataTable) throws Exception {
		prodExtendorBridgeCrewRequestFormPage.addControlRoomAndCrewInfo(
				CucumberUtils.getValuesFromDataTable(dataTable, "Control Room And Crew Option"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Control Room Location"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Control Room"));
	}

	@Then("user verifies the form sections on Extend or Bridge Crew & Facilities production form")
	public void verifyTheFormSectionsInAnimalsOnPremisesProductionForm() {
		prodExtendorBridgeCrewRequestFormPage.verifyTheFormSectionsInExtendOrBrigeCrewAndFacilitiesProductionForm();
	}

	@Then("user verifies the fields present in {string} section of Extend or Bridge Crew & Facilities Production form")
	public void verifyFieldsPresentSectionOfCnbcProduction(String sectionName) {
		prodExtendorBridgeCrewRequestFormPage
				.checkFieldsInSectionOfExtendOrBridgeCrewAndFacilitiesProduction(sectionName);
	}

	@Then("user checks placeholder of Talent field in {string} section on Extend or Bridge Crew & Facilities Production request")
	public void checkPlaceholderOfTalentInput(String sectionName) {
		prodExtendorBridgeCrewRequestFormPage.getProducerDashboardGeneralPage()
				.checkPlaceholderForInputsHavingPlaceholderAttribute("Talent");
	}

	@Then("user checks placeholder of Show Unit or Project Name field in {string} section on Extend or Bridge Crew & Facilities Production request")
	public void checkPlaceholderofShowUnitOrProjectName(String sectionName) {
		prodExtendorBridgeCrewRequestFormPage
				.checkPlaceholderForInputsHavingPlaceholderAttribute("Show Unit or Project Name", 0, sectionName);
	}

	@Then("user checks placeholder of {string} field in {string} section on Extend or Bridge Crew & Facilities Production request")
	public void checkPlaceholderOfField(String field, String sectionName) {
		prodExtendorBridgeCrewRequestFormPage.checkPlaceholderOfSelectFields(field, sectionName);
	}

	@Then("user checks error for {string} required field in {string} section on Extend or Bridge Crew & Facilities Production request")
	public void checkRequiredFieldErrorIfEmpty(String field, String sectionName) {
		prodExtendorBridgeCrewRequestFormPage.verifyErrorBelowFieldIfEmpty(field, sectionName);
	}

	@Then("user checks error not displayed for {string} required field in {string} section on Extend or Bridge Crew & Facilities Production request")
	public void checkRequiredFieldErrorIfNotEmpty(String field, String sectionName) {
		prodExtendorBridgeCrewRequestFormPage.verifyErrorBelowFieldIfNotEmpty(field, sectionName);
	}

	@When("user clears Show Unit or Project Name in {string} section on Extend or Bridge Crew & Facilities production request")
	public void clearShowUnitOrProjectName(String section) {
		prodExtendorBridgeCrewRequestFormPage.clearTextareaInput("Show Unit or Project Name", 0, section);
	}

	@When("user clears Details and Notes in {string} section on Extend or Bridge Crew & Facilities production request")
	public void clearDetailsAndNotes(String section) {
		prodExtendorBridgeCrewRequestFormPage.clearTextareaInput("Details and Notes", 0, section);
	}

	@Then("user checks {string} field in {string} section is disabled on Extend or Bridge Crew & Facilities production request")
	public void isInputDisabled(String field, String sectionName) {
		prodExtendorBridgeCrewRequestFormPage.isInputDisabled(field, sectionName);
	}

	@Then("user checks {string} field in {string} section is readonly on Extend or Bridge Crew & Facilities production request")
	public void isInputReadOnly(String field, String sectionName) {
		prodExtendorBridgeCrewRequestFormPage.isInputReadOnly(field, sectionName);
	}

	@Then("user checks {string} field in {string} section is enabled on Extend or Bridge Crew & Facilities production request")
	public void isInputEnabled(String field, String sectionName) {
		prodExtendorBridgeCrewRequestFormPage.isInputEnabled(field, sectionName);
	}

	@Then("user checks {string} checkbox in {string} section is disabled on Extend or Bridge Crew & Facilities production request")
	public void isCheckboxDisabled(String field, String sectionName) {
		prodExtendorBridgeCrewRequestFormPage.isCheckboxDisabled(field, sectionName);
	}

	@Then("user checks {string} checkbox in {string} section is enabled on Extend or Bridge Crew & Facilities production request")
	public void isCheckboxEnabled(String field, String sectionName) {
		prodExtendorBridgeCrewRequestFormPage.isCheckboxEnabled(field, sectionName);
	}

	@Then("user checks {string} checkbox in {string} section is selected on Extend or Bridge Crew & Facilities production request")
	public void isCheckboxSelected(String field, String sectionName) {
		prodExtendorBridgeCrewRequestFormPage.isCheckboxSelected(field, sectionName);
	}

	@Then("user checks {string} checkbox in {string} section is not selected on Extend or Bridge Crew & Facilities production request")
	public void isCheckboxNotSelected(String field, String sectionName) {
		prodExtendorBridgeCrewRequestFormPage.isCheckboxNotSelected(field, sectionName);
	}

	@Then("user checks {string} radio button is selected for {string} field in {string} section on Extend or Bridge Crew & Facilities production request")
	public void isCorrectRadioSelected(String option, String field, String sectionName) {
		prodExtendorBridgeCrewRequestFormPage.checkCorrectRadioIsSelected(field, sectionName);
	}

	@When("user selects Location in {string} section on Extend or Bridge Crew & Facilities production request")
	public void selectLocation(String section, DataTable dataTable) throws Exception {
		String option = CucumberUtils.getValuesFromDataTable(dataTable, "Location");
		prodExtendorBridgeCrewRequestFormPage.selectValueInDropdown(option, "Location", 0, section);
	}

	@When("user selects Set Location in {string} section on Extend or Bridge Crew & Facilities production request")
	public void selectSetLocation(String section, DataTable dataTable) throws Exception {
		String option = CucumberUtils.getValuesFromDataTable(dataTable, "Set Location");
		prodExtendorBridgeCrewRequestFormPage.selectValueInDropdown(option, "Set Location", 0, section);
	}

	@When("user selects Address in {string} section on Extend or Bridge Crew & Facilities production request")
	public void fillAddress(String section, DataTable dataTable) throws Exception {
		String option = CucumberUtils.getValuesFromDataTable(dataTable, "Address");
		prodExtendorBridgeCrewRequestFormPage.fillTextbox("Address", option, 0, section);
	}

	@When("user selects Control Room & Crew in {string} section on Extend or Bridge Crew & Facilities production request")
	public void selectControlRoomAndCrew(String section, DataTable dataTable) throws Exception {
		String option = CucumberUtils.getValuesFromDataTable(dataTable, "Control Room & Crew");
		prodExtendorBridgeCrewRequestFormPage.selectRadioOption("Control Room & Crew", option, 0, section);
	}

	@When("user selects Control Room Location in {string} section on Extend or Bridge Crew & Facilities production request")
	public void selectControlRoomLocation(String section, DataTable dataTable) throws Exception {
		String option = CucumberUtils.getValuesFromDataTable(dataTable, "Control Room Location");
		prodExtendorBridgeCrewRequestFormPage.selectValueInDropdown(option, "Control Room Location", 0, section);
	}

	@When("user selects Control Room in {string} section on Extend or Bridge Crew & Facilities production request")
	public void selectControlRoom(String section, DataTable dataTable) throws Exception {
		String option = CucumberUtils.getValuesFromDataTable(dataTable, "Control Room");
		prodExtendorBridgeCrewRequestFormPage.selectValueInDropdown(option, "Control Room", 0, section);
	}

	@When("user selects Details and Notes in {string} section on Extend or Bridge Crew & Facilities production request")
	public void fillDetailsAndNotes(String section, DataTable dataTable) throws Exception {
		String text = CucumberUtils.getValuesFromDataTable(dataTable, "Details and Notes");
		prodExtendorBridgeCrewRequestFormPage.fillTextbox("Details and Notes", text, 0, section);
	}

	@When("user selects Division in {string} section on Extend or Bridge Crew & Facilities production request")
	public void selectDivision(String section, DataTable dataTable) throws Exception {
		String option = CucumberUtils.getValuesFromDataTable(dataTable, "Division");
		prodExtendorBridgeCrewRequestFormPage.selectValueInDropdown(option, "Division", 0, section);
	}

	@When("user selects Is a TPM or TM Needed? in {string} section on Extend or Bridge Crew & Facilities production request")
	public void selectIsATpmOrTmNeeded(String section, DataTable dataTable) throws Exception {
		String option = CucumberUtils.getValuesFromDataTable(dataTable, "Is a TPM or TM Needed?");
		prodExtendorBridgeCrewRequestFormPage.selectRadioOption("Is a TPM or TM Needed?", option, 0, section);
	}

	@When("user selects Same as requester? in {string} section on Extend or Bridge Crew & Facilities production request")
	public void selectSameAsRequester(String section, DataTable dataTable) throws Exception {
		String option = CucumberUtils.getValuesFromDataTable(dataTable, "Same as requester?");
		Boolean choice = Boolean.parseBoolean(option);
		prodExtendorBridgeCrewRequestFormPage.selectCheckbox("Same as requester?", section, choice);
	}

	@When("user selects TPM/TM Name in {string} section on Extend or Bridge Crew & Facilities production request")
	public void selectTpmTmName(String section, DataTable dataTable) throws Exception {
		String option = CucumberUtils.getValuesFromDataTable(dataTable, "TPM/TM Name");
		prodExtendorBridgeCrewRequestFormPage.fillTextbox("TPM/TM Name", option, 0, section);
	}

	@When("user selects Air Platform in {string} section on Extend or Bridge Crew & Facilities production request")
	public void selectAirPlatform(String section, DataTable dataTable) throws Exception {
		String option = CucumberUtils.getValuesFromDataTable(dataTable, "Air Platform");
		prodExtendorBridgeCrewRequestFormPage.selectValueInDropdown(option, "Air Platform", 0, section);
	}

	@When("user selects Request For in {string} section on Extend or Bridge Crew & Facilities production request")
	public void selectRequestFor(String section, DataTable dataTable) throws Exception {
		String option = CucumberUtils.getValuesFromDataTable(dataTable, "Request For");
		prodExtendorBridgeCrewRequestFormPage.selectRadioOption("Request For", option, 0, section);
	}

	@When("user selects Show Unit or Project Name in {string} section on Extend or Bridge Crew & Facilities production request")
	public void selectShowUnitOrProjectName(String section, DataTable dataTable) throws Exception {
		String option = CucumberUtils.getValuesFromDataTable(dataTable, "Show Unit or Project Name");
		prodExtendorBridgeCrewRequestFormPage.selectValueInDropdown(option, "Show Unit or Project Name", 0, section);
	}

	@When("user selects Work Order # in {string} section on Extend or Bridge Crew & Facilities production request")
	public void provideWorkOrder(String section, DataTable dataTable) throws Exception {
		String option = CucumberUtils.getValuesFromDataTable(dataTable, "Work Order #");
		prodExtendorBridgeCrewRequestFormPage.fillTextbox("Work Order #", option, 0, section);
	}

	@When("user selects Budget Code in {string} section on Extend or Bridge Crew & Facilities production request")
	public void selectBudgetCode(String section, DataTable dataTable) throws Exception {
		String option = CucumberUtils.getValuesFromDataTable(dataTable, "Budget Code");
		prodExtendorBridgeCrewRequestFormPage.fillTextbox("Budget Code", option, 0, section);
	}

	@When("user selects Start Date in {string} section on Extend or Bridge Crew & Facilities production request")
	public void selectStartDate(String section, DataTable dataTable) throws Exception {
		String option = CucumberUtils.getValuesFromDataTable(dataTable, "Start Date");
		prodExtendorBridgeCrewRequestFormPage.selectDate("Start Date", option, 0, section);
	}

	@When("user selects Start Time in {string} section on Extend or Bridge Crew & Facilities production request")
	public void selectStartTime(String section, DataTable dataTable) throws Exception {
		String option = CucumberUtils.getValuesFromDataTable(dataTable, "Start Time");
		prodExtendorBridgeCrewRequestFormPage.fillTextbox("Start Time", option, 0, section);
	}

	@When("user selects End Time in {string} section on Extend or Bridge Crew & Facilities production request")
	public void selectEndTime(String section, DataTable dataTable) throws Exception {
		String option = CucumberUtils.getValuesFromDataTable(dataTable, "End Time");
		prodExtendorBridgeCrewRequestFormPage.fillTextbox("End Time", option, 0, section);
	}

	@When("user selects Other in {string} section on Extend or Bridge Crew & Facilities production request")
	public void provideTextInOther(String section, DataTable dataTable) throws Exception {
		String option = CucumberUtils.getValuesFromDataTable(dataTable, "Other");
		prodExtendorBridgeCrewRequestFormPage.fillTextbox("Other", option, 0, section);
	}

	@Then("verify all fields in the Extend or Bridge form are matching with columns in production dashboard")
	public void verifyExtendBridgeProductionDashboardValuesWithForm(DataTable dataTable) throws Exception {
		prodExtendorBridgeCrewRequestFormPage.verifyExtendBridgeRequestValuesWithProductionDashboardValues(
				CucumberUtils.getValuesFromDataTable(dataTable, "Requesters"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Prod Date"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Show/Project"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Production Purpose"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Set Location"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Control Room"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Submitted"));
	}
}
