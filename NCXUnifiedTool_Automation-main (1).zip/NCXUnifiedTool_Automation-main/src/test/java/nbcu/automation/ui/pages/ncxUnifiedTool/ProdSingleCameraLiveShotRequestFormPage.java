
package nbcu.automation.ui.pages.ncxUnifiedTool;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import nbcu.automation.ui.constants.ncxUnifiedTool.Constants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.report.ReportGenerate;
import nbcu.framework.utils.ui.Waits;
import nbcu.framework.utils.ui.WebAction;
import nbcu.framework.utils.ui.Waits.WAIT_CONDITIONS;

public class ProdSingleCameraLiveShotRequestFormPage {

	ProducerDashboardGeneralPage producerDashboardGeneralPage = new ProducerDashboardGeneralPage();

	@FindBy(xpath = "//*[contains(text(),'Select Set Background')]/ancestor::div[3]//div[contains(@class,'error')]")
	WebElement setBackgroundError;

	@FindBy(xpath = "//*[contains(@forminputname,'setStagingNeeded')]/ancestor::div[1]//div[contains(@class,'error')]")
	WebElement setStagingNeededError;

	@FindBy(xpath = "//*[contains(text(),'Select Set Background')]")
	WebElement setBackgroundDropDown;

	@FindBy(xpath = "//div[contains(text(),'HAIR STYLIST')]/ancestor::div[1]//input")
	WebElement hairStylistInputbox;

	@FindBy(xpath = "//div[contains(text(),'PROMPTER OP')]/ancestor::div[1]//input")
	WebElement prompterOpInputbox;

	@FindBy(xpath = "//div[contains(text(),'MAKEUP ARTIST')]/ancestor::div[1]//input")
	WebElement makeUpArtistInputbox;

	@FindBy(xpath = "//*[@forminputname='setStagingNeeded']//label[@label-value='false']")
	WebElement setStagingNeeded_No;

	@FindBy(xpath = "//*[@forminputname='setStagingNeeded']//label[@label-value='true']")
	WebElement setStagingNeeded_Yes;

	String dropDownvaluesXpath = "//div[@class='cdk-virtual-scroll-content-wrapper']/nz-option-item";

	@FindBy(xpath = "//div[@class='cdk-virtual-scroll-content-wrapper']/nz-option-item | //nz-option-item ")
	List<WebElement> dropDownvalues;

	@FindBy(xpath = "//*[@sectionTitle]//*[contains(@class,'status-title-area')]//p")
	List<WebElement> formSectionTitles;

	@FindBy(xpath = "//*[@sectiontitle='Show Info']//nz-form-label//label")
	List<WebElement> showInfoSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='General Details']//nz-form-label//label")
	List<WebElement> generalDetailsSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='Requester(s)']//nz-form-label//label")
	List<WebElement> requestersSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='Talent']//nz-form-label//label")
	List<WebElement> talentSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='Details']//nz-form-label//label")
	List<WebElement> detailsSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='SET CREW']//nz-form-label//label")
	List<WebElement> setCrewSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='Set Information']//nz-form-label//label")
	List<WebElement> setInformationSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='Details']//textarea")
	WebElement DetailNotes;

	@FindBy(xpath = "//*[@class='cdk-overlay-pane']//nz-option-item")
	List<WebElement> setBackgroundOptions;

	@FindBy(xpath = "//*[contains(text(),' Set Background ')]//ancestor::div[1]//input")
	WebElement setBackgroundDropdown;

	@FindBy(xpath = "//*[text()='SET INFORMATION']")
	WebElement setInformationSection;

	public ProdSingleCameraLiveShotRequestFormPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify set Information section missing field error message
	 *
	 * @throws Exception
	 */
	public void verifySetInformationMissingFieldError(String setBackgroundErrorMessage,
			String setStagingNeededErrorMessage) throws Exception {
		try {
			CommonValidations.verifyTextValue(setBackgroundError, setBackgroundErrorMessage);
			CommonValidations.verifyTextValue(setStagingNeededError, setStagingNeededErrorMessage);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void selectSetInformation(String backgroundText, String stageingNeededText) throws Exception {
		WebAction.scrollIntoView(producerDashboardGeneralPage.setInformationSection);
		try {
			selectSetBackground(backgroundText);
			addSetStagingNeeded(stageingNeededText);
		} catch (

		Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void addSetBackground(String backgroundText) throws Exception {
		// To select set background
		if (backgroundText != null) {
			boolean valuePresent = false;

			WebAction.clickUsingJs(setBackgroundDropDown);
			Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
			for (WebElement ele : dropDownvalues) {
				if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(backgroundText)) {
					WebAction.click(ele);
					ReportGenerate.test.log(Status.INFO,
							"User selects " + backgroundText + " as Set Background option");
					valuePresent = true;
					break;
				}
			}
			if (valuePresent == false)
				throw new Exception(
						"'" + backgroundText + "' value is not present in the set background type drop down");
		}
	}

	public void addSetStagingNeeded(String stageingNeededText) throws Exception {
		try {
			if (stageingNeededText != null) {
				if (stageingNeededText.equalsIgnoreCase("Yes")) {
					WebAction.click(setStagingNeeded_Yes);
					ReportGenerate.test.log(Status.INFO,
							"User selects " + stageingNeededText + " for Staging: Are set changes needed? option");
				} else {
					WebAction.click(setStagingNeeded_No);
					ReportGenerate.test.log(Status.INFO, "User selects No for Staging: Are set changes needed? option");

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void addSetCrew(String captureManagerText, String setCrewText) throws Exception {
		WebAction.scrollIntoView(producerDashboardGeneralPage.setCrewSection);
		producerDashboardGeneralPage.selectCaptureManager(captureManagerText);
		producerDashboardGeneralPage.addSetCrewText(setCrewText);
		WebAction.clickUsingJs(producerDashboardGeneralPage.setCrewSection);

	}

	/**
	 * To verify sections on request form
	 * 
	 */
	public void verifyTheFormSectionsInSingleCameraLiveShotForm() {
		Object[] expectedHeaders = { "STATUS", "GENERAL DETAILS", "REQUESTER(S)", "TALENT", "DETAILS", "SHOW INFO",
				"SET INFORMATION", "SET CREW" };
		if (expectedHeaders.length != formSectionTitles.size()) {
			Assert.assertEquals(formSectionTitles.size(), expectedHeaders.length,
					"Total number of sections " + "are not the same as expected");
		} else {
			boolean allFormSectionsArePresent = true;
			for (int itr = 0; itr < expectedHeaders.length; itr++) {
				String expectedName = (String) expectedHeaders[itr];
				String displayedName = WebAction.getText(formSectionTitles.get(itr));
				if (!expectedName.equals(displayedName)) {
					allFormSectionsArePresent = false;
					Assert.assertEquals(displayedName, expectedName,
							"Expected section name is not same as " + "displayed name");
				}
			}
			Assert.assertTrue(allFormSectionsArePresent,
					"All expected sections are not present on " + "Single camera live shot form");
		}
	}

	/**
	 * To check fields on the single camera live form
	 * 
	 * @param sectionName - section name
	 */
	public void checkFieldsInSectionOfSingleCameraLiveShot(String sectionName) {
		List<WebElement> sectionLabelElements = getSectionLabelElements(sectionName);
		if (sectionLabelElements == null) {
			Assert.assertTrue(false, sectionName + " section is not present in Single camera live shot form");
			return;
		}

		List<String> expectedFieldNamesList = getExpectedFieldsSectionWise(sectionName);
		List<String> expectedRequiredFieldList = getRequiredFieldsSectionWise(sectionName);
		if (sectionLabelElements.size() != expectedFieldNamesList.size()) {
			Assert.assertEquals(sectionLabelElements.size(), expectedFieldNamesList.size(),
					"Number of displayed fields and expected fields not equal in " + sectionName
							+ " section of single live camera shot");
			return;
		}
		for (int itr = 0; itr < expectedFieldNamesList.size(); itr++) {
			String expectedName = expectedFieldNamesList.get(itr);
			String displayedField = WebAction.getText(sectionLabelElements.get(itr));
			if (displayedField.contains("Prep Time")) {
				displayedField = (displayedField.split(" ")[0] + " " + displayedField.split(" ")[1].trim());
			}
			Assert.assertEquals(displayedField, expectedName, "Displayed field is not same as expected field in "
					+ sectionName + " section of single live camera shot form");
			String cssClasses = WebAction.getAttribute(sectionLabelElements.get(itr), "class");
			if (cssClasses.contains(" ant-form-item-required") && !expectedRequiredFieldList.contains(displayedField)) {
				Assert.assertTrue(false, "'" + displayedField + "' is not a required field in " + sectionName
						+ " section but displayed with *(required symbol)");
			} else if (!cssClasses.contains(" ant-form-item-required")
					&& expectedRequiredFieldList.contains(displayedField)) {
				Assert.assertTrue(false, "'" + displayedField + "' is a required field in " + sectionName
						+ " section but not displayed with *(required symbol)");
			}
		}
	}

	public List<WebElement> getSectionLabelElements(String sectionName) {
		if (sectionName.equalsIgnoreCase("GENERAL DETAILS")) {
			return generalDetailsSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("REQUESTER(S)")) {
			return requestersSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("TALENT")) {
			return talentSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("DETAILS")) {
			return detailsSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("SHOW INFO")) {
			return showInfoSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("SET CREW")) {
			return setCrewSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("SET INFORMATION")) {
			return setInformationSectionFieldLabels;
		}
		return null;
	}

	public List<String> getExpectedFieldsSectionWise(String sectionName) {
		List<String> fieldNamesList = new ArrayList<String>();
		if (sectionName.equalsIgnoreCase("GENERAL DETAILS")) {
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Division")));
		} else if (sectionName.equalsIgnoreCase("REQUESTER(S)")) {
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Add Requester(s)")));
		} else if (sectionName.equalsIgnoreCase("TALENT")) {
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Talent")));
		} else if (sectionName.equalsIgnoreCase("DETAILS")) {
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Details and Notes")));
		} else if (sectionName.equalsIgnoreCase("SHOW INFO")) {
			fieldNamesList.add("Air Platform");
			fieldNamesList.add("Show Unit or Project Name");
			String showUnitOrProjectName = Constants.getShowUnitOrProjectName();
			if (showUnitOrProjectName != null && showUnitOrProjectName.equalsIgnoreCase("Other")) {
				fieldNamesList.add("Other");
			}
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Is Budget Code Available?", "Budget Code")));
			String division = Constants.getDivision();
			if (division != null && division.equals("CNBC")) {
				fieldNamesList.add("Work Order #");
			}
			fieldNamesList
					.addAll(new ArrayList<String>(Arrays.asList("Start Date", "Prep Time", "Start Time", "End Time")));
		} else if (sectionName.equalsIgnoreCase("SET CREW")) {
			fieldNamesList.addAll(new ArrayList<String>(
					Arrays.asList("Capture Manager: Do you need content to be recorded?", "Set Crew")));
		} else if (sectionName.equalsIgnoreCase("SET INFORMATION")) {
			fieldNamesList.add("Set Background");
			String setBackground = Constants.getSetBackground();
			if (setBackground != null && setBackground.equalsIgnoreCase("Other")) {
				fieldNamesList.add("Other");
			}
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Staging: Are set changes needed?")));
		}
		return fieldNamesList;
	}

	public List<String> getRequiredFieldsSectionWise(String sectionName) {
		List<String> fieldNamesList = new ArrayList<String>();
		if (sectionName.equalsIgnoreCase("GENERAL DETAILS")) {
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Division")));
		} else if (sectionName.equalsIgnoreCase("REQUESTER(S)") || sectionName.equalsIgnoreCase("TALENT")
				|| sectionName.equalsIgnoreCase("SET CREW") || sectionName.equalsIgnoreCase("DETAILS")) {
			fieldNamesList.addAll(new ArrayList<String>());
		} else if (sectionName.equalsIgnoreCase("SHOW INFO")) {
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Air Platform", "Show Unit or Project Name",
					"Other", "Is Budget Code Available?", "Budget Code", "Start Date", "Start Time", "End Time")));
		} else if (sectionName.equalsIgnoreCase("SET INFORMATION")) {
			fieldNamesList
					.addAll(new ArrayList<String>(Arrays.asList("Set Background", "Staging: Are set changes needed?")));
		}
		return fieldNamesList;
	}

	/**
	 * To add details and notes in the form
	 *
	 * @param Notes- Notes
	 */
	public void addDetailsAndNotes(String Notes) throws Exception {
		WebAction.scrollIntoView(DetailNotes);
		WebAction.sendKeys(DetailNotes, Notes);
		ReportGenerate.test.log(Status.INFO, "User enters " + Notes + " in Details and Notes section");
	}

	/**
	 * To select set background in the form
	 *
	 * @param setBackground- Set Background
	 */
	public void selectSetBackground(String setBackground) throws Exception {
		WebAction.scrollIntoView(setInformationSection);
		if (setBackground != null) {
			boolean valuePresent = false;
			WebAction.clickUsingJs(setBackgroundDropdown);
			for (WebElement options : setBackgroundOptions) {
				if (WebAction.getAttribute(options, "title").equalsIgnoreCase(setBackground)) {
					WebAction.click(options);
					Constants.setSetBackground(options.getText());
					valuePresent = true;
					ReportGenerate.test.log(Status.INFO, "User selects " + setBackground + " as Set Background option");
					break;
				}

			}

			if (valuePresent == false)
				throw new Exception("'" + setBackground + "' value is not present in the location type drop down");
		}
	}

	/**
	 * To verify values in the Single Camera Live Shot form are present in
	 * production dashboard columns
	 * 
	 * @throws Exception
	 */
	public void verifySingleCameraLiveShotRequestValuesWithProductionDashboardValues(String additionalRequestersText,
			String ProdDateText, String ShowProjectText, String ProductionPurposeText, String SetLocationText,
			String ControlRoomText, String PositionsText, String SubmittedText) throws Exception {
		try {

			String columnCellString = "//a[contains(text(),'<<RequestId>>')]/ancestor::tr/td[contains(@class,'<<ColumnType>>')]/div";

			String columnCellTypeText = columnCellString.replace("<<RequestId>>", Constants.getRequestNumber())
					.replace("<<ColumnType>>", "position");

			// To validate set crew
			if (PositionsText != null) {
				String SetCrewArrayList[] = null;
				if (PositionsText.contains(",")) {
					SetCrewArrayList = PositionsText.split(",");
				} else {
					SetCrewArrayList = PositionsText.split(" ");
				}
				for (int i = 0; i < SetCrewArrayList.length; i++) {
					switch (SetCrewArrayList[i].toUpperCase()) {

					case "HAIR STYLIST":
						SetCrewArrayList[i] = "HAIR";
						break;
					case "MAKEUP ARTIST":
						SetCrewArrayList[i] = "MU";
						break;
					case "PLAZA PRODUCTIONS OP":
						// SetCrewArrayList[i] = "";
						break;
					case "PROMPTER OP":
						SetCrewArrayList[i] = "PMT";
						break;
					}
				}
				for (String SetCrewArray : SetCrewArrayList) {
					producerDashboardGeneralPage.verifyExpectedValueInFormWithActualValueInDashboard(columnCellTypeText,
							SetCrewArray);
				}
			}

			ProductionPurposeText = "Live Shot - Single Camera";
			SetLocationText = "Any Room Plaza Prod";
			ControlRoomText = null;
			PositionsText = null;

			producerDashboardGeneralPage.verifyRockCenterRequestValuesWithProductionDashboardValues(
					additionalRequestersText, ProdDateText, ShowProjectText, ProductionPurposeText, SetLocationText,
					ControlRoomText, PositionsText, SubmittedText);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
}