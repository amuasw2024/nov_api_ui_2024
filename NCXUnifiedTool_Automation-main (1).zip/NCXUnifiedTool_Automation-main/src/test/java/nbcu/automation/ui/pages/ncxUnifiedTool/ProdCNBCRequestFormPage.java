
package nbcu.automation.ui.pages.ncxUnifiedTool;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import nbcu.automation.ui.constants.ncxUnifiedTool.Constants;
import nbcu.automation.ui.pojos.ncxUnifiedTool.CrewRecord;
import nbcu.automation.ui.pojos.ncxUnifiedTool.LocationRecord;
import nbcu.automation.ui.pojos.ncxUnifiedTool.RequesterRecord;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.Other.DateFunctions;
import nbcu.framework.utils.ui.Waits;
import nbcu.framework.utils.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.utils.ui.WebAction;
import static nbcu.framework.factory.DriverFactory.getCurrentDriver;
import static nbcu.framework.utils.ui.Waits.waitForElement;
import static nbcu.framework.utils.ui.WebAction.scrollIntoView;
import static nbcu.framework.utils.ui.WebAction.getText;
import static nbcu.framework.utils.ui.WebAction.click;
import org.openqa.selenium.Keys;

public class ProdCNBCRequestFormPage {

	ProducerDashboardGeneralPage producerDashboardGeneralPage = new ProducerDashboardGeneralPage();

	public ProducerDashboardGeneralPage getProducerDashboardGeneralPage() {
		return producerDashboardGeneralPage;
	}

	@FindBy(xpath = "(//*[contains(text(),'Sub Division')]//following::nz-select-search[1])[1]")
	WebElement subDivisionSection;

	@FindBy(xpath = "//textarea[@placeholder='Add Staging Needs']")
	WebElement StagingNeedsTextarea;

	@FindBy(xpath = "//*[@forminputname='controlRoomNeeded']//label[@label-value='true']")
	WebElement controlRoomNeeded_Yes;

	@FindBy(xpath = "//*[@forminputname='controlRoomNeeded']//label[@label-value='false']")
	WebElement controlRoomNeeded_No;

	@FindBy(xpath = "//*[@forminputname='ingest']//label[@label-value='true']")
	WebElement ingest_Yes;

	@FindBy(xpath = "//*[@forminputname='ingest']//label[@label-value='false']")
	WebElement ingest_No;

	@FindBy(xpath = "//*[@forminputname='iso']//label[@label-value='true']")
	WebElement iso_Yes;

	@FindBy(xpath = "//*[@forminputname='iso']//label[@label-value='false']")
	WebElement iso_No;

	@FindBy(xpath = "//*[contains(text(),' Is a Control Room Needed')]/ancestor::div[3]//div[contains(@class,'error')]")
	WebElement controlRoomNeededError;

	@FindBy(xpath = "//*[contains(text(),' Is a Control Room Needed? ')]")
	WebElement IsAControlRoomNeededLabel;

	@FindBy(xpath = "//*[contains(text(),' Is Budget Code Available? ')]/../following::*[1]//input")
	List<WebElement> isBudgetCodeAvailableRadios;

	@FindBy(xpath = "//*[contains(text(),' Is Budget Code Available? ')]/../following::*[1]//*[text()]")
	List<WebElement> isBudgetCodeAvailableRadioLabels;

	@FindBy(xpath = "//*[contains(text(),' Is a Control Room Needed? ')]/../following::*[1]//input")
	List<WebElement> isAControlRoomNeededRadios;

	@FindBy(xpath = "//*[contains(text(),' Is a Control Room Needed? ')]/../following::*[1]//*[text()]")
	List<WebElement> isAControlRoomNeededRadioLabels;

	@FindBy(xpath = "//*[contains(text(),' Ingest: Do you need content to be recorded? ')]/../following::*[1]//input")
	List<WebElement> ingestDoYouNeedContentToBeRecordedRadios;

	@FindBy(xpath = "//*[contains(text(),' Ingest: Do you need content to be recorded? ')]/../following::*[1]//*[text()]")
	List<WebElement> ingestDoYouNeedContentToBeRecordedRadioLabels;

	@FindBy(xpath = "//*[contains(text(),' ISO: Do you need ISO recordings? ')]/../following::*[1]//input")
	List<WebElement> isoDoYouNeedIsoRecordingsRadios;

	@FindBy(xpath = "//*[contains(text(),' ISO: Do you need ISO recordings? ')]/../following::*[1]//*[text()]")
	List<WebElement> isoDoYouNeedIsoRecordingsRadioLabels;

	@FindBy(xpath = "//*[@sectionTitle]//*[contains(@class,'status-title-area')]//p[contains(@class,'left-hand-title')]")
	List<WebElement> formSectionTitles;

	@FindBy(xpath = "//*[@sectiontitle='Show Info']//nz-form-label//label")
	List<WebElement> showInfoSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='General Details']//nz-form-label//label")
	List<WebElement> generalDetailsSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='Requester(s)']//nz-form-label//label")
	List<WebElement> requestersSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='Talent']//nz-form-label//label")
	List<WebElement> talentSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='Production Purpose']//nz-form-label//label")
	List<WebElement> productionPurposeSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='Set Location']//nz-form-label//label")
	List<WebElement> setLocationSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='Set Crew']//nz-form-label//label")
	List<WebElement> setCrewSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='Staging']//nz-form-label//label")
	List<WebElement> stagingSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='Control Room']//nz-form-label//label")
	List<WebElement> controlRoomSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='Control Room CREW']//nz-form-label//label")
	List<WebElement> controlRoomCrewSectionFieldLabels;

	@FindBy(xpath = "//label[contains(text(),'Division')]/ancestor::nz-form-label/following::input[1]")
	WebElement divisionInput;

	@FindBy(xpath = "//label[contains(text(),'Show Unit or Project Name')]/ancestor::nz-form-label/following::input[1]")
	WebElement showUnitOrProjectNameInput;

	@FindBy(xpath = "//*[text()=' Request For ']/../following::*[1]//input")
	WebElement requestForInput;

	@FindBy(xpath = "//*[text()=' Location ']/../following::*[1]//input")
	WebElement locationInput;

	@FindBy(xpath = "//*[text()=' Set Crew ']/../following::*[1]//input")
	WebElement setCrewInput;

	@FindBy(xpath = "//*[text()=' Control Room Crew ']/../following::*[1]//input")
	WebElement controlRoomCrewInput;

	@FindBy(xpath = "//*[text()=' Details & Notes ']/../following::*[1]//textarea")
	WebElement detailsAndNotesInput;

	@FindBy(xpath = "//*[text()=' Staging Needs ']/../following::*[1]//textarea")
	WebElement stagingNeedsInput;

	WebDriver driver = DriverFactory.getCurrentDriver();

	public ProdCNBCRequestFormPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify set location section missing field error message
	 *
	 * @throws Exception
	 */
	public void verifySetLocationMissingFieldError(String locationErrorMessage) throws Exception {
		WebAction.scrollIntoView(producerDashboardGeneralPage.setLocationSection);
		try {
			CommonValidations.verifyTextValue(producerDashboardGeneralPage.locationError, locationErrorMessage);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify control room section missing field error message
	 *
	 * @throws Exception
	 */
	public void verifyControlRoomNeededMissingFieldError(String controlRoomNeededErrorMessage) throws Exception {
		WebAction.scrollIntoView(producerDashboardGeneralPage.stagingSection);
		try {
			CommonValidations.verifyTextValue(controlRoomNeededError, controlRoomNeededErrorMessage);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void addShowInfoInCNBCProduction(String airPlatformText, String subDivisionText, String showText,
			String startDateText, String callTimeText, String startTimeText, String endTimeText) throws Exception {
		try {
			WebAction.scrollIntoView(producerDashboardGeneralPage.productionPurposeSection);
			producerDashboardGeneralPage.selectAirPlatform(airPlatformText);
			selectSubDivision(subDivisionText);
			producerDashboardGeneralPage.enterShow(showText);
			producerDashboardGeneralPage.selectStartDate(startDateText);
			producerDashboardGeneralPage.selectPrepCallTime(callTimeText);
			producerDashboardGeneralPage.selectStartTime(startTimeText);
			producerDashboardGeneralPage.selectEndTime(endTimeText);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	private void selectSubDivision(String subDivisionText) throws Exception {
		// To select sub division
		if (subDivisionText != null && WebAction.isDisplayed(subDivisionSection)) {
			boolean valuePresent = false;
			WebAction.clickUsingJs(subDivisionSection);
			Waits.waitUntilElementSizeGreater(By.xpath(producerDashboardGeneralPage.dropDownvaluesXpath), 0);
			for (WebElement ele : producerDashboardGeneralPage.dropDownvalues) {
				if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(subDivisionText)) {
					WebAction.click(ele);
					valuePresent = true;
					break;
				}
			}
			if (valuePresent == false)
				throw new Exception(
						"'" + subDivisionText + "' value is not present in the sub division type drop down");
		}
	}

	public void addSetLocationInfoInCNBCProduction(String locationText) throws Exception {
		try {
			WebAction.scrollIntoView(producerDashboardGeneralPage.setLocationSection);
			producerDashboardGeneralPage.selectLocation(locationText);
			Constants.setLocations(locationText);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void addStagingInfoInCNBCProduction(String StagingNeedsText) throws Exception {
		try {
			if (StagingNeedsText != null) {
				Waits.waitForElement(StagingNeedsTextarea, WAIT_CONDITIONS.CLICKABLE);
				WebAction.click(StagingNeedsTextarea);
				WebAction.sendKeys(StagingNeedsTextarea, StagingNeedsText);
			}
		} catch (

		Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void addControlRoomInfoInCNBCProduction(String controlRoomNeededText, String ingestText, String isoText,
			String controlRoomCrewText) throws Exception {
		try {
			WebAction.scrollIntoView(producerDashboardGeneralPage.controlRoomSection);
			if (controlRoomNeededText != null) {
				if (controlRoomNeededText.equalsIgnoreCase("No"))
					WebAction.click(controlRoomNeeded_No);
				else {
					WebAction.click(controlRoomNeeded_Yes);
					if (ingestText.equalsIgnoreCase("yes")) {
						WebAction.click(ingest_Yes);
					} else {
						WebAction.click(ingest_No);
					}
					if (isoText.equalsIgnoreCase("yes")) {
						WebAction.click(iso_Yes);
					} else {
						WebAction.click(iso_No);
					}
					if (controlRoomCrewText != null) {
						producerDashboardGeneralPage.addControlRoomCrew(controlRoomCrewText);
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public By getBy(String name) {
		if (name.equals("sectionStatusIconsBy")) {
			return By.xpath("//*[@sectionTitle]//*[contains(@class,'button-section')]//i");
		} else if (name.equals("sectionNamesHavingStatusIconBy")) {
			return By.xpath("//*[@sectionTitle]//*[contains(@class,'button-section')]//i"
					+ "/ancestor::*[@class='button-section']/following::*[contains(@class,'status-title-area')]//p");
		} else if (name.equals("dropdownOptionsBy")) {
			return By.xpath("//*[contains(@class,'ant-select-item') and text()]");
		} else if (name.equals("budgetCodeInputBy")) {
			return By.xpath("(//*[contains(text(),' Budget Code ')])[2]/following::input[1]");
		} else if (name.equals("doYouNeedIsoRecordingsLabelBy")) {
			return By.xpath("//*[contains(text(),' ISO: Do you need ISO recordings? ')]");
		} else if (name.equals("doYouNeedContentToBeRecordedLabelBy")) {
			return By.xpath("//*[contains(text(),' Ingest: Do you need content to be recorded? ')]");
		} else if (name.equals("controlRoomCrewLabelBy")) {
			return By.xpath("//label[contains(text(),' Control Room Crew ')]");
		} else if (name.equals("controlRoomCrewInputBy")) {
			return By.xpath("//label[contains(text(),' Control Room Crew ')]/../following::input[1]");
		} else if (name.equals("controlRoomRecordsLabelBy")) {
			return By.xpath("//label[contains(text(),' - Control Room ')]");
		} else if (name.equals("controlRoomRecordsInputsBy")) {
			return By.xpath("//label[contains(text(),' - Control Room ')]/../following::input[1]");
		} else if (name.equals("addControlRoomButtonBy")) {
			return By.xpath("//*[text()=' Control Room ']/ancestor::button");
		}
		Assert.fail(String.format("Cannot find By locator for '%s'", name));
		return By.xpath("");
	}

	public void verifyIfControlRoomCrewSectionAndRelatedFieldsShouldDisplayOrNot() throws Exception {
		producerDashboardGeneralPage.waitForLoadingSpinnerToDisappear();
		String yesOrNo = Constants.getIsAControlRoomNeeded();
		WebDriver driver = DriverFactory.getCurrentDriver();
		if (yesOrNo.equalsIgnoreCase("Yes")) {
			Boolean allFieldsAreDisplayed = true;
			List<WebElement> controlRoomRecordsLabels = driver.findElements(getBy("controlRoomRecordsLabelBy"));
			if (controlRoomRecordsLabels.size() == 0) {
				Assert.assertTrue(false, "'x - Control Room' field is not displaying. " + "It should.");
				allFieldsAreDisplayed = false;
			}
			List<WebElement> controlRoomRecordsInputs = driver.findElements(getBy("controlRoomRecordsInputsBy"));
			if (controlRoomRecordsInputs.size() == 0) {
				Assert.assertTrue(false, "'x - Control Room' input field is not displaying. " + "It should.");
				allFieldsAreDisplayed = false;
			}
			List<WebElement> doYouNeedContentToBeRecordedLabel = driver
					.findElements(getBy("doYouNeedContentToBeRecordedLabelBy"));
			if (doYouNeedContentToBeRecordedLabel.size() == 0) {
				Assert.assertTrue(false,
						"'Ingest: Do you need content to be recorded?' field is not displaying. " + "It should.");
				allFieldsAreDisplayed = false;
			}
			List<WebElement> doYouNeedIsoRecordingsLabel = driver.findElements(getBy("doYouNeedIsoRecordingsLabelBy"));
			if (doYouNeedIsoRecordingsLabel.size() == 0) {
				Assert.assertTrue(false, "'ISO: Do you need ISO recordings?' field is not displaying. It should.");
				allFieldsAreDisplayed = false;
			}
			List<WebElement> controlRoomCrewLabel = driver.findElements(getBy("controlRoomCrewLabelBy"));
			if (controlRoomCrewLabel.size() == 0) {
				Assert.assertTrue(false, "'Control Room Crew' field is not displaying. It should.");
				allFieldsAreDisplayed = false;
			}
			List<WebElement> controlRoomCrewInput = driver.findElements(getBy("controlRoomCrewInputBy"));
			if (controlRoomCrewInput.size() == 0) {
				Assert.assertTrue(false, "'Control Room Crew Input' field is not displaying. It should.");
				allFieldsAreDisplayed = false;
			}
			if (allFieldsAreDisplayed) {
				Assert.assertTrue(allFieldsAreDisplayed);
			}
		} else if (yesOrNo.equalsIgnoreCase("No")) {
			Boolean allFieldsAreHidden = true;
			List<WebElement> controlRoomRecordsLabels = driver.findElements(getBy("controlRoomRecordsLabelBy"));
			if (controlRoomRecordsLabels.size() >= 1) {
				Assert.assertFalse(true, "'x - Control Room' field is displaying. " + "It should not.");
				allFieldsAreHidden = false;
			}
			List<WebElement> controlRoomRecordsInputs = driver.findElements(getBy("controlRoomRecordsInputsBy"));
			if (controlRoomRecordsInputs.size() >= 1) {
				Assert.assertFalse(true, "'x - Control Room' input field is displaying. " + "It should not.");
				allFieldsAreHidden = false;
			}
			List<WebElement> addControlRoomButton = driver.findElements(getBy("addControlRoomButtonBy"));
			if (addControlRoomButton.size() == 1) {
				Assert.assertFalse(true, "'+ Control Room' button is displaying. " + "It should not.");
				allFieldsAreHidden = false;
			}
			List<WebElement> doYouNeedContentToBeRecordedLabel = driver.findElements(getBy("addControlRoomButtonBy"));
			if (doYouNeedContentToBeRecordedLabel.size() >= 1) {
				Assert.assertFalse(true,
						"'Ingest: Do you need content to be recorded?' field is displaying. " + "It shoud not.");
				allFieldsAreHidden = false;
			}
			List<WebElement> doYouNeedIsoRecordingsLabel = driver.findElements(getBy("doYouNeedIsoRecordingsLabelBy"));
			if (doYouNeedIsoRecordingsLabel.size() >= 1) {
				Assert.assertFalse(true, "'ISO: Do you need ISO recordings?' field is displaying. It should not.");
				allFieldsAreHidden = false;
			}
			List<WebElement> controlRoomCrewLabel = driver.findElements(getBy("controlRoomCrewLabelBy"));
			if (controlRoomCrewLabel.size() >= 1) {
				Assert.assertFalse(true, "'Control Room Crew' field is displaying. It should not.");
				allFieldsAreHidden = false;
			}
			List<WebElement> controlRoomCrewInput = driver.findElements(getBy("controlRoomCrewInputBy"));
			if (controlRoomCrewInput.size() >= 1) {
				Assert.assertTrue(true, "'Control Room Crew Input' field is displaying. It should not.");
				allFieldsAreHidden = false;
			}
			if (allFieldsAreHidden) {
				Assert.assertTrue(allFieldsAreHidden);
			}
		}
	}

	public List<WebElement> getRadioLabelElements(String field) {
		if (field.equals("Is Budget Code Available?")) {
			return isBudgetCodeAvailableRadioLabels;
		} else if (field.equals("Is a Control Room Needed?")) {
			return isAControlRoomNeededRadioLabels;
		} else if (field.equals("Ingest: Do you need content to be recorded?")) {
			return ingestDoYouNeedContentToBeRecordedRadioLabels;
		} else if (field.equals("ISO: Do you need ISO recordings?")) {
			return isoDoYouNeedIsoRecordingsRadioLabels;
		}
		return new ArrayList<WebElement>();
	}

	public List<WebElement> getRadioInputElements(String field) {
		if (field.equals("Is Budget Code Available?")) {
			return isBudgetCodeAvailableRadios;
		} else if (field.equals("Is a Control Room Needed?")) {
			return isAControlRoomNeededRadios;
		} else if (field.equals("Ingest: Do you need content to be recorded?")) {
			return ingestDoYouNeedContentToBeRecordedRadios;
		} else if (field.equals("ISO: Do you need ISO recordings?")) {
			return isoDoYouNeedIsoRecordingsRadios;
		}
		return new ArrayList<WebElement>();
	}

	public void selectRadioOption(String field, String option) throws Exception {
		Boolean optionSelected = false;
		List<WebElement> radioLabels = getRadioLabelElements(field);
		for (int i = 0; i < radioLabels.size(); i++) {
			WebElement optionNameElement = radioLabels.get(i);
			String label = WebAction.getText(optionNameElement);
			if (label.equals(option)) {
				WebAction.scrollIntoView(optionNameElement);
				int trials = 3;
				while (trials-- > 0) {
					try {
						optionNameElement.click();
						break;
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				optionSelected = true;
				storeInConstants(field, option);
			}
		}
		Assert.assertTrue(optionSelected, "Option '" + option + "' is not displayed for '" + field + "'");
	}

	public void shouldBudgetCodeInputBeEnabled() {
		WebDriver driver = DriverFactory.getCurrentDriver();
		List<WebElement> budgetCodeInput = driver.findElements(getBy("budgetCodeInputBy"));
		if (budgetCodeInput.size() == 0 || budgetCodeInput.size() > 1) {
			Assert.assertEquals(budgetCodeInput.size(), 1, "Either 0 or more than 1 inputs for Budget Code label");
		} else {
			WebElement input = budgetCodeInput.get(0);
			String selectedOption = Constants.getIsBudgetCodeAvailable();
			if (selectedOption.equalsIgnoreCase("Available") && !input.isEnabled()) {
				Assert.assertEquals("Disabled", "Enabled", "Budget Code input is disabled but it should be enabled");
			} else if (selectedOption.equalsIgnoreCase("Will Provide") && input.isEnabled()) {
				Assert.assertEquals("Enabled", "Disabled", "Budget Code input is enabled but it should be disabled");
			}
		}
	}

	public void verifyTheFormSectionsInCnbcProductionForm() {
		Object[] expectedHeaders = { "STATUS", "GENERAL DETAILS", "REQUESTER(S)", "TALENT", "PRODUCTION PURPOSE",
				"SHOW INFO", "SET LOCATION", "SET CREW", "STAGING", "CONTROL ROOM" };
		String isControlRoomNeeded = Constants.getIsAControlRoomNeeded();
		if (isControlRoomNeeded != null && isControlRoomNeeded.equalsIgnoreCase("Yes")) {
			List<Object> list = new ArrayList<Object>(Arrays.asList(expectedHeaders));
			list.add("CONTROL ROOM CREW");
			expectedHeaders = list.toArray();
		}
		if (expectedHeaders.length != formSectionTitles.size()) {
			Assert.assertEquals(formSectionTitles.size(), expectedHeaders.length,
					"Total number of sections " + "are not the same as expected");
		} else {
			boolean allFormSectionsArePresent = true;
			for (int itr = 0; itr < expectedHeaders.length; itr++) {
				String expectedName = (String) expectedHeaders[itr];
				String displayedName = WebAction.getText(formSectionTitles.get(itr));
				if (!expectedName.equals(displayedName)) {
					allFormSectionsArePresent = false;
					Assert.assertEquals(displayedName, expectedName,
							"Expected section name is not same as " + "displayed name");
				}
			}
			Assert.assertTrue(allFormSectionsArePresent,
					"All expected sections are not present on " + "CNBC Production form");
		}
	}

	public void checkFieldsInSectionOfCnbcProduction(String sectionName) {
		List<WebElement> sectionLabelElements = getSectionLabelElements(sectionName);
		if (sectionLabelElements == null) {
			Assert.assertTrue(false, sectionName + " section is not present in CNBC production form");
			return;
		}

		List<String> expectedFieldNamesList = getExpectedFieldsSectionWise(sectionName);
		List<String> expectedRequiredFieldList = getRequiredFieldsSectionWise(sectionName);
		if (sectionLabelElements.size() != expectedFieldNamesList.size()) {
			Assert.assertEquals(sectionLabelElements.size(), expectedFieldNamesList.size(),
					"Number of displayed fields and expected fields not equal in " + sectionName
							+ " section of CNBC Production");
			return;
		}
		for (int itr = 0; itr < expectedFieldNamesList.size(); itr++) {
			String expectedName = expectedFieldNamesList.get(itr);
			String displayedField = WebAction.getText(sectionLabelElements.get(itr));
			Assert.assertEquals(displayedField, expectedName,
					"Displayed field is not same as expected field in " + sectionName + " section of CNBC Production");
			String cssClasses = WebAction.getAttribute(sectionLabelElements.get(itr), "class");
			if (cssClasses.contains(" ant-form-item-required") && !expectedRequiredFieldList.contains(displayedField)) {
				Assert.assertTrue(false, "'" + displayedField + "' is not a required field in " + sectionName
						+ " section but displayed with *(required symbol)");
			} else if (!cssClasses.contains(" ant-form-item-required")
					&& expectedRequiredFieldList.contains(displayedField)) {
				Assert.assertTrue(false, "'" + displayedField + "' is a required field in " + sectionName
						+ " section but not displayed with *(required symbol)");
			}
		}
	}

	public List<WebElement> getSectionLabelElements(String sectionName) {
		if (sectionName.equalsIgnoreCase("GENERAL DETAILS")) {
			return generalDetailsSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("REQUESTER(S)")) {
			return requestersSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("TALENT")) {
			return talentSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("PRODUCTION PURPOSE")) {
			return productionPurposeSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("SHOW INFO")) {
			return showInfoSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("SET LOCATION")) {
			return setLocationSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("SET CREW")) {
			return setCrewSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("STAGING")) {
			return stagingSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("CONTROL ROOM")) {
			return controlRoomSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("CONTROL ROOM CREW")) {
			return controlRoomCrewSectionFieldLabels;
		}
		return null;
	}

	public List<String> getExpectedFieldsSectionWise(String sectionName) {
		List<String> fieldNamesList = new ArrayList<String>();
		if (sectionName.equalsIgnoreCase("GENERAL DETAILS")) {
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Division")));
		} else if (sectionName.equalsIgnoreCase("REQUESTER(S)")) {
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Add Requester(s)")));
		} else if (sectionName.equalsIgnoreCase("TALENT")) {
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Talent")));
		} else if (sectionName.equalsIgnoreCase("PRODUCTION PURPOSE")) {
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Request For", "Details & Notes")));
		} else if (sectionName.equalsIgnoreCase("SHOW INFO")) {
			fieldNamesList.add("Air Platform");
			String division = Constants.getDivision();
			if (division != null && division.equals("CNBC")) {
				fieldNamesList.add("Sub Division");
			}
			fieldNamesList.add("Show Unit or Project Name");
			String showUnitOrProjectName = Constants.getShowUnitOrProjectName();
			if (showUnitOrProjectName != null && showUnitOrProjectName.equalsIgnoreCase("Other")) {
				fieldNamesList.add("Other");
			}
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Is Budget Code Available?", "Budget Code",
					"Start Date", "Call Time", "Start Time", "End Time")));
		} else if (sectionName.equalsIgnoreCase("SET LOCATION")) {
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Location", "Set Location")));
		} else if (sectionName.equalsIgnoreCase("SET CREW")) {
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Set Crew")));
		} else if (sectionName.equalsIgnoreCase("STAGING")) {
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Staging Needs")));
		} else if (sectionName.equalsIgnoreCase("CONTROL ROOM")) {
			List<String> fields = new ArrayList<String>();
			fields.add("Is a Control Room Needed?");
			String yesOrNo = Constants.getIsAControlRoomNeeded();
			if (yesOrNo != null && yesOrNo.equalsIgnoreCase("Yes")) {
				List<String> controlRooms = Constants.getControlRoom();
				int size = controlRooms.size();
				for (int itr = 1; itr <= size; itr++) {
					fields.add(itr + " - Control Room");
				}
			}
			fieldNamesList.addAll(fields);
		} else if (sectionName.equalsIgnoreCase("CONTROL ROOM CREW")) {
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Ingest: Do you need content to be recorded?",
					"ISO: Do you need ISO recordings?", "Control Room Crew")));
		}
		return fieldNamesList;
	}

	public List<String> getRequiredFieldsSectionWise(String sectionName) {
		List<String> fieldNamesList = new ArrayList<String>();
		if (sectionName.equalsIgnoreCase("GENERAL DETAILS")) {
			fieldNamesList.addAll((Arrays.asList("Division")));
		} else if (sectionName.equalsIgnoreCase("REQUESTER(S)") || sectionName.equalsIgnoreCase("TALENT")) {
			fieldNamesList.addAll((Arrays.asList()));
		} else if (sectionName.equalsIgnoreCase("PRODUCTION PURPOSE")) {
			fieldNamesList.addAll((Arrays.asList("Request For")));
		} else if (sectionName.equalsIgnoreCase("SHOW INFO")) {
			fieldNamesList.addAll((Arrays.asList("Air Platform", "Sub Division", "Show Unit or Project Name", "Other",
					"Is Budget Code Available?", "Budget Code", "Start Date", "Start Time", "End Time")));
		} else if (sectionName.equalsIgnoreCase("SET LOCATION")) {
			fieldNamesList.addAll(Arrays.asList("Location"));
		} else if (sectionName.equalsIgnoreCase("SET CREW") || sectionName.equalsIgnoreCase("STAGING")) {
			fieldNamesList.addAll(Arrays.asList());
		} else if (sectionName.equalsIgnoreCase("CONTROL ROOM")) {
			List<String> fields = new ArrayList<String>();
			fields.add("Is a Control Room Needed?");
			fieldNamesList.addAll(fields);
		} else if (sectionName.equalsIgnoreCase("CONTROL ROOM CREW")) {
			fieldNamesList.addAll(Arrays.asList());
		}
		return fieldNamesList;
	}

	public void addControlRoom(int times) {
		WebDriver driver = DriverFactory.getCurrentDriver();
		WebElement addButton = driver.findElement(getBy("addControlRoomButtonBy"));
		while (times-- > 0) {
			scrollIntoView(addButton);
			addButton.click();
			Constants.getControlRoom().add("");
		}
	}

	public void populateProductionPurposeSection(String requestFor, String detailAndNotes) throws Exception {
		selectValueInDropdown(requestFor, "Request For");
		fillTextbox("Details & Notes", detailAndNotes);
	}

	public void fillTextbox(String field, String text) {
		WebElement element = getTextareaElement(field);
		scrollIntoView(element);
		WebAction.clear(element);
		WebAction.sendKeys(element, text);
		storeInConstants(field, text);
		// verify the placeholder of the the textarea
		String displayed = WebAction.getAttribute(element, "placeholder");
		String expected = getExpectedPlaceholder(field);
		Assert.assertEquals(displayed.trim(), expected, "Placeholder for '" + field + "' textarea is not correct");
	}

	public WebElement getTextareaElement(String fieldName) {
		if (fieldName.equals("Details & Notes")) {
			return detailsAndNotesInput;
		} else if (fieldName.equals("Staging Needs")) {
			return stagingNeedsInput;
		}
		return null;
	}

	public Optional<List<WebElement>> getPlaceholderElementForField(String field) {
		Optional<String> locator = Optional.empty();
		if (field.equals("Division")) {
			locator = Optional.of("//*[text()=' Division ']/../following::*[1]//nz-select-placeholder");
		} else if (field.equals("Request For")) {
			locator = Optional.of("//*[text()=' Request For ']/../following::*[1]//nz-select-placeholder");
		} else if (field.equals("Location")) {
			locator = Optional.of("//*[text()=' Location ']/../following::*[1]//nz-select-placeholder");
		} else if (field.equals("Set Crew")) {
			locator = Optional.of("//*[text()=' Set Crew ']/../following::*[1]//nz-select-placeholder");
		}
		WebDriver driver = getCurrentDriver();
		Optional<List<WebElement>> elementsOptional = locator.isEmpty() ? Optional.empty()
				: Optional.of(driver.findElements(By.xpath(locator.get())));
		return elementsOptional;
	}

	public String getExpectedPlaceholder(String field) {
		if (field.equals("Division")) {
			return "Select Division";
		} else if (field.equals("Request For")) {
			return "Select Request For";
		} else if (field.equals("Location")) {
			return "Select Location";
		} else if (field.equals("Set Crew")) {
			return "Select Set Crew";
		} else if (field.equals("Details & Notes")) {
			return "Add Details and Notes";
		} else if (field.equals("Staging Needs")) {
			return "Add Staging Needs";
		}
		return "";
	}

	public void checkPlaceholderOfSelectFields(String fieldName) {
		Optional<List<WebElement>> placeholderElementOptional = getPlaceholderElementForField(fieldName);
		Assert.assertFalse(placeholderElementOptional.isEmpty(),
				String.format("xpath locator for placeholder of field '%s' is not specified", fieldName));
		String requestForValue = Constants.getRequestFor();
		if (requestForValue == null) {
			Assert.assertFalse(placeholderElementOptional.get().size() == 0,
					String.format("Placeholder for '%s' field is not present", fieldName));
			String displayed = WebAction.getText(placeholderElementOptional.get().get(0));
			String expected = getExpectedPlaceholder(fieldName);
			Assert.assertEquals(displayed, expected,
					String.format("Placeholder for '%s' field is not correct", fieldName));
		} else {
			Assert.assertTrue(placeholderElementOptional.get().size() == 0,
					String.format("Placeholder for '%s' field should not display if value is selected", fieldName));
		}
	}

	public String getExpectedErrorMessageForRequiredField(String field) {
		if (field.equals("Division")) {
			return "Select a value";
		} else if (field.equals("Request For")) {
			return "Select a value";
		} else if (field.equals("Location")) {
			return "Select a value";
		}
		return "";
	}

	public Optional<List<WebElement>> getErrorElementForField(String field) {
		Optional<String> locator = Optional.empty();
		if (field.equals("Division")) {
			locator = Optional.of(
					"//*[text()=' Division ']/../following::*[1]//*[contains(@class,'ant-form-item-explain-error')]");
		} else if (field.equals("Request For")) {
			locator = Optional.of(
					"//*[text()=' Request For ']/../following::*[1]//*[contains(@class,'ant-form-item-explain-error')]");
		} else if (field.equals("Location")) {
			locator = Optional.of(
					"//*[text()=' Location ']/../following::*[1]//*[contains(@class,'ant-form-item-explain-error')]");
		}
		WebDriver driver = getCurrentDriver();
		Optional<List<WebElement>> elementsOptional = locator.isEmpty() ? Optional.empty()
				: Optional.of(driver.findElements(By.xpath(locator.get())));
		return elementsOptional;
	}

	public void verifyErrorBelowFieldIfEmpty(String fieldName) {
		Optional<List<WebElement>> elementsOptional = getErrorElementForField(fieldName);
		Assert.assertEquals(elementsOptional.isPresent(), true,
				String.format("xpath locator for error below '%s' field is not specified", fieldName));
		Assert.assertFalse(elementsOptional.get().size() == 0,
				String.format("Error text for '%s' required field is not present", fieldName));
		WebElement element = elementsOptional.get().get(0);
		scrollIntoView(element);
		String displayed = getText(element);
		String expected = getExpectedErrorMessageForRequiredField(fieldName);
		Assert.assertEquals(displayed, expected,
				String.format("Error text for '%s' required field is not correct", fieldName));
	}

	public void verifyErrorBelowFieldIfNotEmpty(String fieldName) {
		Optional<List<WebElement>> elementsOptional = getErrorElementForField(fieldName);
		Assert.assertEquals(elementsOptional.isPresent(), true,
				String.format("xpath locator for error below '%s' field is not specified", fieldName));
		Assert.assertTrue(elementsOptional.get().size() == 0,
				String.format("Error text for '%s' required field should not display", fieldName));
	}

	public void checkIfSectionIsChecked(String sectionName) {
		WebDriver driver = getCurrentDriver();
		List<WebElement> sectionNamesHavingStatusIcon = driver.findElements(getBy("sectionNamesHavingStatusIconBy"));
		List<WebElement> sectionStatusIcons = driver.findElements(getBy("sectionStatusIconsBy"));
		if (sectionNamesHavingStatusIcon.size() == sectionStatusIcons.size()) {
			for (int itr = 0; itr < sectionNamesHavingStatusIcon.size(); ++itr) {
				String displayedSectionName = WebAction.getText(sectionNamesHavingStatusIcon.get(itr));
				if (displayedSectionName.equalsIgnoreCase(sectionName)) {
					String cssClass = WebAction.getAttribute(sectionStatusIcons.get(itr), "class");
					Assert.assertTrue(cssClass.contains("anticon-check"), "'" + sectionName + "' is not checked");
				}
			}
		}
	}

	public void checkIfSectionIsCrossed(String sectionName) {
		WebDriver driver = getCurrentDriver();
		List<WebElement> sectionNamesHavingStatusIcon = driver.findElements(getBy("sectionNamesHavingStatusIconBy"));
		List<WebElement> sectionStatusIcons = driver.findElements(getBy("sectionStatusIconsBy"));
		if (sectionNamesHavingStatusIcon.size() == sectionStatusIcons.size()) {
			for (int itr = 0; itr < sectionNamesHavingStatusIcon.size(); ++itr) {
				String displayedSectionName = WebAction.getText(sectionNamesHavingStatusIcon.get(itr));
				if (displayedSectionName.equalsIgnoreCase(sectionName)) {
					String cssClass = WebAction.getAttribute(sectionStatusIcons.get(itr), "class");
					Assert.assertTrue(cssClass.contains("anticon-close"), "'" + sectionName + "' is not crossed");
				}
			}
		}
	}

	public void checkIfSectionIsNeitherCheckedNorCrossed(String sectionName) {
		WebDriver driver = getCurrentDriver();
		List<WebElement> sectionNamesHavingStatusIcon = driver.findElements(getBy("sectionNamesHavingStatusIconBy"));
		List<WebElement> sectionStatusIcons = driver.findElements(getBy("sectionNamesHavingStatusIconBy"));
		if (sectionNamesHavingStatusIcon.size() == sectionStatusIcons.size()) {
			for (int itr = 0; itr < sectionNamesHavingStatusIcon.size(); ++itr) {
				String displayedSectionName = WebAction.getText(sectionNamesHavingStatusIcon.get(itr));
				if (displayedSectionName.equalsIgnoreCase(sectionName)) {
					String cssClass = WebAction.getAttribute(sectionStatusIcons.get(itr), "class");
					Assert.assertTrue(
							cssClass.contains("anticon-") && !cssClass.contains("anticon-close")
									&& !cssClass.contains("anticon-check"),
							"'" + sectionName + "' is either checked or crossed");
				}
			}
		}
	}

	public WebElement getDropdownElement(String fieldName) {
		WebDriver driver = getCurrentDriver();
		if (fieldName.equals("Location")) {
			return locationInput;
		} else if (fieldName.equals("Division")) {
			return divisionInput;
		} else if (fieldName.equals("Request For")) {
			return requestForInput;
		} else if (fieldName.equals("Set Crew")) {
			return setCrewInput;
		} else if (fieldName.equals("Show Unit or Project Name")) {
			return showUnitOrProjectNameInput;
		} else if (fieldName.equals("Control Room Crew")) {
			return driver.findElement(getBy("controlRoomCrewInputBy"));
		}
		return null;
	}

	public void storeInConstants(String fieldName, Object option) {
		if (fieldName.equals("Location")) {
			Constants.getLocation().add(new LocationRecord((String) option, "", ""));
		} else if (fieldName.equals("Request For")) {
			Constants.setRequestFor((String) option);
		} else if (fieldName.equals("Division")) {
			Constants.setDivision((String) option);
		} else if (fieldName.equals("Set Crew")) {
			Constants.getSetCrew().add(new CrewRecord((String) option, 0));
		} else if (fieldName.equals("Details & Notes")) {
			Constants.setDetailsAndNotes((String) option);
		} else if (fieldName.equals("Staging Needs")) {
			Constants.setStagingNeeds((String) option);
		} else if (fieldName.equals("Show Unit or Project Name")) {
			Constants.setShowUnitOrProjectName((String) option);
		} else if (fieldName.equals("Is a Control Room Needed?")) {
			String val = (String) option;
			Constants.setIsAControlRoomNeeded(val);
			if (val.equalsIgnoreCase("Yes")) {
				Constants.getControlRoom().add("1 - Control Room");
			} else if (val.equalsIgnoreCase("No")) {
				Constants.getControlRoom().clear();
			}
		} else if (fieldName.equals("Is Budget Code Available?")) {
			Constants.setIsBudgetCodeAvailable((String) option);
		} else if (fieldName.equals("Ingest: Do you need content to be recorded?")) {
			Constants.setIngestDoYouNeedContentToBeRecorded((String) option);
		} else if (fieldName.equals("ISO: Do you need ISO recordings?")) {
			Constants.setIsoDoYouNeedIsoRecordings((String) option);
		} else if (fieldName.equals("Control Room Crew")) {
			Constants.getControlRoomCrew().add(new CrewRecord((String) option, 0));
			;
		}
	}

	public void selectValueInDropdown(String option, String fieldName) {
		try {
			WebDriver driver = getCurrentDriver();
			WebElement input = getDropdownElement(fieldName);
			waitForElement(input, WAIT_CONDITIONS.VISIBLE);
			scrollIntoView(input);
			try {
				WebAction.click(input);
			} catch (Exception e) {
				input.sendKeys(Keys.ENTER);
			}
			By dropdownOptionsBy = getBy("dropdownOptionsBy");
			waitForElement(dropdownOptionsBy, WAIT_CONDITIONS.VISIBLE);
			List<WebElement> options = driver.findElements(dropdownOptionsBy);
			Optional<WebElement> optional = options.stream()
					.filter((WebElement divisionOption) -> getText(divisionOption).equals(option)).findAny();
			if (optional.isPresent()) {
				WebElement optionToSelect = optional.get();
				scrollIntoView(optionToSelect);
				click(optionToSelect);
				storeInConstants(fieldName, option);
			} else {
				Assert.assertTrue(false,
						"'" + option + "' is not present as an option in '" + fieldName + "' on CNBC production form");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Error while selecting '" + option + "' in '" + fieldName + "' on CNBC Production form");
		}
	}

	/**
	 * To verify values in the cnbc form are present in production dashboard columns
	 * 
	 * @throws Exception
	 */
	public void verifyCNBCRequestValuesWithProductionDashboardValues(String additionalRequestersText,
			String ProdDateText, String ShowProjectText, String ProductionPurposeText, String SetLocationText,
			String ControlRoomText, String PositionsText, String SubmittedText) throws Exception {
		try {
			String requestNumber = Constants.getRequestNumber();
			String columnCellString = "//a[contains(text(),'<<RequestId>>')]/ancestor::tr/td[contains(@class,'<<ColumnType>>')]";
			producerDashboardGeneralPage.verifyStatusColorBaseOnProductionDateInDashboard(requestNumber,
					columnCellString);
			verifyDefaultRequesterInCNBCDashboard(requestNumber, columnCellString);
			producerDashboardGeneralPage.verifyAdditionalRequesterInDashboard(additionalRequestersText, requestNumber,
					columnCellString);
			producerDashboardGeneralPage.verifyProdDateInDashboard(ProdDateText, requestNumber, columnCellString);
			producerDashboardGeneralPage.verifyShowProjectInDashboard(ShowProjectText, requestNumber, columnCellString);
			producerDashboardGeneralPage.verifyProductionPurposeInDashboard(ProductionPurposeText, requestNumber,
					columnCellString);
			verifySetLocationInCNBCDashboard(SetLocationText, requestNumber, columnCellString);
			producerDashboardGeneralPage.verifyControlRoomInDashboard(ControlRoomText, requestNumber, columnCellString);
			verifyPositionsColumnInCNBCDashboard(PositionsText, requestNumber, columnCellString);
			producerDashboardGeneralPage.verifySubmittedInDashboard(SubmittedText, requestNumber, columnCellString);
			producerDashboardGeneralPage.verifyActionsColumnInDashboard(requestNumber, columnCellString);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void verifyPositionsColumnInCNBCDashboard(String PositionsText, String requestNumber,
			String columnCellString) {
		if (PositionsText != null) {
			String[] positionsTextArrayList;
			positionsTextArrayList = PositionsText.split("-");
			String columnTypeText = "position";
			String columnCellTypeText = columnCellString.replace("<<RequestId>>", requestNumber)
					.replace("<<ColumnType>>", columnTypeText);
			String setCrewText = positionsTextArrayList[0];
			String controlRoomCrewText = positionsTextArrayList[1];

			// To validate set crew
			String SetCrewArrayList[] = null;
			if (setCrewText != null) {
				if (setCrewText.contains(",")) {
					SetCrewArrayList = setCrewText.split(",");
				} else {
					SetCrewArrayList = setCrewText.split(" ");
				}
				for (int i = 0; i < SetCrewArrayList.length; i++) {
					switch (SetCrewArrayList[i].toUpperCase()) {
					case "HAIR STYLIST":
						SetCrewArrayList[i] = "HAIR";
						break;
					case "MAKEUP ARTIST":
						SetCrewArrayList[i] = "MU";
						break;
					}
				}
				for (String SetCrewArray : SetCrewArrayList) {
					String updatedColumnCellTypeText = columnCellTypeText + "/div/div[1]";
					producerDashboardGeneralPage.verifyExpectedValueInFormWithActualValueInDashboard(
							updatedColumnCellTypeText, SetCrewArray);
				}
			}
			// To validate control room crew
			if (controlRoomCrewText != null) {
				String controlRoomCrewArrayList[] = null;
				if (controlRoomCrewText.contains(",")) {
					controlRoomCrewArrayList = controlRoomCrewText.split(",");
				} else {
					controlRoomCrewArrayList = controlRoomCrewText.split(" ");
				}

				for (String controlRoomCrewArray : controlRoomCrewArrayList) {
					String updatedColumnCellTypeText = columnCellTypeText + "/div/div[2]";
					producerDashboardGeneralPage.verifyExpectedValueInFormWithActualValueInDashboard(
							updatedColumnCellTypeText, controlRoomCrewArray);
				}
			}

		}
	}

	public void verifyDefaultRequesterInCNBCDashboard(String requestNumber, String columnCellString) {
		String columnTypeText;
		// To validate default requester
		String defaultRequesterName = Constants.getDefaultRequesterName();
		columnTypeText = "modifiedBy";
		String defaultRequesterNamecolumnCellTypeText = columnCellString.replace("<<RequestId>>", requestNumber)
				.replace("<<ColumnType>>", columnTypeText);
		String defaultRequesterNameTextIndashboard = defaultRequesterNamecolumnCellTypeText.concat("//div");
		producerDashboardGeneralPage.verifyExpectedValueInFormWithActualValueInDashboard(
				defaultRequesterNameTextIndashboard, defaultRequesterName);
	}

	public void verifySetLocationInCNBCDashboard(String SetLocationText, String requestNumber, String columnCellString)
			throws Exception, InterruptedException {
		String columnTypeText;
		// To validate set location
		if (SetLocationText != null) {
			columnTypeText = "setLocation";
			String columnCellTypeText = columnCellString.replace("<<RequestId>>", requestNumber)
					.replace("<<ColumnType>>", columnTypeText);
			String[] SetLocationArrayList;
			if (SetLocationText.contains(",")) {
				SetLocationArrayList = SetLocationText.split(",");
				String SetLocationArrayListTextIndashboard = columnCellTypeText.concat("/div/div/span");
				WebElement SetLocationArrayListWebelement = driver
						.findElement(By.xpath(SetLocationArrayListTextIndashboard));
				Waits.waitForElement(SetLocationArrayListWebelement, WAIT_CONDITIONS.VISIBLE);
				Thread.sleep(1000);
				WebAction.click(SetLocationArrayListWebelement);
				String locationNamesXpath = "(//div[contains(@class,'popover')])[last()]/div[<<locationNo>>]";
				for (int i = 0; i < SetLocationArrayList.length; i++) {
					String locationNamesNewXpath = locationNamesXpath.replace("<<locationNo>>",
							Integer.toString(i + 1));
					producerDashboardGeneralPage.verifyExpectedValueInFormWithActualValueInDashboard(
							locationNamesNewXpath, SetLocationArrayList[i]);
				}
			} else {
				SetLocationArrayList = SetLocationText.split(" ");
				String SetLocationArrayListTextIndashboard = columnCellTypeText.concat("/div/div");
				producerDashboardGeneralPage.verifyExpectedValueInFormWithActualValueInDashboard(
						SetLocationArrayListTextIndashboard, SetLocationArrayList[0]);
			}
		}
	}

}