package nbcu.automation.ui.pojos.ncxUnifiedTool;

public class CrewRecord {
	private String crewName;
	private Integer number;
	
	public CrewRecord(String crewName,Integer number) {
		super();
		this.crewName=crewName;
		this.number=number;
	}
	public CrewRecord() {
	}

	public String getCrewName() {
		return crewName;
	}

	public void setCrewName(String crewName) {
		this.crewName = crewName;
	}

	public Integer getNumber() {
		return number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}

	@Override
	public String toString() {
		return "CrewRecord [crewName=" + crewName + ", number=" + number + "]";
	}
}
