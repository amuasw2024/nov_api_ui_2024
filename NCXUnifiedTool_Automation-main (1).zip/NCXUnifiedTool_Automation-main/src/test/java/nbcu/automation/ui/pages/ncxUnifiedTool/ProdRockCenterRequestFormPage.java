
package nbcu.automation.ui.pages.ncxUnifiedTool;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import nbcu.automation.ui.constants.ncxUnifiedTool.Constants;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;
import nbcu.framework.utils.ui.Waits;
import nbcu.framework.utils.ui.WebAction;

public class ProdRockCenterRequestFormPage {

	ProducerDashboardGeneralPage producerDashboardGeneralPage = new ProducerDashboardGeneralPage();

	@FindBy(xpath = "//div[contains(text(),'Ultimatte')]/ancestor::div[1]//input")
	WebElement ultimatteInputbox;

	@FindBy(xpath = "//div[contains(text(),'Voice Activated Prompter')]/ancestor::div[1]//input")
	WebElement vapInputbox;

	@FindBy(xpath = "//*[@forminputname='isStagingNeeded']//label[@label-value='false']")
	WebElement isStagingNeeded_No;

	@FindBy(xpath = "//*[@forminputname='isStagingNeeded']//label[@label-value='true']")
	WebElement isStagingNeeded_Yes;

	@FindBy(xpath = "//*[@forminputname='isCarpentryNeeded']//label[@label-value='true']")
	WebElement isCarpentryNeeded_Yes;

	@FindBy(xpath = "//*[@forminputname='isCarpentryNeeded']//label[@label-value='false']")
	WebElement isCarpentryNeeded_No;

	@FindBy(xpath = "//*[@forminputname='isLightingNeeded']//label[@label-value='true']")
	WebElement isLightingNeeded_Yes;

	@FindBy(xpath = "//*[@forminputname='isLightingNeeded']//label[@label-value='false']")
	WebElement isLightingNeeded_No;

	@FindBy(xpath = "//*[@forminputname='isPropsNeeded']//label[@label-value='true']")
	WebElement isPropsNeeded_Yes;

	@FindBy(xpath = "//*[@forminputname='isPropsNeeded']//label[@label-value='false']")
	WebElement isPropsNeeded_No;

	String dropDownvaluesXpath = "//div[@class='cdk-virtual-scroll-content-wrapper']/nz-option-item";

	@FindBy(xpath = "//div[@class='cdk-virtual-scroll-content-wrapper']/nz-option-item | //nz-option-item")
	List<WebElement> dropDownvalues;

	@FindBy(xpath = "//*[@label='Additional Crew']//nz-select//input")
	WebElement additionalCrew;

	@FindBy(xpath = "//*[@label='Set Location']//input")
	WebElement setLocationDropDown;

	@FindBy(xpath = "//*[@label='Location']//input")
	WebElement locationDropDown;

	@FindBy(xpath = "//*[@sectionTitle]//*[contains(@class,'status-title-area')]//p")
	List<WebElement> formSectionTitles;

	@FindBy(xpath = "//*[@sectiontitle='Show Info']//nz-form-label//label")
	List<WebElement> showInfoSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='General Details']//nz-form-label//label")
	List<WebElement> generalDetailsSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='Requester(s)']//nz-form-label//label")
	List<WebElement> requestersSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='Talent']//nz-form-label//label")
	List<WebElement> talentSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='Production Purpose']//nz-form-label//label")
	List<WebElement> productionPurposeSectionFieldLabels;

	@FindBy(xpath = "//*[contains(@class,'location-items')]//label")
	List<WebElement> setLocationSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='Set Crew']//nz-form-label//label")
	List<WebElement> setCrewSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='Staging']//nz-form-label//label")
	List<WebElement> stagingSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='Control Room']//nz-form-label//label")
	List<WebElement> controlRoomSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='Control Room CREW']//nz-form-label//label")
	List<WebElement> controlRoomCrewSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='TPM / TM Information']//nz-form-label//label")
	List<WebElement> TPMTMInfoSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='Additional Crew']//nz-form-label//label")
	List<WebElement> additionalCrewSectionFieldLabels;

	@FindBy(xpath = "//*[@class='crew-member-title']/div[contains(@class,'title')]")
	List<WebElement> systemsSectionFieldLabels;

	@FindBy(xpath = "//*[@emptylistmessage='No Requesters Selected']//*[@nztype='link']")
	List<WebElement> additionalRequestersDisplayed;

	@FindBy(xpath = "//*[@class='display-container']//div[@class='ant-col ant-col-xs-10']")
	List<WebElement> AdditionalTalent;

	@FindBy(xpath = "//*[@forminputname='tpmTmName']//input")
	WebElement tpmTmName;

	@FindBy(xpath = "//*[@forminputname='tpmOrTm']//label[@label-value='Yes']")
	WebElement tpmOrTm_Yes;

	@FindBy(xpath = "//*[@forminputname='tpmOrTm']//label[@label-value='No']")
	WebElement tpmOrTm_No;

	@FindBy(xpath = "//*[contains(text(),'Same as requester')]")
	WebElement sameAsRequesterCheckBox;

	@FindBy(xpath = "//p[contains(text(),'TPM / TM INFORMATION')]")
	WebElement tpmOrTmSection;

	@FindBy(xpath = "//p[contains(text(),'SET LOCATION')] | //p[contains(text(),'SET LOCATION & CREW')]")
	WebElement setLocationSection;

	@FindBy(xpath = "(//*[@placeholder='Enter address here'])[1]")
	WebElement locationAddressInputBox;

	@FindBy(xpath = "//*[@label='Control Room Location']//input")
	WebElement controlRoomLocationDropDown;

	@FindBy(xpath = "//*[@label='Control Room']//input")
	WebElement controlRoomDropDown;

	@FindBy(xpath = "(//*[@placeholder='Enter address here'])[2]")
	WebElement controlRoomAddressInputBox;

	@FindBy(xpath = "//*[@forminputname='isStagingNeeded']//label")
	List<WebElement> stagingButtons;

	@FindBy(xpath = "//*[@forminputname='isLightingNeeded']//label")
	List<WebElement> lightingButtons;

	@FindBy(xpath = "//*[@forminputname='isCarpentryNeeded']//label")
	List<WebElement> carpentryButtons;

	@FindBy(xpath = "//*[@forminputname='isPropsNeeded']//label")
	List<WebElement> propsButtons;

	@FindBy(xpath = "//*[text()='FLASHCAM CREW']")
	WebElement flashcamSection;

	@FindBy(xpath = "//phase-two-container[@class='ng-star-inserted'][4]")
	List<WebElement> flashcamCrewoSectionFieldLabels;

	public ProdRockCenterRequestFormPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify control room section missing field error message
	 *
	 * @throws Exception
	 */
	public void verifyControlRoomMissingFieldError(String controlRoomLocationErrorMessage,
			String controlRoomErrorMessage) throws Exception {
		WebAction.scrollIntoView(producerDashboardGeneralPage.controlRoomSection);
		try {
			producerDashboardGeneralPage.controlRoomLocationErrorMessage(controlRoomLocationErrorMessage);
			producerDashboardGeneralPage.controlRoomErrorMessage(controlRoomErrorMessage);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void addControlRoomInfoInRockcenter(String controlRoomLocationText, String controlRoomText)
			throws Exception {
		try {
			if (Constants.getLocations().toUpperCase().contains("NONE")) {
				WebAction.scrollIntoView(producerDashboardGeneralPage.setLocationSection);
			} else {
				WebAction.scrollIntoView(producerDashboardGeneralPage.setCrewSection);
			}
			producerDashboardGeneralPage.addControlRoomLocation(controlRoomLocationText);
			producerDashboardGeneralPage.addControlRoom(controlRoomText, controlRoomLocationText);
			Constants.setControlRoomLocation(controlRoomLocationText);
			ProducerDashboardGeneralPage.emailCCList.add(ConfigFileReader.getProperty("prodreq-controlroom-"+controlRoomLocationText.toLowerCase(),"emailconfig.properties"));
			
		}

		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void selectControlRoomCrew(String captureManagerText, String controlRoomCrewText) throws Exception {
		// To select control room crew
		// WebAction.scrollIntoView(producerDashboardGeneralPage.controlRoomSection);
		if (!(Constants.getControlRoomLocation().toUpperCase().contains("NO CONTROL ROOM"))) {
			try {
				producerDashboardGeneralPage.selectCaptureManager(captureManagerText);
				producerDashboardGeneralPage.addControlRoomCrew(controlRoomCrewText);
			} catch (

			Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
	}

	public void selectAdditionalCrew(String additionalCrewText) throws Exception {
		if (Constants.getControlRoomLocation().toUpperCase().contains("NO CONTROL ROOM")) {
			WebAction.scrollIntoView(producerDashboardGeneralPage.controlRoomSection);
		} else {
			WebAction.scrollIntoView(producerDashboardGeneralPage.controlRoomCrewSection);
		}
		try {
			WebAction.clickUsingJs(additionalCrew);
			if (additionalCrewText != null) {
				if (additionalCrewText.contains(",")) {
					String additionalCrewArrayList[] = additionalCrewText.split(",");
					for (String enterAdditionalCrew : additionalCrewArrayList) {
						WebAction.sendKeys(additionalCrew, enterAdditionalCrew);
						Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
						for (WebElement ele : dropDownvalues) {
							if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(enterAdditionalCrew)) {
								WebAction.click(ele);
								String enterAdditionalCrewTxt = enterAdditionalCrew.replace(" ","");
								ProducerDashboardGeneralPage.emailCCList.add(ConfigFileReader.getProperty("prodreq-additionalcrew-"+enterAdditionalCrewTxt.toLowerCase(),"emailconfig.properties"));
								
								break;
							}
						}
					}
				} else {
					WebAction.sendKeys(additionalCrew, additionalCrewText);
					Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
					for (WebElement ele : dropDownvalues) {
						if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(additionalCrewText)) {
							WebAction.click(ele);
							String enterAdditionalCrewTxt = additionalCrewText.replace(" ","");
							ProducerDashboardGeneralPage.emailCCList.add(ConfigFileReader.getProperty("prodreq-additionalcrew-"+enterAdditionalCrewTxt.toLowerCase(),"emailconfig.properties"));
							
							break;
						}
					}
				}
				WebAction.clickUsingJs(producerDashboardGeneralPage.additionalCrewSection);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void addingAdditionalCrew(String additionalCrewText) throws Exception {
		WebAction.scrollIntoView(producerDashboardGeneralPage.additionalCrewSection);
		try {
			String[] additionalCrewArrayList = null;
			if (additionalCrewText != null) {
				if (additionalCrewText.contains(",")) {
					additionalCrewArrayList = additionalCrewText.split(",");
				} else {
					additionalCrewArrayList = additionalCrewText.split(" ");
				}
				for (String additionalCrewList : additionalCrewArrayList) {
					WebAction.clickUsingJs(additionalCrew);
					Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
					for (WebElement ele : dropDownvalues) {
						if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(additionalCrewList)) {
							WebAction.click(ele);
							break;
						}
					}
					WebAction.clickUsingJs(producerDashboardGeneralPage.additionalCrewSection);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void addtionalCrewSelection(String additionalCrewText) throws Exception {
		WebAction.scrollIntoView(setLocationSection);
		try {
			if (additionalCrewText.contains(",") || additionalCrewText.contains("-"))
				addingAdditionalCrew(additionalCrewText);
			else
				selectAdditionalCrew(additionalCrewText);
			WebAction.clickUsingJs(producerDashboardGeneralPage.additionalCrewSection);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void addSystemInfo(String ultimatteText, String voiceActivatedPrompteText, String notesText)
			throws Exception {
		try {
			WebAction.scrollIntoView(producerDashboardGeneralPage.additionalCrewSection);
			// To select ultimatte
			if (ultimatteText != null) {
				WebAction.clickUsingJs(ultimatteInputbox);
				WebAction.sendKeys(ultimatteInputbox, ultimatteText);

			}
			// To select voiceActivatedPrompte
			if (voiceActivatedPrompteText != null) {
				WebAction.clickUsingJs(vapInputbox);
				WebAction.sendKeys(vapInputbox, voiceActivatedPrompteText);

			}
			producerDashboardGeneralPage.addNotes(notesText);
		}

		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void addStagingInfoInRockCenter(String StagingText, String CarpentryText, String LightingText,
			String PropsText, String DescribeStagingNeedsText) throws Exception {
		try {
			if (StagingText != null) {
				WebAction.scrollIntoView(producerDashboardGeneralPage.systemsSection);

				if (StagingText.equalsIgnoreCase("Yes")) {
					WebAction.click(isStagingNeeded_Yes);
					ProducerDashboardGeneralPage.emailCCList.add(
							ConfigFileReader.getProperty("prodreq-staging","emailconfig.properties"));
					if (CarpentryText.equalsIgnoreCase("Yes"))
						WebAction.click(isCarpentryNeeded_Yes);
					else
						WebAction.click(isCarpentryNeeded_No);

					if (LightingText.equalsIgnoreCase("Yes"))
						WebAction.click(isLightingNeeded_Yes);
					else
						WebAction.click(isLightingNeeded_No);

					if (PropsText.equalsIgnoreCase("Yes"))
						WebAction.click(isPropsNeeded_Yes);
					else
						WebAction.click(isPropsNeeded_No);
				} else
					WebAction.click(isStagingNeeded_No);
			}
			producerDashboardGeneralPage.addDescribeStagingNeeds(DescribeStagingNeedsText);
		} catch (

		Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify sections on the form
	 */
	public void verifyTheFormSectionsInRockCenterForm() {

		Object[] expectedHeaders = { "STATUS", "GENERAL DETAILS", "REQUESTER(S)", "TALENT", "PRODUCTION PURPOSE",
				"SHOW INFO", "SET CREW", "CONTROL ROOM", "CONTROL ROOM CREW", "ADDITIONAL CREW", "SYSTEMS", "STAGING",
				"TPM / TM INFORMATION" };
		if (Constants.getLocations() != null && Constants.getLocations().equals("Telemundo Center")
				&& (Constants.getSetLocations().equals("Newsroom Flashcam")
						|| Constants.getSetLocations().equals("Newsroom Desk"))) {
			List<Object> expectedHeadersList = (Arrays.asList(expectedHeaders));
			expectedHeadersList.add("FLASHCAM CREW");
			expectedHeadersList.remove("SET CREW");
			expectedHeadersList.remove("STAGING");
			expectedHeaders = expectedHeadersList.toArray();
		} else if (Constants.getLocations() != null && Constants.getLocations().equals("None")) {
			List<Object> expectedHeadersList = (Arrays.asList(expectedHeaders));
			expectedHeadersList.remove("SET CREW");
			expectedHeadersList.remove("STAGING");
			expectedHeaders = expectedHeadersList.toArray();
		} else if (Constants.getLocations() != null && Constants.getLocations().equals("Telemundo Center")
				&& (Constants.getSetLocations().equals("Studio"))) {
			List<Object> expectedHeadersList = (Arrays.asList(expectedHeaders));
			expectedHeadersList.add("FLASHCAM CREW");
			expectedHeaders = expectedHeadersList.toArray();
		}

		if (expectedHeaders.length != formSectionTitles.size()) {
			Assert.assertEquals(formSectionTitles.size(), expectedHeaders.length,
					"Total number of sections " + "are not the same as expected");
		} else {
			boolean allFormSectionsArePresent = true;
			for (int itr = 0; itr < expectedHeaders.length; itr++) {
				String expectedName = (String) expectedHeaders[itr];
				String displayedName = WebAction.getText(formSectionTitles.get(itr));
				if (!expectedName.equals(displayedName)) {
					allFormSectionsArePresent = false;
					Assert.assertEquals(displayedName, expectedName,
							"Expected section name is not same as " + "displayed name");
				}
			}
			Assert.assertTrue(allFormSectionsArePresent,
					"All expected sections are not present on " + "Rock Center Production form");
		}
	}

	public void checkFieldsInSectionOfRockCenter(String sectionName) {
		List<WebElement> sectionLabelElements = getSectionLabelElements(sectionName);
		if (sectionLabelElements == null) {
			Assert.assertTrue(false, sectionName + " section is not present in Rock center production form");
			return;
		}

		List<String> expectedFieldNamesList = getExpectedFieldsSectionWise(sectionName);
		List<String> expectedRequiredFieldList = getRequiredFieldsSectionWise(sectionName);
		if (sectionLabelElements.size() != expectedFieldNamesList.size()) {
			Assert.assertEquals(sectionLabelElements.size(), expectedFieldNamesList.size(),
					"Number of displayed fields and expected fields not equal in " + sectionName
							+ " section of Rock center Production");
			return;
		}
		for (int itr = 0; itr < expectedFieldNamesList.size(); itr++) {
			String expectedName = expectedFieldNamesList.get(itr);
			String displayedField = WebAction.getText(sectionLabelElements.get(itr));
			if (displayedField.contains("Prep Time")) {
				displayedField = (displayedField.split(" ")[0] + " " + displayedField.split(" ")[1].trim());
			}
			Assert.assertEquals(displayedField, expectedName, "Displayed field is not same as expected field in "
					+ sectionName + " section of rock center Production");
			String cssClasses = WebAction.getAttribute(sectionLabelElements.get(itr), "class");
			if (cssClasses.contains(" ant-form-item-required") && !expectedRequiredFieldList.contains(displayedField)) {
				Assert.assertTrue(false, "'" + displayedField + "' is not a required field in " + sectionName
						+ " section but displayed with *(required symbol)");
			} else if (!cssClasses.contains(" ant-form-item-required")
					&& expectedRequiredFieldList.contains(displayedField)) {
				Assert.assertTrue(false, "'" + displayedField + "' is a required field in " + sectionName
						+ " section but not displayed with *(required symbol)");
			}
		}
	}

	public List<WebElement> getSectionLabelElements(String sectionName) {
		if (sectionName.equalsIgnoreCase("GENERAL DETAILS")) {
			return generalDetailsSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("REQUESTER(S)")) {
			return requestersSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("TALENT")) {
			return talentSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("PRODUCTION PURPOSE")) {
			return productionPurposeSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("SHOW INFO")) {
			return showInfoSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("SET LOCATION")) {
			return setLocationSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("SET CREW")) {
			return setCrewSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("STAGING")) {
			return stagingSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("CONTROL ROOM")) {
			return controlRoomSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("CONTROL ROOM CREW")) {
			return controlRoomCrewSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("ADDITIONAL CREW")) {
			return additionalCrewSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("SYSTEMS")) {
			return systemsSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("TPM / TM INFORMATION")) {
			return TPMTMInfoSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("FLASHCAM CREW")) {
			return flashcamCrewoSectionFieldLabels;
		}
		return null;
	}

	public List<String> getExpectedFieldsSectionWise(String sectionName) {
		List<String> fieldNamesList = new ArrayList<String>();
		if (sectionName.equalsIgnoreCase("GENERAL DETAILS")) {
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Division")));
		} else if (sectionName.equalsIgnoreCase("REQUESTER(S)")) {
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Add Requester(s)")));
		} else if (sectionName.equalsIgnoreCase("TALENT")) {
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Talent")));
		} else if (sectionName.equalsIgnoreCase("PRODUCTION PURPOSE")) {
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Request For", "Details & Notes")));
		} else if (sectionName.equalsIgnoreCase("SHOW INFO")) {
			fieldNamesList.add("Air Platform");
			fieldNamesList.add("Show Unit or Project Name");
			String showUnitOrProjectName = Constants.getShowUnitOrProjectName();
			if (showUnitOrProjectName != null && showUnitOrProjectName.equalsIgnoreCase("Other")) {
				fieldNamesList.add("Other");
			}
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Is Budget Code Available?", "Budget Code")));
			String division = Constants.getDivision();
			if (division != null && division.equals("CNBC")) {
				fieldNamesList.add("Work Order #");
			}
			fieldNamesList
					.addAll(new ArrayList<String>(Arrays.asList("Start Date", "Prep Time", "Start Time", "End Time")));
		} else if (sectionName.equalsIgnoreCase("SET LOCATION")) {
			fieldNamesList.add("Location");
			String locationdetail = Constants.getLocations();
			if (locationdetail != null && locationdetail.equalsIgnoreCase("Field")) {
				fieldNamesList.add("Address");
			} else if (locationdetail != null && !locationdetail.equalsIgnoreCase("None")) {
				fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Set Location")));
			}
		} else if (sectionName.equalsIgnoreCase("SET CREW")) {
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Set Crew")));
		} else if (sectionName.equalsIgnoreCase("CONTROL ROOM")) {
			fieldNamesList.add("Control Room Location");
			String controlRoom = Constants.getControlRoomLocation();
			if (controlRoom != null && controlRoom.equalsIgnoreCase("Field")) {
				fieldNamesList.add("Address");
			} else if (controlRoom != null && !controlRoom.equalsIgnoreCase("No Control Room")) {
				fieldNamesList.add("Control Room");
			}
		} else if (sectionName.equalsIgnoreCase("CONTROL ROOM CREW")) {
			String controlRoom = Constants.getControlRoomLocation();
			if (controlRoom != null && !controlRoom.equalsIgnoreCase("No Control Room")) {
				fieldNamesList.addAll(new ArrayList<String>(
						Arrays.asList("Capture Manager: Do you need content to be recorded?", "Control Room Crew")));
			}
		} else if (sectionName.equalsIgnoreCase("ADDITIONAL CREW")) {
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Additional Crew")));
		} else if (sectionName.equalsIgnoreCase("SYSTEMS")) {
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Ultimatte", "Voice Activated Prompter")));
		} else if (sectionName.equalsIgnoreCase("STAGING")) {
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Is STAGING Needed?", "Is LIGHTING Needed?",
					"Is CARPENTRY Needed?", "Are PROPS needed?", "Describe Staging Needs")));
		} else if (sectionName.equalsIgnoreCase("TPM / TM INFORMATION")) {
			fieldNamesList.addAll(new ArrayList<String>(
					Arrays.asList("Is a TPM or TM Needed?", "Same as requester?", "TPM/TM Name")));
		} else if (sectionName.equalsIgnoreCase("FLASHCAM CREW")) {
			String locationdetail = Constants.getLocations();
			String setLocationdetail = Constants.getSetLocations();
			if (locationdetail != null && locationdetail.equalsIgnoreCase("Telemundo Center")
					&& setLocationdetail.equalsIgnoreCase("Newsroom Desk")) {
				fieldNamesList.addAll(
						new ArrayList<String>(Arrays.asList("Set Flashcam Crew", "Notes", "CAMERA OPERATOR", "A1")));
			} else if (locationdetail != null && locationdetail.equalsIgnoreCase("Telemundo Center")
					&& setLocationdetail.equalsIgnoreCase("Newsroom Flashcam")) {
				fieldNamesList
						.addAll(new ArrayList<String>(Arrays.asList("Set Flashcam Crew", "Notes", "TECH MANAGER")));
			}
		}
		return fieldNamesList;
	}

	public List<String> getRequiredFieldsSectionWise(String sectionName) {
		List<String> fieldNamesList = new ArrayList<String>();
		if (sectionName.equalsIgnoreCase("GENERAL DETAILS")) {
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Division")));
		} else if (sectionName.equalsIgnoreCase("REQUESTER(S)") || sectionName.equalsIgnoreCase("TALENT")
				|| sectionName.equalsIgnoreCase("SET CREW") || sectionName.equalsIgnoreCase("CONTROL ROOM CREW")
				|| sectionName.equalsIgnoreCase("ADDITIONAL CREW")
				|| sectionName.equalsIgnoreCase("TPM / TM INFORMATION") || sectionName.equalsIgnoreCase("SYSTEMS")
				|| sectionName.equalsIgnoreCase("FLASHCAM CREW")) {
			fieldNamesList.addAll(new ArrayList<String>());
		} else if (sectionName.equalsIgnoreCase("PRODUCTION PURPOSE")) {
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Request For")));
		} else if (sectionName.equalsIgnoreCase("SHOW INFO")) {
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Air Platform", "Show Unit or Project Name",
					"Other", "Is Budget Code Available?", "Budget Code", "Start Date", "Start Time", "End Time")));
		} else if (sectionName.equalsIgnoreCase("SET LOCATION")) {
			fieldNamesList.add("Location");
			String locationdetail = Constants.getLocations();
			if (locationdetail != null && locationdetail.equalsIgnoreCase("Field")) {
				fieldNamesList.add("Address");
			} else if (locationdetail != null && !locationdetail.equalsIgnoreCase("None"))
				fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Set Location")));
		} else if (sectionName.equalsIgnoreCase("STAGING")) {
			fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Is STAGING Needed?", "Is LIGHTING Needed?",
					"Is CARPENTRY Needed?", "Are PROPS needed?")));
		} else if (sectionName.equalsIgnoreCase("CONTROL ROOM")) {
			fieldNamesList.add("Control Room Location");
			String locationdetail = Constants.getControlRoomLocation();
			if (locationdetail != null && locationdetail.equalsIgnoreCase("Field")) {
				fieldNamesList.add("Address");
			} else if (locationdetail != null && !locationdetail.equalsIgnoreCase("None"))
				fieldNamesList.addAll(new ArrayList<String>(Arrays.asList("Control Room")));
		}
		return fieldNamesList;
	}

	/**
	 * To verify additional talent added in the form
	 *
	 * @param talent- additional talent name
	 */
	public void verifyAdditionOfTalent(String talent) {
		String[] additionalTalentList;
		try {
			if (talent != null) {
				if (talent.contains("-")) {
					additionalTalentList = talent.split("-");

				} else {
					additionalTalentList = talent.split(" ");
				}
				for (String additionalTal : additionalTalentList) {
					for (int i = 0; i < AdditionalTalent.size(); i++) {
						String displayedTalentName = WebAction.getText(AdditionalTalent.get(i));
						Assert.assertEquals(displayedTalentName, additionalTal);
					}
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}

	public void TPMorTMSectionDetails(String TPMorTM) throws InterruptedException {

		WebAction.scrollIntoView(tpmOrTmSection);
		if (!tpmOrTm_No.isSelected()) {
			tpmTmName.sendKeys("TPMorTM");
		}

	}

	public void fillSetLocationDetails(String locationText, String setLocationText, String Division) throws Exception {
		try {
			WebAction.scrollIntoView(setLocationSection);
			producerDashboardGeneralPage.selectDivision(Division);
			producerDashboardGeneralPage.selectLocation(locationText);
			if (!locationText.equalsIgnoreCase("None") && !locationText.equalsIgnoreCase("Field")
					&& setLocationText != null) {
				boolean valuePresent = false;
				WebAction.clickUsingJs(setLocationDropDown);
				Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
				for (WebElement ele : dropDownvalues) {
					if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(setLocationText)) {
						WebAction.click(ele);
						valuePresent = true;
						break;
					}
				}
				if (valuePresent == false)
					throw new Exception(
							"'" + setLocationText + "' value is not present in the set location type drop down");
			} else if (locationText.equalsIgnoreCase("Field") && setLocationText != null) {
				WebAction.sendKeys(locationAddressInputBox, setLocationText);
			} else {
				Assert.assertTrue(true, "set location field is not present as location is None");
			}
			Constants.setLocations(locationText);
			Constants.setSetLocations(setLocationText);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void fillControlRoomDetails(String ControlRoomLocation, String ControlRoom) throws Exception {
		try {
			WebAction.scrollIntoView(controlRoomLocationDropDown);
			producerDashboardGeneralPage.addControlRoomLocation(ControlRoomLocation);
			Constants.setControlRoomLocation(ControlRoomLocation);
			if (!ControlRoomLocation.equalsIgnoreCase("No Control Room")
					&& !ControlRoomLocation.equalsIgnoreCase("Field") && ControlRoomLocation != null) {
				WebAction.clickUsingJs(controlRoomDropDown);
				boolean valuePresent = false;
				for (WebElement ele : dropDownvalues) {
					if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(ControlRoom)) {
						WebAction.click(ele);
						valuePresent = true;
						break;
					}
				}
				if (valuePresent == false)
					throw new Exception(
							"'" + ControlRoom + "' value is not present in the set location type drop down");
			} else if (ControlRoomLocation.equalsIgnoreCase("Field") && ControlRoom != null) {
				WebAction.sendKeys(controlRoomAddressInputBox, ControlRoom);
				Constants.setControlRoomOption(ControlRoom);
			} else {

				Assert.assertTrue(true,
						"Control room field is not present as No control room is selected as control room location");
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void checkDefaultState() {
		WebAction.scrollIntoView(producerDashboardGeneralPage.stagingSection);
		for (int i = 0; i < stagingButtons.size(); i++) {
			String cssClasses = WebAction.getAttribute(stagingButtons.get(i), "class");
			if (!cssClasses.contains(" ant-radio-button-wrapper-checked")) {
				Assert.assertTrue(true, "The staging buttons are in unchecked state");
			}
			if (stagingButtons.get(i).getText().equalsIgnoreCase("No")) {
				stagingButtons.get(i).click();
				String cssClassesOfLighting = WebAction.getAttribute(lightingButtons.get(i), "class");
				if (cssClassesOfLighting.contains(" ant-radio-button-wrapper-disabled")) {
					Assert.assertTrue(true, "The lighting buttons are in enabled state");
				}
				String cssClassesOfCarpentry = WebAction.getAttribute(carpentryButtons.get(i), "class");
				if (!cssClassesOfCarpentry.contains(" ant-radio-button-wrapper-disabled")) {
					Assert.assertTrue(true, "The Carpentry buttons are in enabled state");
				}
				String cssClassesOfProps = WebAction.getAttribute(propsButtons.get(i), "class");
				if (!cssClassesOfProps.contains(" ant-radio-button-wrapper-disabled")) {
					Assert.assertTrue(true, "The Props buttons are in enabled state");
				}
			} else {
				stagingButtons.get(i).click();
				String cssClassesOfLighting = WebAction.getAttribute(lightingButtons.get(i), "class");
				if (!cssClassesOfLighting.contains(" ant-radio-button-wrapper-disabled")) {
					Assert.assertTrue(true, "The lighting buttons are in disabled state");
				}
				String cssClassesOfCarpentry = WebAction.getAttribute(carpentryButtons.get(i), "class");
				if (!cssClassesOfCarpentry.contains(" ant-radio-button-wrapper-disabled")) {
					Assert.assertTrue(true, "The Carpentry buttons are in disabled state");
				}
				String cssClassesOfProps = WebAction.getAttribute(propsButtons.get(i), "class");
				if (!cssClassesOfProps.contains(" ant-radio-button-wrapper-disabled")) {
					Assert.assertTrue(true, "The Props buttons are in disabled state");

				}
			}

		}

	}

	/**
	 * To verify flashcam crew section in the form
	 *
	 * @param locationText-    location detail
	 * @param Division-        Division detail
	 * @param SetLocationText- Set location detail
	 * @throws Exception
	 */
	public void verifyPresenceOfFlashCamSection(String locationText, String Division, String SetLocationText)
			throws Exception {
		String ExpectedName = "FLASHCAM CREW";
		WebAction.scrollIntoView(locationDropDown);
		fillSetLocationDetails(locationText, Division, SetLocationText);
		if (Constants.getLocations().equalsIgnoreCase("Telemundo Center")
				&& (Constants.getSetLocations().equalsIgnoreCase("Newsroom Flashcam")
						|| Constants.getSetLocations().equalsIgnoreCase("Newsroom Desk"))) {
			Assert.assertEquals(flashcamSection.getText(), ExpectedName, "flashcam section is visible");
		}

	}

}