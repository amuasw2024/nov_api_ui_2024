package nbcu.automation.ui.stepdefs.ncxUnifiedTool;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.ncxUnifiedTool.ProducerDashboardGeneralPage;
import nbcu.framework.utils.cucumber.CucumberUtils;

public class CrewNBCNewsRequestFormPageSteps {

	ProducerDashboardGeneralPage producerDashboardGeneralPage = new ProducerDashboardGeneralPage();

	@When("user enters shoot specs Information in NBC News Crew form")
	public void fillShootSpecsInfoInNBCNewsCrewRequest(DataTable dataTable) throws Exception {
		producerDashboardGeneralPage.addAudioNeeds(CucumberUtils.getValuesFromDataTable(dataTable, "Audio Needs"));
		producerDashboardGeneralPage
				.addSpecialConditions(CucumberUtils.getValuesFromDataTable(dataTable, "Special Conditions"));
		producerDashboardGeneralPage
				.addTransmissionType(CucumberUtils.getValuesFromDataTable(dataTable, "Transmission Type"));
		producerDashboardGeneralPage
				.addAcquisitionSpecs(CucumberUtils.getValuesFromDataTable(dataTable, "Acquisition Specs"));
		producerDashboardGeneralPage
				.enterIsthisaDroneShootText(CucumberUtils.getValuesFromDataTable(dataTable, "Is this a Drone Shoot"));
		producerDashboardGeneralPage.enterSpecialGear(CucumberUtils.getValuesFromDataTable(dataTable, "Special Gear"));
	}

	@When("user enters shoot specs in NBC News crew fulfillment section")
	public void fillShootSpecsInFulfillmentsection(DataTable dataTable) throws Exception {
		producerDashboardGeneralPage.fillprimaryCameraTypeInFulfillmentSection(
				CucumberUtils.getValuesFromDataTable(dataTable, "Primary Camera Type"));
		producerDashboardGeneralPage
				.fillmediaFormatInFulfillmentSection(CucumberUtils.getValuesFromDataTable(dataTable, "Media Format"));
	}
}
