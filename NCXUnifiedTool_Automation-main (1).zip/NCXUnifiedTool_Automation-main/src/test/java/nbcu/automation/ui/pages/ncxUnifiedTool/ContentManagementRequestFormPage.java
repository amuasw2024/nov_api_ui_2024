
package nbcu.automation.ui.pages.ncxUnifiedTool;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import nbcu.automation.ui.constants.ncxUnifiedTool.Constants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.Other.DateFunctions;
import nbcu.framework.utils.ui.Waits;
import nbcu.framework.utils.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.utils.ui.WebAction;

public class ContentManagementRequestFormPage {

	@FindBy(xpath = "//*[@role='menuitem']/div")
	List<WebElement> SearchList;

	String dropDownvaluesXpath = "//div[@class='cdk-virtual-scroll-content-wrapper']/nz-option-item";

	@FindBy(xpath = "//div[@class='cdk-virtual-scroll-content-wrapper']/nz-option-item | //nz-option-item ")
	List<WebElement> dropDownvalues;

	@FindBy(xpath = "//*[@forminputname='dateNeededBy']//input")
	WebElement dateNeededBy;

	@FindBy(xpath = "//*[@formcontrolname='dateNeededByASAPBin' or @formcontrolname='dateNeededByASAP']//input")
	WebElement dateNeededByASAPCheckBox;

	@FindBy(xpath = "//*[@forminputname='timeNeededBy']//input")
	WebElement timeNeededBy;

	@FindBy(xpath = "//*[@formcontrolname='timeNeededByFlexible' or @formcontrolname='timeNeededByFlexibleBin']//input")
	WebElement timeNeededByFlexibleCheckBox;

	String sourceTypeDropDown = "(//*[@forminputname='deviceType']//input)[<<sourceTypeDropDownNo>>]";

	String destinationTypeDropDown = "(//*[@forminputname='selectDestination']//input)[<<destinationTypeDropDownNo>>]";

	String quantityInputBox = "(//*[@forminputname='quantity' or @forminputname='inputQuantity']//input)[<<quantityInputBoxNo>>]";

	String commentsInputBox = "(//*[@forminputname='sourceComments' or @forminputname='comments']//textarea)[<<commentsInputBoxNo>>]";

	String detailsInputBox = "(//*[@forminputname='textareaDestinationDetails']//textarea)[<<detailsInputBoxNo>>]";

	String slugInputBox = "((//*[@formarrayname='cnbcStratusSlug'])[<<sourceTypeDropDownNo>>]//*[@forminputname='slug']//input)[<<slugInputBoxNo>>]";

	String addStratusSlugButton = "(//span[contains(text(),'Stratus Slug')])[<<sourceTypeDropDownNo>>]";

	String sourceDetailsInputBox = "(//*[@forminputname='sourceDetails']//textarea)[<<sourceDetailsInputBoxNo>>]";

	String timeCodesInputBox = "(//*[@forminputname='timeCodes']//input)[<<timeCodesInputBoxNo>>]";

	@FindBy(xpath = "//span[contains(text(),'SOURCE')] | //span[contains(text(),'Source')]")
	WebElement addSourceButton;

	@FindBy(xpath = "//span[contains(text(),'Destination')]")
	WebElement addDestinationButton;

	String addCameraTypeButtonText = "(//*[@forminputname='deviceType']//input)[<<sourceTypeDropDownNo>>]//ancestor::div[6]//*[contains(text(),'Camera Type')]";

	String cameraTypeInputBox = "((//*[@forminputname='deviceType']//input)[<<sourceTypeDropDownNo>>]//ancestor::div[6]//*[@forminputname='cameraTypeInput' or @forminputname='cameraType']//input)[<<cameraInputBoxNo>>]";

	String finalDestination = "//*[contains(@sectiontitle,'Destination')]//p[text()='<<finalDestinationName>>']/ancestor::div[2]//input[@type='checkbox']";

	@FindBy(xpath = "//*[@placeholder='Other Sources']//input")
	WebElement otherFinalDestinationInputBox;

	@FindBy(xpath = "//*[@forminputname='contentDescription']//textarea")
	WebElement contentDescriptionTextArea;

	@FindBy(xpath = "//*[@forminputname='fiComments' or @forminputname='generalComments']//textarea")
	WebElement commentTextArea;

	@FindBy(xpath = "//*[@forminputname='textareaInstructions']//textarea")
	WebElement instructionsTextArea;

	@FindBy(xpath = "//p[contains(text(),'SHOW INFORMATION')]")
	WebElement showInformationSection;

	@FindBy(xpath = "//p[contains(text(),'DATE & TIME NEEDED')]")
	WebElement dateAndTimeNeededSection;

	@FindBy(xpath = "//p[contains(text(),'ADDITIONAL SOURCE')]")
	WebElement additionalSourceSection;

	@FindBy(xpath = "//p[contains(text(),'ATTACHMENTS')]")
	WebElement attachmentsSection;

	@FindBy(xpath = "//*[@label='Method of Ingest']//input")
	WebElement methodOfIngest;

	@FindBy(xpath = "//*[@label='Destination(s)']//input | //h1[text()='Destination(s)']//ancestor::div[1]//input")
	WebElement destinations;

	@FindBy(xpath = "//input[@placeholder='Enter Other Method of Ingest']")
	WebElement otherMethodOfIngestInputBox;

	@FindBy(xpath = "//input[@placeholder='Enter Other File Format'] | //*[@forminputname='fulFillerFileFormat']//ancestor::div[1]//*[@forminputname='fulFillerFileFormatOther']//input")
	WebElement otherFileFormatInputBox;

	@FindBy(xpath = "//input[@placeholder='Enter Other Folder Format']")
	WebElement otherFolderFormatInputBox;

	@FindBy(xpath = "//*[@label='File Format']//input | //*[@forminputname='fulFillerFileFormat']//input")
	WebElement fileFormat;

	@FindBy(xpath = "//*[@label='Gig Size']//input")
	WebElement gigSize;

	@FindBy(xpath = "//*[@label='Clip Count']//input | //h1[text()='Clip Count']//ancestor::div[1]//input")
	WebElement clipCount;

	@FindBy(xpath = "//*[@label='Folder Format']//input")
	WebElement folderFormat;

	@FindBy(xpath = "//*[@label='Bin Name']//input")
	WebElement binName;

	@FindBy(xpath = "//*[@label='Media ID #']//input | //h1[text()='Media ID#']//ancestor::div[1]//input")
	WebElement mediaID;

	@FindBy(xpath = "//*[@label='Assistant Editor Assigned']//input")
	WebElement assistantEditorAssigned;

	@FindBy(xpath = "//*[@label='Hours']//input")
	WebElement deviceTimerHours;

	@FindBy(xpath = "//*[@label='Minutes']//input")
	WebElement deviceTimerMinutes;

	@FindBy(xpath = "//*[@label='Seconds']//input")
	WebElement deviceTimerSeconds;

	@FindBy(xpath = "//div[@class='fulfillment']//*[@forminputname='comments']//textarea | //*[@forminputname='ffComments' or @forminputname='fulFillerComments']//textarea")
	WebElement fulfillmentComments;

	@FindBy(xpath = "//*[@forminputname='feedTime']//input")
	WebElement feedTime;

	@FindBy(xpath = "//*[@formarrayname='fulfillerDestinations']//div[@title='Destinations']")
	List<WebElement> fullfilmentSectionDestionationList;

	@FindBy(xpath = "//button[@title='Add Destination']")
	WebElement addFulfillmentDestinationButton;

	String destinationsInputBox = "(//*[@formarrayname='fulfillerDestinations']//div[@title='Destinations'])[<<destinationsInputBoxNo>>]";

	String findRequestById = "//a[contains(text(),'<<RequestId>>')]";

	public ContentManagementRequestFormPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To fill Date Needed By & Time Needed By setLocationSection
	 * 
	 * @param commentText - Date Needed By & Time Needed By in this form
	 * @throws Exception
	 */
	public void fillDateNeededByTimeNeededBy(String dateNeededByText, String timeNeededByText) throws Exception {
		try {
			WebAction.scrollIntoView(showInformationSection);
			// To fill Date Needed By
			if (dateNeededByText != null) {
				WebAction.click(dateNeededBy);
				WebAction.sendKeys(dateNeededBy, generateDate(dateNeededByText, "MM/dd/yyyy"));
				WebAction.keyPress(dateNeededBy, "Enter");
			} else {
				WebAction.clickUsingJs(dateNeededByASAPCheckBox);
			}

			// To fill Time Needed By
			if (timeNeededByText != null) {
				WebAction.click(timeNeededBy);
				WebAction.sendKeys(timeNeededBy, generateTime(timeNeededByText, "hh:mm a"));
			} else {
				WebAction.clickUsingJs(timeNeededByFlexibleCheckBox);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To generate date based on input. Date should like CurrebDate+1,
	 * CurrentDate-2, etc.,
	 * 
	 * @param date   - date
	 * @param format - date format
	 * @throws Exception
	 */
	public String generateDate(String date, String format) throws Exception {
		String updateddate = "";
		try {
			if (date.trim() != null) {
				if (date.toUpperCase().contains("CURRENTDATE")) {
					String days = date.replaceAll("[a-zA-Z]", "").trim();
					if (days.length() == 0) {
						days = "0";
					}
					updateddate = DateFunctions.addOrMinusDateFromCurrentDate(format, days);
				} else
					throw new Exception("Please provide date in valid format");
			} else
				throw new Exception("Date is empty");

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return updateddate;
	}

	/**
	 * To generate time based on input. Time should like CurrentTime+1,
	 * CurrentTime-2, etc.,
	 * 
	 * @param time   - time
	 * @param format - time format
	 * @return
	 * @throws Exception
	 */
	public String generateTime(String time, String format) throws Exception {
		String updatedTime = "";
		try {
			if (time.trim() != null) {
				if (time.toUpperCase().contains("CURRENTTIME")) {
					String hours = time.replaceAll("[a-zA-Z]", "").trim();
					if (hours.length() == 0) {
						hours = "0";
					}
					updatedTime = DateFunctions.addOrMinusTimeFromCurrentTime(format, hours);
				} else
					updatedTime = time;
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return updatedTime;
	}

	public int daysBetween(Date d1, Date d2) {
		return (int) ((d2.getTime() - d1.getTime()) / (1000 * 60 * 60 * 24));
	}

	/**
	 * To fill Source section
	 * 
	 * @param Source this form
	 * @throws Exception
	 */
	public void fillSource(String SourceText, String quantityText, String commentsText, String cameraText)
			throws Exception {
		try {
			WebAction.scrollIntoView(dateAndTimeNeededSection);
			WebDriver driver = DriverFactory.getCurrentDriver();
			// To select Source type
			if (SourceText != null) {
				String[] SourceTextArrayList = SourceText.split(",");
				int j = 1, k = 0, l = 0;
				for (k = 0; k < SourceTextArrayList.length; k++) {
					String sourceTypeDropDownXpath = sourceTypeDropDown.replace("<<sourceTypeDropDownNo>>",
							Integer.toString(k + 1));
					WebElement sourceTypeDropDownWebElement = driver.findElement(By.xpath(sourceTypeDropDownXpath));
					Waits.waitForElement(sourceTypeDropDownWebElement, WAIT_CONDITIONS.CLICKABLE);
					boolean valuePresent = false;
					WebAction.click(sourceTypeDropDownWebElement);
					WebAction.sendKeys(sourceTypeDropDownWebElement, SourceTextArrayList[k].trim());
					Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
					for (WebElement ele : dropDownvalues) {

						if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(SourceTextArrayList[k].trim())) {
							WebAction.clickUsingJs(ele);
							valuePresent = true;
							break;
						}
					}
					// To enter quantity
					fillQuantity(quantityText, k);
					// To enter comments
					if (commentsText != null) {
						String[] commentsTextArrayList = commentsText.split(",");
						String commentsInputBoxXpath = commentsInputBox.replace("<<commentsInputBoxNo>>",
								Integer.toString(k + 1));
						WebElement commentsInputBoxWebElement = driver.findElement(By.xpath(commentsInputBoxXpath));
						WebAction.sendKeys(commentsInputBoxWebElement, commentsTextArrayList[k]);

					}
					fillCamera(cameraText, k);
					// need to check here
					if (j <= SourceTextArrayList.length - 1
							&& addSourceButton.getAttribute("class").contains("ng-star-inserted")) {
						Waits.waitForElement(addSourceButton, WAIT_CONDITIONS.CLICKABLE);
						WebAction.click(addSourceButton);
						j++;
					}
				}
			}
		}

		catch (

		Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void fillSourceFeedOut(String SourceText, String slugText, String quantityText, String commentsText)
			throws Exception {
		try {
			WebAction.scrollIntoView(dateAndTimeNeededSection);
			WebDriver driver = DriverFactory.getCurrentDriver();
			// To select Source type
			if (SourceText != null) {
				String[] SourceTextArrayList = SourceText.split(",");
				int j = 1, k = 0, l = 0;
				for (k = 0; k < SourceTextArrayList.length; k++) {
					String sourceTypeDropDownXpath = sourceTypeDropDown.replace("<<sourceTypeDropDownNo>>",
							Integer.toString(k + 1));
					WebElement sourceTypeDropDownWebElement = driver.findElement(By.xpath(sourceTypeDropDownXpath));
					Waits.waitForElement(sourceTypeDropDownWebElement, WAIT_CONDITIONS.CLICKABLE);
					boolean valuePresent = false;
					WebAction.click(sourceTypeDropDownWebElement);
					WebAction.sendKeys(sourceTypeDropDownWebElement, SourceTextArrayList[k].trim());
					Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
					for (WebElement ele : dropDownvalues) {
						if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(SourceTextArrayList[k].trim())) {
							if (SourceTextArrayList[k].trim().equalsIgnoreCase("CNBC- Stratus")) {
								l++;
							}
							WebAction.clickUsingJs(ele);
							valuePresent = true;
							break;
						}
					}
					// To enter slug for CNBC- Stratus source type
					if (SourceTextArrayList[k].trim().equalsIgnoreCase("CNBC- Stratus") && slugText != null) {
						int a = 0;
						String[] slugTextArrayList = slugText.split(",");
						for (int x = 1; x <= SourceTextArrayList.length; x++) {
							if (!(x == 1)) {
								String addStratusSlugButtonXpath = addStratusSlugButton
										.replace("<<sourceTypeDropDownNo>>", Integer.toString(l));
								WebElement addStratusSlugButtonWebElement = driver
										.findElement(By.xpath(addStratusSlugButtonXpath));
								Waits.waitForElement(addStratusSlugButtonWebElement, WAIT_CONDITIONS.CLICKABLE);
								WebAction.click(addStratusSlugButtonWebElement);
							}
							String slugInputBoxXpath = slugInputBox.replace("<<sourceTypeDropDownNo>>",
									Integer.toString(l));
							slugInputBoxXpath = slugInputBoxXpath.replace("<<slugInputBoxNo>>", Integer.toString(x));
							WebElement slugInputBoxWebElement = driver.findElement(By.xpath(slugInputBoxXpath));
							WebAction.sendKeys(slugInputBoxWebElement, slugTextArrayList[a]);
							a++;
						}
					}

					// To enter quantity
					fillQuantity(quantityText, k);
					// To enter comments
					if (commentsText != null) {
						String[] commentsTextArrayList = commentsText.split(",");
						String commentsInputBoxXpath = commentsInputBox.replace("<<commentsInputBoxNo>>",
								Integer.toString(k + 1));
						WebElement commentsInputBoxWebElement = driver.findElement(By.xpath(commentsInputBoxXpath));
						WebAction.sendKeys(commentsInputBoxWebElement, commentsTextArrayList[k]);

					}
					// need to check here
					if (j <= SourceTextArrayList.length - 1
							&& addSourceButton.getAttribute("class").contains("ng-star-inserted")) {
						Waits.waitForElement(addSourceButton, WAIT_CONDITIONS.CLICKABLE);
						WebAction.click(addSourceButton);
						j++;
					}
				}
			}
		}

		catch (

		Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill Source section
	 * 
	 * @param Source this form
	 * @throws Exception
	 */
	public void fillSourceInMTD(String SourceText, String sourceDetailsText, String timeCodesText, String cameraText)
			throws Exception {
		try {
			WebAction.scrollIntoView(dateAndTimeNeededSection);
			WebDriver driver = DriverFactory.getCurrentDriver();
			// To select Source type
			if (SourceText != null) {
				String[] SourceTextArrayList = SourceText.split(",");
				int j = 1, k = 0, l = 0;
				for (k = 0; k < SourceTextArrayList.length; k++) {
					String sourceTypeDropDownXpath = sourceTypeDropDown.replace("<<sourceTypeDropDownNo>>",
							Integer.toString(k + 1));
					WebElement sourceTypeDropDownWebElement = driver.findElement(By.xpath(sourceTypeDropDownXpath));
					Waits.waitForElement(sourceTypeDropDownWebElement, WAIT_CONDITIONS.CLICKABLE);
					boolean valuePresent = false;
					WebAction.click(sourceTypeDropDownWebElement);
					WebAction.sendKeys(sourceTypeDropDownWebElement, SourceTextArrayList[k].trim());
					Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
					for (WebElement ele : dropDownvalues) {
						if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(SourceTextArrayList[k].trim())) {
							WebAction.clickUsingJs(ele);
							valuePresent = true;
							break;
						}
					}
					// To enter source details
					fillSourceDetails(sourceDetailsText, k);
					// To enter Time codes
					if (timeCodesText != null) {
						String[] timeCodesTextArrayList = timeCodesText.split(",");
						String timeCodeInputBoxXpath = timeCodesInputBox.replace("<<timeCodesInputBoxNo>>",
								Integer.toString(k + 1));
						WebElement timeCodeInputBoxWebElement = driver.findElement(By.xpath(timeCodeInputBoxXpath));
						Waits.waitForElement(timeCodeInputBoxWebElement, WAIT_CONDITIONS.CLICKABLE);
						WebAction.sendKeys(timeCodeInputBoxWebElement, timeCodesTextArrayList[k]);
						Thread.sleep(1000);
						Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
						Thread.sleep(1000);
						for (WebElement ele : dropDownvalues) {
							if (WebAction.getAttribute(ele, "title")
									.equalsIgnoreCase(timeCodesTextArrayList[k].trim())) {
								WebAction.clickUsingJs(ele);
							}
						}
					}
					fillCamera(cameraText, k);
					// need to check here
					if (j <= SourceTextArrayList.length - 1
							&& addSourceButton.getAttribute("class").contains("ng-star-inserted")) {
						WebAction.scrollIntoView(additionalSourceSection);
						Waits.waitForElement(addSourceButton, WAIT_CONDITIONS.CLICKABLE);
						WebAction.clickUsingJs(addSourceButton);
						j++;
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void fillSourceDetails(String sourceDetailsText, int k) throws Exception {
		try {
			WebDriver driver = DriverFactory.getCurrentDriver();
			// To enter source Details
			if (sourceDetailsText != null) {
				String[] sourceDetailsTextArrayList = sourceDetailsText.split(",");
				String sourceDetailsXpath = sourceDetailsInputBox.replace("<<sourceDetailsInputBoxNo>>",
						Integer.toString(k + 1));
				WebElement sourceDetailsWebElement = driver.findElement(By.xpath(sourceDetailsXpath));
				Thread.sleep(1000);
				WebAction.sendKeys(sourceDetailsWebElement, sourceDetailsTextArrayList[k]);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To enter quantity in form
	 * 
	 * @param quantity in form
	 * @throws Exception
	 */
	public void fillQuantity(String quantityText, int k) throws Exception {
		try {
			WebDriver driver = DriverFactory.getCurrentDriver();
			// To enter quantity
			if (quantityText != null) {
				String[] quantityTextArrayList = quantityText.split(",");
				String quantityInputBoxXpath = quantityInputBox.replace("<<quantityInputBoxNo>>",
						Integer.toString(k + 1));
				WebElement quantityInputBoxWebElement = driver.findElement(By.xpath(quantityInputBoxXpath));
				WebAction.sendKeys(quantityInputBoxWebElement, "\u0008");
				Thread.sleep(2000);
				WebAction.sendKeys(quantityInputBoxWebElement, quantityTextArrayList[k]);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To select Camera type
	 * 
	 * @param select Camera type
	 * @throws Exception
	 */
	public void fillCamera(String cameraText, int k) throws Exception {
		try {
			WebDriver driver = DriverFactory.getCurrentDriver();
			int j = 0;
			String[] cameraTextArrayList = null;
			if (cameraText != null) {
				cameraTextArrayList = cameraText.split(",");
				for (int x = 0; x < cameraTextArrayList.length; x++) {
					String cameraTextXpath = cameraTypeInputBox
							.replace("<<sourceTypeDropDownNo>>", Integer.toString(k + 1))
							.replace("<<cameraInputBoxNo>>", Integer.toString(x + 1));
					WebElement cameraTextWebElement = driver.findElement(By.xpath(cameraTextXpath));
					WebAction.sendKeys(cameraTextWebElement, cameraTextArrayList[x]);
					WebAction.keyPress(cameraTextWebElement, "Enter");
					j++;
					if (j < cameraTextArrayList.length) {
						String addCameraTypeButtonXpath = addCameraTypeButtonText.replace("<<sourceTypeDropDownNo>>",
								Integer.toString(k + 1));
						WebElement addCameraTypeButton = driver.findElement(By.xpath(addCameraTypeButtonXpath));
						Waits.waitForElement(addCameraTypeButton, WAIT_CONDITIONS.CLICKABLE);
						WebAction.click(addCameraTypeButton);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To fill Destinations
	 * 
	 * @throws Exception
	 */
	public void fillDestinationDetails(String finalDestinationText) throws Exception {
		try {
			WebAction.scrollIntoView(additionalSourceSection);
			WebDriver driver = DriverFactory.getCurrentDriver();
			// To select final Delivery
			if (finalDestinationText != null) {
				String[] finalDestinationTextArrayList = finalDestinationText.split(",");
				for (int i = 0; i < finalDestinationTextArrayList.length; i++) {
					if (finalDestinationTextArrayList[i].toUpperCase().contains(("OTHER"))) {
						WebAction.sendKeys(otherFinalDestinationInputBox, finalDestinationTextArrayList[i]);
					} else {
						String finalDestinationXpath = finalDestination.replace("<<finalDestinationName>>",
								finalDestinationTextArrayList[i].trim());
						WebAction.clickUsingJs(driver.findElement(By.xpath(finalDestinationXpath)));
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void fillContentDescriptionInCM(String contentDescriptionText) throws Exception {
		try {
			if (contentDescriptionText != null) {
				WebAction.scrollIntoView(attachmentsSection);
				Waits.waitForElement(contentDescriptionTextArea, WAIT_CONDITIONS.CLICKABLE);
				WebAction.sendKeys(contentDescriptionTextArea, contentDescriptionText);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void fillCommentInCM(String commentText) throws Exception {
		try {
			if (commentText != null) {
				Waits.waitForElement(commentTextArea, WAIT_CONDITIONS.CLICKABLE);
				WebAction.sendKeys(commentTextArea, commentText);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void fileIngestFillFulfullmentSection(String MethodOfIngest, String Destinations, String FileFormat,
			String gigSizeText, String clipCountText, String FolderFormat, String BinName, String mediaIDText,
			String assistantEditorAssignedText, String deviceTimerHoursText, String deviceTimerMinutesText,
			String deviceTimerSecondsText, String fulfillerComments) throws Exception {

		try {
			enterMethodOfIngest(MethodOfIngest);
			enterDestinations(Destinations);
			enterFileFormat(FileFormat);
			fillgigSize(gigSizeText);
			fillclipCount(clipCountText);
			enterFolderFormat(FolderFormat);
			fillBinName(BinName);
			fillMediaID(mediaIDText);
			enterAssistantEditorAssigned(assistantEditorAssignedText);
			filldeviceTimerHoursHours(deviceTimerHoursText);
			filldeviceTimerMinutes(deviceTimerMinutesText);
			filldeviceTimerSeconds(deviceTimerSecondsText);
			fillFulfillmentComment(fulfillerComments);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}

	public void fillBinName(String BinName) throws Exception {
		if (BinName != null) {
			WebAction.sendKeys(binName, BinName);
		}
	}

	public void fillMediaID(String mediaIDText) throws Exception {
		if (mediaIDText != null) {
			WebAction.sendKeys(mediaID, mediaIDText);
		}
	}

	public void enterFolderFormat(String FolderFormat) throws Exception {
		if (FolderFormat != null) {
			boolean valuePresent = false;
			String[] FolderFormatTextArrayList = FolderFormat.split(",");
			WebAction.clickUsingJs(folderFormat);
			Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
			for (String FolderFormatTextList : FolderFormatTextArrayList) {
				WebAction.sendKeys(folderFormat, FolderFormatTextList.trim());
				for (WebElement ele : dropDownvalues) {
					if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(FolderFormatTextList.trim())) {
						WebAction.click(ele);
						valuePresent = true;
						break;
					}
				}
				if (valuePresent == false)
					throw new Exception(
							"'" + FolderFormatTextList + "' value is not present in the Folder Format type drop down");
			}
			WebAction.keyPress(folderFormat, "Esc");
			for (int i = 0; i < FolderFormatTextArrayList.length; i++) {
				if (FolderFormatTextArrayList[i].toUpperCase().contains(("OTHER"))) {
					WebAction.sendKeys(otherFolderFormatInputBox, FolderFormatTextArrayList[i]);
				}
			}
		}
	}

	public void enterFileFormat(String FileFormat) throws Exception {
		if (FileFormat != null) {
			boolean valuePresent = false;
			String[] FileFormatTextArrayList = FileFormat.split(",");
			WebAction.clickUsingJs(fileFormat);
			Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
			for (String FileFormatTextList : FileFormatTextArrayList) {
				WebAction.sendKeys(fileFormat, FileFormatTextList.trim());
				for (WebElement ele : dropDownvalues) {
					if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(FileFormatTextList.trim())) {
						WebAction.click(ele);
						valuePresent = true;
						break;
					}
				}
				if (valuePresent == false)
					throw new Exception(
							"'" + FileFormatTextList + "' value is not present in the File Format type drop down");
			}
			WebAction.keyPress(fileFormat, "Esc");
			for (int i = 0; i < FileFormatTextArrayList.length; i++) {
				if (FileFormatTextArrayList[i].toUpperCase().contains(("OTHER"))) {
					WebAction.sendKeys(otherFileFormatInputBox, FileFormatTextArrayList[i]);
				}
			}
		}
	}

	public void enterMethodOfIngest(String MethodOfIngest) throws Exception {
		// To fill method of ingest
		if (MethodOfIngest != null) {
			boolean valuePresent = false;
			String[] MethodOfIngestTextArrayList = MethodOfIngest.split(",");
			WebAction.clickUsingJs(methodOfIngest);
			Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
			for (String MethodOfIngestTextList : MethodOfIngestTextArrayList) {
				WebAction.sendKeys(methodOfIngest, MethodOfIngestTextList.trim());
				for (WebElement ele : dropDownvalues) {
					if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(MethodOfIngestTextList.trim())) {
						WebAction.click(ele);
						valuePresent = true;
						break;
					}
				}
				if (valuePresent == false)
					throw new Exception("'" + MethodOfIngestTextList
							+ "' value is not present in the method of ingest type drop down");
			}
			WebAction.keyPress(methodOfIngest, "Esc");
			for (int i = 0; i < MethodOfIngestTextArrayList.length; i++) {
				if (MethodOfIngestTextArrayList[i].toUpperCase().contains(("OTHER"))) {
					WebAction.sendKeys(otherMethodOfIngestInputBox, MethodOfIngestTextArrayList[i]);
				}
			}
		}
	}

	public void enterDestinations(String Destinations) throws Exception {
		// To fill destinations
		if (Destinations != null) {
			boolean valuePresent = false;
			String[] DestinationsTextArrayList = Destinations.split(",");
			WebAction.clickUsingJs(destinations);
			Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
			for (String DestinationsTextList : DestinationsTextArrayList) {
				WebAction.sendKeys(destinations, DestinationsTextList.trim());
				for (WebElement ele : dropDownvalues) {
					if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(DestinationsTextList.trim())) {
						WebAction.click(ele);
						valuePresent = true;
						break;
					}
				}
				if (valuePresent == false)
					throw new Exception(
							"'" + DestinationsTextList + "' value is not present in the Destinations type drop down");
			}
			WebAction.keyPress(destinations, "Esc");
		}
	}

	public void fillgigSize(String gigSizeText) throws Exception {
		// To fill gig size
		if (gigSizeText != null) {
			WebAction.sendKeys(gigSize, gigSizeText);
		}
	}

	public void fillclipCount(String clipCountText) throws Exception {
		// To fill clip count
		if (clipCountText != null) {
			WebAction.sendKeys(clipCount, clipCountText);
		}
	}

	public void fillFulfillmentComment(String fulfillmentCommentText) throws Exception {
		try {
			if (fulfillmentCommentText != null) {
				Waits.waitForElement(fulfillmentComments, WAIT_CONDITIONS.CLICKABLE);
				WebAction.sendKeys(fulfillmentComments, fulfillmentCommentText);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void enterAssistantEditorAssigned(String assistantEditorAssignedText) throws Exception {
		if (assistantEditorAssignedText != null) {
			Waits.waitForElement(assistantEditorAssigned, WAIT_CONDITIONS.CLICKABLE);
			WebAction.sendKeys(assistantEditorAssigned, assistantEditorAssignedText);
			Thread.sleep(1000);
			Waits.waitUntilElementSizeGreater(SearchList, 0);
			Thread.sleep(1000);
			WebAction.click(SearchList.get(0));
		}
	}

	public void filldeviceTimerHoursHours(String deviceTimerHoursText) throws Exception {
		if (deviceTimerHoursText != null) {
			WebAction.sendKeys(deviceTimerHours, deviceTimerHoursText);
		}
	}

	public void filldeviceTimerMinutes(String deviceTimerMinutesText) throws Exception {
		if (deviceTimerMinutesText != null) {
			WebAction.sendKeys(deviceTimerMinutes, deviceTimerMinutesText);
		}
	}

	public void filldeviceTimerSeconds(String deviceTimerSecondsText) throws Exception {
		if (deviceTimerSecondsText != null) {
			WebAction.sendKeys(deviceTimerSeconds, deviceTimerSecondsText);
		}
	}

	public void selectFeedTime(String feedTimeText) throws Exception {
		// To fill feed Time
		if (feedTimeText != null) {
			WebAction.click(feedTime);
			WebAction.sendKeys(feedTime, generateTime(feedTimeText, "hh:mm a"));
			WebAction.keyPress(feedTime, "Enter");
		}
	}

	public void feedOutFillFulfullmentSection(String Destinations, String mediaIDText, String feedTimeText,
			String deviceTimerHoursText, String deviceTimerMinutesText, String deviceTimerSecondsText,
			String clipCountText, String fulfillerComments) throws Exception {

		try {
			enterDestinations(Destinations);
			fillMediaID(mediaIDText);
			selectFeedTime(feedTimeText);
			filldeviceTimerHoursHours(deviceTimerHoursText);
			filldeviceTimerMinutes(deviceTimerMinutesText);
			filldeviceTimerSeconds(deviceTimerSecondsText);
			fillclipCount(clipCountText);
			fillFulfillmentComment(fulfillerComments);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}

	public void fillInstructionsInCM(String instructionsText) throws Exception {
		try {
			if (instructionsText != null) {
				Waits.waitForElement(instructionsTextArea, WAIT_CONDITIONS.CLICKABLE);
				WebAction.sendKeys(instructionsTextArea, instructionsText);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void fillDestinationInMTD(String destinationText, String quantityText, String detailsText) throws Exception {
		try {
			WebAction.scrollIntoView(additionalSourceSection);
			WebDriver driver = DriverFactory.getCurrentDriver();
			// To select Source type
			if (destinationText != null) {
				String[] destinationTextArrayList = destinationText.split(",");
				int j = 1, k = 0, l = 0;
				for (k = 0; k < destinationTextArrayList.length; k++) {
					String destinationTypeDropDownXpath = destinationTypeDropDown
							.replace("<<destinationTypeDropDownNo>>", Integer.toString(k + 1));
					WebElement destinationTypeDropDownWebElement = driver
							.findElement(By.xpath(destinationTypeDropDownXpath));
					Waits.waitForElement(destinationTypeDropDownWebElement, WAIT_CONDITIONS.CLICKABLE);
					boolean valuePresent = false;
					WebAction.click(destinationTypeDropDownWebElement);
					WebAction.sendKeys(destinationTypeDropDownWebElement, destinationTextArrayList[k].trim());
					Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
					for (WebElement ele : dropDownvalues) {
						if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(destinationTextArrayList[k].trim())) {
							WebAction.clickUsingJs(ele);
							valuePresent = true;
							break;
						}
					}
					fillQuantity(quantityText, k);

					if (detailsText != null) {
						String[] detailsTextArrayList = detailsText.split(",");
						String detailsInputBoxXpath = detailsInputBox.replace("<<detailsInputBoxNo>>",
								Integer.toString(k + 1));
						WebElement detailsInputBoxWebElement = driver.findElement(By.xpath(detailsInputBoxXpath));
						WebAction.sendKeys(detailsInputBoxWebElement, detailsTextArrayList[k]);
					}

					// need to check here
					if (j <= destinationTextArrayList.length - 1
							&& addDestinationButton.getAttribute("class").contains("ng-star-inserted")) {
						Waits.waitForElement(addDestinationButton, WAIT_CONDITIONS.CLICKABLE);
						WebAction.click(addDestinationButton);
						j++;
					}
				}
			}
		}

		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void MTDFillFulfullmentSection(String Destinations, String FileFormat, String gigSizeText,
			String clipCountText, String deviceTimerHoursText, String deviceTimerMinutesText,
			String deviceTimerSecondsText, String fulfillerComments) throws Exception {

		try {
			enterDestinationsInMTD(Destinations);
			enterFileFormat(FileFormat);
			fillgigSize(gigSizeText);
			fillclipCount(clipCountText);
			filldeviceTimerHoursHours(deviceTimerHoursText);
			filldeviceTimerMinutes(deviceTimerMinutesText);
			filldeviceTimerSeconds(deviceTimerSecondsText);
			fillFulfillmentComment(fulfillerComments);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}

	public void enterDestinationsInMTD(String Destinations) throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		// To fill MTD destinations
		if (Destinations != null) {
			boolean valuePresent = false;
			String[] DestinationsTextArrayList = Destinations.split(",");
			int NoOfDestination = fullfilmentSectionDestionationList.size();
			Waits.waitForElement(addFulfillmentDestinationButton, WAIT_CONDITIONS.CLICKABLE);
			WebAction.click(addFulfillmentDestinationButton);
			int j = 0;
			for (int k = 0; k < DestinationsTextArrayList.length; k++) {
				String destinationsInputBoxXpath = destinationsInputBox.replace("<<destinationsInputBoxNo>>",
						Integer.toString(NoOfDestination + k + 1));
				WebElement destinationsInputBoxtWebElement = driver.findElement(By.xpath(destinationsInputBoxXpath));
				Waits.waitForElement(destinationsInputBoxtWebElement, WAIT_CONDITIONS.CLICKABLE);
				WebAction.click(destinationsInputBoxtWebElement);
				Waits.waitUntilElementSizeGreater(By.xpath(dropDownvaluesXpath), 0);
				for (WebElement ele : dropDownvalues) {
					if (WebAction.getAttribute(ele, "title").equalsIgnoreCase(DestinationsTextArrayList[k].trim())) {
						WebAction.clickUsingJs(ele);
						valuePresent = true;
						break;
					}
				}
				j++;
				if (j < DestinationsTextArrayList.length) {
					Waits.waitForElement(addFulfillmentDestinationButton, WAIT_CONDITIONS.CLICKABLE);
					WebAction.click(addFulfillmentDestinationButton);
				}
			}
		}
	}

	/**
	 * To verify status background color
	 *
	 * @param typeOfCss
	 * @param status
	 * @param expectedColor
	 * @throws Exception
	 */
	public void verifyStatusBackgroundColorInECM(String typeOfCss, String status, String expectedColor)
			throws Exception {
		try {
			WebDriver driver = DriverFactory.getCurrentDriver();
			String requestNumber = Constants.getRequestNumber();
			// String requestNumber = "SR-08302024-00316914";
			// To add request number in allure report
			// AllureUtility.addParameter("Request Number", requestNumber);
			WebElement requestIDField = driver
					.findElement(By.xpath(findRequestById.replace("<<RequestId>>", requestNumber)));
			Waits.waitForElement(requestIDField, WAIT_CONDITIONS.VISIBLE);
			Waits.waitForElement(requestIDField, WAIT_CONDITIONS.CLICKABLE);

			try {
				WebAction.mouseOver(requestIDField);
				Thread.sleep(2000);
			} catch (Exception e) {
				WebAction.clickUsingJs(requestIDField);
			}
			String actualStatus = WebAction
					.getText(driver.findElement(By.xpath("//div[contains(@class,'tooltip-title')]//span[2]"))).trim();

			if (!(actualStatus.equalsIgnoreCase(status))) {
				throw new Exception("Status of the request is not correct. Expected status is '" + status
						+ "' and actual status is '" + actualStatus + "'");
			}
			CommonValidations.verifyCssValueOfWebElement(requestIDField, typeOfCss, expectedColor);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
}
