package nbcu.automation.ui.stepdefs.ncxUnifiedTool;

import java.util.List;
import java.util.Map;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.ncxUnifiedTool.ProdRockCenterRequestFormPage;
import nbcu.automation.ui.pages.ncxUnifiedTool.ProdSingleCameraLiveShotRequestFormPage;
import nbcu.automation.ui.pages.ncxUnifiedTool.ProducerDashboardGeneralPage;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.utils.cucumber.CucumberUtils;
import nbcu.framework.utils.propertyfilereader.ExcelReader;

public class ProdSingleCameraLiveShotRequestFormPageSteps {

	ProdSingleCameraLiveShotRequestFormPage prodSingleCameraLiveShotRequestFormPage = new ProdSingleCameraLiveShotRequestFormPage();
	CommonValidations commonValidations = new CommonValidations();
	ProducerDashboardGeneralPage producerDashboardGeneralPage = new ProducerDashboardGeneralPage();

	@Then("Verify error message is displayed for all mandatory fields in Set Information section In Single Camera Live Shot Production Form")
	public void verifySetInformationMissingFieldError(DataTable dataTable) throws Exception {
		prodSingleCameraLiveShotRequestFormPage.verifySetInformationMissingFieldError(
				CucumberUtils.getValuesFromDataTable(dataTable, "Set Background Error"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Set Staging Needed Error"));
	}

	@When("user enters set information in Single Camera Live Shot Production form")
	public void fillSetInformation(DataTable dataTable) throws Exception {
		prodSingleCameraLiveShotRequestFormPage.selectSetInformation(
				CucumberUtils.getValuesFromDataTable(dataTable, "Set Background"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Set Staging Needed"));
	}

	@When("user enters set crew in Single Camera Live Shot Production form")
	public void fillSystemInfoInRockCenterProduction(DataTable dataTable) throws Exception {
		prodSingleCameraLiveShotRequestFormPage.addSetCrew(
				CucumberUtils.getValuesFromDataTable(dataTable, "Capture Manager"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Set Crew"));
	}

	@Then("user verifies the form sections on Single Camera Live Shot production form")
	public void verifyTheFormSectionsInSingleCameraLiveShotForm() {
		prodSingleCameraLiveShotRequestFormPage.verifyTheFormSectionsInSingleCameraLiveShotForm();
	}

	@Then("user verifies the fields present in {string} section of Single Live Camera Shot form")
	public void verifyFieldsPresentOnSectionOfSingleCameraLiveShot(String sectionName) {
		if (sectionName != null) {
			prodSingleCameraLiveShotRequestFormPage.checkFieldsInSectionOfSingleCameraLiveShot(sectionName);
		}
	}

	@When("user provides notes under Details and Notes section")
	public void addDetailsAndNotes(DataTable dataTable) throws Exception {
		prodSingleCameraLiveShotRequestFormPage
				.addDetailsAndNotes(CucumberUtils.getValuesFromDataTable(dataTable, "Notes"));
	}

	@When("user selects set background option from the dropdown")
	public void selectSetBackground(DataTable dataTable) throws Exception {
		prodSingleCameraLiveShotRequestFormPage
				.selectSetBackground(CucumberUtils.getValuesFromDataTable(dataTable, "Set Background"));
	}

	@Then("verify all fields in the Single Camera Live Shot form are matching with columns in production dashboard")
	public void verifySingleCameraLiveShotProductionDashboardValuesWithForm(DataTable dataTable) throws Exception {
		prodSingleCameraLiveShotRequestFormPage.verifySingleCameraLiveShotRequestValuesWithProductionDashboardValues(
				CucumberUtils.getValuesFromDataTable(dataTable, "Requesters"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Prod Date"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Show/Project"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Production Purpose"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Set Location"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Control Room"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Positions"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Submitted"));
	}
}
