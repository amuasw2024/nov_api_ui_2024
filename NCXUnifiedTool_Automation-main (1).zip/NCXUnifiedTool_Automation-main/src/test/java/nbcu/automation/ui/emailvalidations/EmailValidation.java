package nbcu.automation.ui.emailvalidations;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.BodyPart;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.internet.MimeMultipart;

import org.testng.Assert;

import nbcu.automation.ui.constants.ncxUnifiedTool.Constants;
import nbcu.automation.ui.pages.ncxUnifiedTool.ProducerDashboardGeneralPage;
import nbcu.framework.utils.encryption.PasswordEncryption;
//import nbcu.automation.ui.constants.gtreplatform.BookingGuestConstants;
//import nbcu.automation.ui.constants.gtreplatform.GuestProfileConstants;
//import nbcu.framework.utils.others.DateFunctions;
import nbcu.framework.utils.propertyfilereader.ConfigFileReader;
import nbcu.framework.utils.ui.WebAction;

public class EmailValidation {

	/**
	 * To read email content
	 * 
	 * @param store
	 * @throws NumberFormatException
	 * @throws Exception
	 */
	public void verifyEmailReceived(String emailReceived, String status)
			throws NumberFormatException, Exception {
		
		Store store = null;
		String userName = "";
		boolean emailCheck = false;
		try {


			// To fetch gmail host, user name and password from config.properties
			String host = ConfigFileReader.getProperty("Gmail-Host","emailconfig.properties");
			userName = ConfigFileReader.getProperty("Gmail-UserName","emailconfig.properties");
			
			String password = ConfigFileReader.getProperty("Gmail-Password","emailconfig.properties");

			Folder emailFolder = null;
			String subject = "", toList = "", ccList = "", emailBody = "";

			// create properties
			Properties properties = new Properties();

			properties.put("mail.imap.host", host);
			properties.put("mail.imap.port", "993");
			properties.put("mail.pop3.starttls.enable", "true");

			Session emailSession = Session.getDefaultInstance(properties);

			// create the pop3 store object and connect to the pop3 server
			store = emailSession.getStore("imaps");

			
			store.connect(host, userName, password);

			outer: for (int waitCount = 0; waitCount < 2; waitCount++) {
				// wait for 10 seconds
				Thread.sleep(10000);

				// create the folder object and open it
				emailFolder = store.getFolder("INBOX");
				emailFolder.open(Folder.READ_WRITE);

				// retrieve the messages from the folder in an array and print it
				Message[] messages = emailFolder.getMessages();
				System.out.println("messages.length---" + messages.length);


				for (int i = messages.length - 1; i >= messages.length - 5; i--) {
					Message message = messages[i];
					System.out.println("---------------------------------");
					System.out.println("Email Number " + (i + 1));
					subject = message.getSubject();

					emailBody = getTextFromMessage(message);

					emailCheck = emailBody.contains(status.toUpperCase()+" - "+Constants.getRequestNumber());
					
					if(emailCheck) {
					
						if (message.getRecipients(Message.RecipientType.TO) != null) {
							for (Address address : message.getRecipients(Message.RecipientType.TO)) {
								toList = toList + address.toString() + ",";
							}
							toList = toList.substring(0, toList.length() - 1);
						}

						if (message.getRecipients(Message.RecipientType.CC) != null) {
							for (Address address : message.getRecipients(Message.RecipientType.CC)) {
								ccList = ccList + address.toString() + ",";
							}
							ccList = ccList.substring(0, ccList.length() - 1);
						}
						
						EmailConstants.setEmailSubject(subject.replace("  ", " "));
						EmailConstants.setEmailToList(toList);
						EmailConstants.setEmailCcList(ccList);
						EmailConstants.setEmailBody(emailBody);
						
						break outer;
					}else {
						subject = "";
						toList = "";
						ccList = "";
						emailBody = "";
					}
				
				}
			}

			// Close email folder
			emailFolder.close(false);
			// close the store and folder objects
			store.close();

		
		} catch (MessagingException e) {
			store.close();
			e.printStackTrace();
			throw new Exception("Failed to connect email account -" + userName);
		} catch (Exception e) {
			store.close();
			e.printStackTrace();
			throw new Exception("Failed to connect email account -" + userName);
		}
	}

	/**
	 * To read email body
	 * 
	 * @param message
	 * @return
	 * @throws MessagingException
	 * @throws IOException
	 */
	private static String getTextFromMessage(Message message) throws MessagingException, IOException {
		String result = "";
		if (message.isMimeType("text/plain")) {
			result = message.getContent().toString();
		} else if (message.isMimeType("multipart/*")) {
			MimeMultipart mimeMultipart = (MimeMultipart) message.getContent();
			result = getTextFromMimeMultipart(mimeMultipart);
		} else if (message.isMimeType("text/html")) {
			String html = (String) message.getContent();
			result = org.jsoup.Jsoup.parse(html).text();
		}
		return result;
	}

	/**
	 * To read multi part email body
	 * 
	 * @param mimeMultipart
	 * @return
	 * @throws MessagingException
	 * @throws IOException
	 */
	private static String getTextFromMimeMultipart(MimeMultipart mimeMultipart) throws MessagingException, IOException {
		String result = "";
		int count = mimeMultipart.getCount();
		for (int i = 0; i < count; i++) {
			BodyPart bodyPart = mimeMultipart.getBodyPart(i);
			if (bodyPart.isMimeType("text/plain")) {
				result = result + "\n" + bodyPart.getContent();
				break; // without break same text appears twice in my tests
			} else if (bodyPart.isMimeType("text/html")) {
				String html = (String) bodyPart.getContent();
				result = result + "\n" + org.jsoup.Jsoup.parse(html).text();
			} else if (bodyPart.getContent() instanceof MimeMultipart) {
				result = result + getTextFromMimeMultipart((MimeMultipart) bodyPart.getContent());
			}
		}
		return result;
	}

	/*
	 * private static boolean checkEmailIsPresent(String emailBody, String
	 * bookingType, String expectedShowName, String expectedGuestName, String
	 * showDate, String showTime, String expectedStudio, String expectedTopicName)
	 * throws MessagingException, IOException { boolean emailCheck = false; try { if
	 * ((bookingType.equalsIgnoreCase("NEW BOOKING")) ||
	 * (bookingType.equalsIgnoreCase("EDITED BOOKING"))) { if
	 * ((emailBody.toLowerCase().contains(expectedShowName.toLowerCase())) &&
	 * (emailBody.toLowerCase().contains(expectedGuestName.toLowerCase())) &&
	 * (emailBody.toLowerCase().contains(showDate)) &&
	 * (emailBody.toLowerCase().contains(showTime.toLowerCase())) &&
	 * (emailBody.toLowerCase().contains(expectedStudio.toLowerCase())) &&
	 * (emailBody.toLowerCase().contains(expectedTopicName.toLowerCase()))) {
	 * emailCheck = true; }
	 * 
	 * } else if (bookingType.equalsIgnoreCase("CANCEL BOOKING")) { if
	 * ((emailBody.toLowerCase().contains(expectedShowName.toLowerCase())) &&
	 * (emailBody.toLowerCase().contains(expectedGuestName.toLowerCase())) &&
	 * (emailBody.toLowerCase().contains(showDate)) &&
	 * (emailBody.toLowerCase().contains("cancelled"))) { emailCheck = true; } }
	 * else if (bookingType.equalsIgnoreCase("DUPLICATE BOOKING")) { showTime =
	 * DateFunctions.convertDateStringToAnotherFormat(BookingGuestConstants.
	 * getDuplicateBookingShowTime(), "HH:mm", "hh:mm:ss a"); if
	 * ((emailBody.toLowerCase().contains(expectedShowName.toLowerCase())) &&
	 * (emailBody.toLowerCase().contains(expectedGuestName.toLowerCase())) &&
	 * (emailBody.toLowerCase().contains(showDate)) &&
	 * (emailBody.toLowerCase().contains(showTime.toLowerCase())) &&
	 * (emailBody.toLowerCase().contains(expectedTopicName.toLowerCase())) &&
	 * (emailBody.toLowerCase().contains("duplicate booking alert"))) { emailCheck =
	 * true; } } else Assert.assertTrue(false,
	 * "Enter valid booking type for email check"); } catch (Exception e) {
	 * e.printStackTrace(); } return emailCheck; }
	 */

	public static void main(String[] args) throws Exception {

		/*
		 * String host = "imap.gmail.com"; String mailStoreType = "imap"; String
		 * username = "mag459new@gmail.com"; String password = "ednkpqmqnwiiyxfs";
		 */

	//	EmailValidation email = new EmailValidation();
		//email.verifyEmailReceived("received", "NEW");

		List<String> listA   = new ArrayList<String>();
		
		listA.add("A");
		listA.add("B");
		List<String> listB   = new ArrayList<String>();
		
		listB.add("B");
		listB.add("A");
		
		Collections.sort(listA); Collections.sort(listB);
		Assert.assertEquals(listA, listB);
	}
	
	
	public void validateTOandCCList(String ToOrCCList) throws Exception {
		
		if(ToOrCCList.equals("ToList")) {		
			String tolist[]= EmailConstants.getEmailToList().split(",");
			List<String> toListArray = new ArrayList<String>();
			for (String item : tolist) {
				toListArray.add(item);
			}
			Collections.sort(toListArray);
			Collections.sort(ProducerDashboardGeneralPage.emailtoList);
			Assert.assertEquals(toListArray, ProducerDashboardGeneralPage.emailtoList);
		}else if(ToOrCCList.equals("CcList")) {
			String cclist[]= EmailConstants.getEmailCcList().split(",");
			List<String> ccListArray = new ArrayList<String>();
			for (String item : cclist) {
				ccListArray.add(item);
			}
			System.out.println("Email CC List "+ProducerDashboardGeneralPage.emailCCList);
			System.out.println("Constant CC List "+ccListArray);
			Collections.sort(ccListArray); Collections.sort(ProducerDashboardGeneralPage.emailCCList);
			Assert.assertEquals(ccListArray, ProducerDashboardGeneralPage.emailCCList);
		}
	}
}

