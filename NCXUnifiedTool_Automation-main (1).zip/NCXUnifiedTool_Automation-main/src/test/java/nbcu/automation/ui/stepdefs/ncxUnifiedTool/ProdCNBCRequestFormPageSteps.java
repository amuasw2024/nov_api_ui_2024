package nbcu.automation.ui.stepdefs.ncxUnifiedTool;

import java.util.List;
import java.util.Map;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.ncxUnifiedTool.ProdCNBCRequestFormPage;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.utils.cucumber.CucumberUtils;

public class ProdCNBCRequestFormPageSteps {

	ProdCNBCRequestFormPage prodCNBCRequestFormPage = new ProdCNBCRequestFormPage();

	// CNBC Production error field validation
	@Then("Verify error message is displayed for all mandatory fields in set Location info section In CNBC Production Form")
	public void verifySetLocationMissingFieldErrorInProductionSection(DataTable dataTable) throws Exception {
		prodCNBCRequestFormPage
				.verifySetLocationMissingFieldError(CucumberUtils.getValuesFromDataTable(dataTable, "Location Error"));
	}

	@Then("Verify error message is displayed for all mandatory fields in Control Room section In CNBC Production Form")
	public void verifyControlRoomMissingFieldErrorInProductionSection(DataTable dataTable) throws Exception {
		prodCNBCRequestFormPage.verifyControlRoomNeededMissingFieldError(
				CucumberUtils.getValuesFromDataTable(dataTable, "control Room Needed Error"));
	}

	// CNBC Production filling form
	@When("user enters show information in CNBC Production form")
	public void fillShowInfoInCNBCProduction(DataTable dataTable) throws Exception {
		prodCNBCRequestFormPage.addShowInfoInCNBCProduction(
				CucumberUtils.getValuesFromDataTable(dataTable, "Air Platform"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Sub Division"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Show or Project Name"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Start Date"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Call Time"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Start Time"),
				CucumberUtils.getValuesFromDataTable(dataTable, "End Time"));
	}

	@When("user enters set location information in CNBC Production form")
	public void fillSetLocationInfoInCNBCProduction(DataTable dataTable) throws Exception {
		prodCNBCRequestFormPage
				.addSetLocationInfoInCNBCProduction(CucumberUtils.getValuesFromDataTable(dataTable, "Location"));
	}

	@When("user enters staging information in CNBC Production form")
	public void fillStagingInfoInCNBCProduction(DataTable dataTable) throws Exception {
		prodCNBCRequestFormPage
				.addStagingInfoInCNBCProduction(CucumberUtils.getValuesFromDataTable(dataTable, "Staging Needs"));
	}

	@When("user enters control room information in CNBC Production form")
	public void fillControlRoomInfoInCNBCProduction(DataTable dataTable) throws Exception {
		prodCNBCRequestFormPage.addControlRoomInfoInCNBCProduction(
				CucumberUtils.getValuesFromDataTable(dataTable, "Control Room Needed"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Ingest"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Iso"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Control Room Crew"));
	}
	@When("user selects `Is a Control Room Needed?` in CNBC production form")
	public void selectIsAControlRoomNeeded(DataTable dataTable) throws Exception {
		String option = CucumberUtils.getValuesFromDataTable(dataTable, "Is a Control Room Needed?");
		prodCNBCRequestFormPage.selectRadioOption("Is a Control Room Needed?",option);
	}
	@Then("user verifies that Control Room Crew section and fields under the section are not displayed in CNBC production form")
	public void verifyThatControlRoomCrewSectionAndRelatedFieldsAreNotDisplayed() throws Exception {
		prodCNBCRequestFormPage.verifyIfControlRoomCrewSectionAndRelatedFieldsShouldDisplayOrNot();
	}
	@Then("user verifies that Control Room Crew section and fields under the section are displayed in CNBC production form")
	public void verifyThatControlRoomCrewSectionAndRelatedFieldsAreDisplayed() throws Exception {
		prodCNBCRequestFormPage.verifyIfControlRoomCrewSectionAndRelatedFieldsShouldDisplayOrNot();
	}
	@When("user selects `Is Budget Code Available?` on CNBC Production")
	public void selectIsBudgetCodeAvailable(DataTable dataTable) throws Exception {
		String option=CucumberUtils.getValuesFromDataTable(dataTable, "Is Budget Code Available?");
		prodCNBCRequestFormPage.selectRadioOption("Is Budget Code Available?",option);
	}
	@Then("user verifies `Budget Code` input is disabled")
	public void verifyIfBudgetCodeInputIsEnabled() {
		prodCNBCRequestFormPage.shouldBudgetCodeInputBeEnabled();
	}
	@Then("user verifies `Budget Code` input is enabled")
	public void verifyIfBudgetCodeInputIsDisabled() {
		prodCNBCRequestFormPage.shouldBudgetCodeInputBeEnabled();
	}
	@Then("user verifies the form title on CNBC production")
	public void verifyFormTitle() throws Exception {
		prodCNBCRequestFormPage.getProducerDashboardGeneralPage().verifySelectedRequestPageDisplayed("CNBC Production");
	}
	@Then("user verifies the form sections on CNBC production form")
	public void verifyTheFormSectionsInCnbcProductionForm() {
		prodCNBCRequestFormPage.verifyTheFormSectionsInCnbcProductionForm();
	}
	@Then("user verifies the fields present in {string} section of CNBC Production form")
	public void verifyFieldsPresentSectionOfCnbcProduction(String sectionName) {
		prodCNBCRequestFormPage.checkFieldsInSectionOfCnbcProduction(sectionName);
	}
	@When("user selects {string} as Division on CNBC Production")
	public void selectDivision(String option) throws Exception {
		prodCNBCRequestFormPage.selectValueInDropdown(option,"Division");
	}
	@When("user selects {string} as Show Unit or Project Name on CNBC Production")
	public void selectShowUnitOrProjectName(String option) throws Exception {
		prodCNBCRequestFormPage.selectValueInDropdown(option,"Show Unit or Project Name");
	}
	@When("user clicks `+ Control Room` {string} times on CNBC Production")
	public void addControlRoom(String timesStr) {
		int times = Integer.parseInt(timesStr);
		prodCNBCRequestFormPage.addControlRoom(times);
	}
	@When("user populates GENERAL DETAILS section on CNBC Production request")
	public void populateGeneralDetailsSection(DataTable dataTable) throws Exception {
		String option = CucumberUtils.getValuesFromDataTable(dataTable, "Division");
		prodCNBCRequestFormPage.selectValueInDropdown(option,"Division");
	}
	@When("user populates PRODUCTION PURPOSE section on CNBC Production request")
	public void populateProductionPurposeSection(DataTable dataTable) throws Exception {
		String requestFor = CucumberUtils.getValuesFromDataTable(dataTable, "Request For");
		String detailsAndNotes = CucumberUtils.getValuesFromDataTable(dataTable, "Details & Notes");
		prodCNBCRequestFormPage.populateProductionPurposeSection(requestFor, detailsAndNotes);
	}
	@When("user selects {string} as Request For in Production Purpose section on CNBC Production request")
	public void selectRequestForInProductionPurpose(String requestFor) throws Exception {
		prodCNBCRequestFormPage.selectValueInDropdown(requestFor,"Request For");
	}
	@When("user gives {string} as Details & Notes in Production Purpose section on CNBC Production request")
	public void giveDetailsAndNotesInProductionPurpose(String detailsAndNotes){
		prodCNBCRequestFormPage.fillTextbox("Details & Notes", detailsAndNotes);
	}
	@When("user selects Location in {string} section on CNBC Production request")
	public void selectLocation(String section,DataTable dataTable) throws Exception {
		String option = CucumberUtils.getValuesFromDataTable(dataTable, "Location");
		prodCNBCRequestFormPage.selectValueInDropdown(option,"Location");
	}
	@Then("user checks error for {string} required field in {string} section on CNBC Production request")
	public void checkRequiredFieldErrorIfEmpty(String field, String sectionName){
		prodCNBCRequestFormPage.verifyErrorBelowFieldIfEmpty(field);
	}
	@Then("user checks error not displayed for {string} required field in {string} section on CNBC Production request")
	public void checkRequiredFieldErrorIfNotEmpty(String field, String sectionName){
		prodCNBCRequestFormPage.verifyErrorBelowFieldIfNotEmpty(field);
	}
	@Then("user checks placeholder of {string} field in {string} section on CNBC Production request")
	public void checkPlaceholderOfField(String field, String sectionName) {
		prodCNBCRequestFormPage.checkPlaceholderOfSelectFields(field);
	}
	@When("user selects Control Room Crew in {string} section on CNBC Production request")
	public void selectControlRoomCrew(String section,DataTable dataTable) throws Exception {
		String option=CucumberUtils.getValuesFromDataTable(dataTable, "Control Room Crew");
		prodCNBCRequestFormPage.selectValueInDropdown(option,"Control Room Crew");
	}
	@When("user selects ISO: Do you need ISO recordings? in {string} section on CNBC Production request")
	public void chooseDoYouNeedIsoRecordings(String section,DataTable dataTable) throws Exception {
		String option=CucumberUtils.getValuesFromDataTable(dataTable, "ISO: Do you need ISO recordings?");
		prodCNBCRequestFormPage.selectRadioOption("ISO: Do you need ISO recordings?",option);
	}
	@When("user selects Ingest: Do you need content to be recorded? in {string} section on CNBC Production request")
	public void chooseIngestDoYouNeedContentToBeRecorded(String section,DataTable dataTable) throws Exception {
		String option=CucumberUtils.getValuesFromDataTable(dataTable, "Ingest: Do you need content to be recorded?");
		prodCNBCRequestFormPage.selectRadioOption("Ingest: Do you need content to be recorded?",option);
	}
	@When("user selects Staging Needs in {string} section on CNBC Production request")
	public void provideStagingNeeds(String section,DataTable dataTable) throws Exception {
		String option = CucumberUtils.getValuesFromDataTable(dataTable, "Staging Needs");
		prodCNBCRequestFormPage.fillTextbox("Staging Needs", option);
	}
	@When("user selects Set Crew in {string} section on CNBC Production request")
	public void selectSetCrew(String section,DataTable dataTable) throws Exception {
		String option = CucumberUtils.getValuesFromDataTable(dataTable, "Set Crew");
		prodCNBCRequestFormPage.selectValueInDropdown(option,"Set Crew");
	}
	
	@Then("verify all fields in the CNBC form are matching with columns in production dashboard")
	public void verifyCNBCProductionDashboardValuesWithForm(DataTable dataTable) throws Exception {
		prodCNBCRequestFormPage.verifyCNBCRequestValuesWithProductionDashboardValues(
				CucumberUtils.getValuesFromDataTable(dataTable, "Requesters"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Prod Date"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Show/Project"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Production Purpose"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Set Location"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Control Room"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Positions"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Submitted"));
	}
}
