package nbcu.automation.ui.pojos.ncxUnifiedTool;

public class LocationRecord {
	private String location;
	private String setLocation;
	private String address;
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getSetLocation() {
		return setLocation;
	}
	public void setSetLocation(String setLocation) {
		this.setLocation = setLocation;
	}
	public LocationRecord(String location, String setLocation) {
		super();
		this.location = location;
		this.setLocation = setLocation;
	}
	public LocationRecord() {
		super();
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public LocationRecord(String location, String setLocation, String address) {
		super();
		this.location = location;
		this.setLocation = setLocation;
		this.address = address;
	}
	@Override
	public String toString() {
		return "LocationRecord [location=" + location + ", setLocation=" + setLocation + ", address=" + address + "]";
	}
}
