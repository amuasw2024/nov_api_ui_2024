package nbcu.automation.ui.stepdefs.ncxUnifiedTool;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.pages.ncxUnifiedTool.ContentManagementRequestFormPage;
import nbcu.automation.ui.pages.ncxUnifiedTool.EditRequestFormPage;
import nbcu.automation.ui.pages.ncxUnifiedTool.ProducerDashboardGeneralPage;
import nbcu.framework.utils.cucumber.CucumberUtils;

public class ContentManagementRequestFormPageSteps {

	ProducerDashboardGeneralPage producerDashboardGeneralPage = new ProducerDashboardGeneralPage();
	EditRequestFormPage editRequestFormPage = new EditRequestFormPage();
	ContentManagementRequestFormPage contentManagementRequestFormPage = new ContentManagementRequestFormPage();

	@When("user enters General info in Feed Out Request form")
	@When("user enters General info in File Ingest Request form")
	public void addProducerInfoinGeneralSectionInContentManagementForm(DataTable dataTable) throws Exception {
		producerDashboardGeneralPage.addGeneralInfo(CucumberUtils.getValuesFromDataTable(dataTable, "Slug"),
				CucumberUtils.getValuesFromDataTable(dataTable, "NCX Story Name"));
		producerDashboardGeneralPage.selectDivision(CucumberUtils.getValuesFromDataTable(dataTable, "Division"));
		producerDashboardGeneralPage
				.additionalRequestersListInfo(CucumberUtils.getValuesFromDataTable(dataTable, "Additional Requesters"));
		editRequestFormPage
				.fillAdditionalRecipients(CucumberUtils.getValuesFromDataTable(dataTable, "Additional Recipients"));
		producerDashboardGeneralPage
				.addProducerInfo(CucumberUtils.getValuesFromDataTable(dataTable, "Is Producer Same as Requestor"));
		producerDashboardGeneralPage
				.enterSeniorProducerValue(CucumberUtils.getValuesFromDataTable(dataTable, "Sr Producer"));
		producerDashboardGeneralPage.enterTalentValue(CucumberUtils.getValuesFromDataTable(dataTable, "Talent"));
	}

	@When("user enters show info Information in MTD Request form")
	@When("user enters show info Information in Feed Out Request form")
	@When("user enters show info Information in File Ingest Request form")
	public void fillShowInfoInContentManagement(DataTable dataTable) throws Exception {
		editRequestFormPage.addShowInfoInECM(CucumberUtils.getValuesFromDataTable(dataTable, "Show Unit"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Budget Code"));
		editRequestFormPage.addAirDateTimeInfo(CucumberUtils.getValuesFromDataTable(dataTable, "Air Date"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Air Time"));
	}

	@When("user enters Date Needed By and Time Needed By info in MTD Request form")
	@When("user enters Date Needed By and Time Needed By info in Feed Out Request form")
	@When("user enters Date Needed By and Time Needed By info in File Ingest Request form")
	public void fillDateNeededByTimeNeededBy(DataTable dataTable) throws Exception {
		contentManagementRequestFormPage.fillDateNeededByTimeNeededBy(
				CucumberUtils.getValuesFromDataTable(dataTable, "Date Needed By"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Time Needed By"));
	}

	@When("user enters source info in File Ingest Request form")
	public void fillSourceInFileIngest(DataTable dataTable) throws Exception {
		contentManagementRequestFormPage.fillSource(CucumberUtils.getValuesFromDataTable(dataTable, "Source"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Quantity"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Comments"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Camera"));
	}

	@When("user selects Final Destination in Feed Out Request form")
	@When("user selects Final Destination in File Ingest Request form")
	public void fillFinalDestinationSection(DataTable dataTable) throws Exception {
		contentManagementRequestFormPage
				.fillDestinationDetails(CucumberUtils.getValuesFromDataTable(dataTable, "Final Destination"));
	}

	@When("user enters content description info in Feed Out Request form")
	@When("user enters content description info in File Ingest Request form")
	public void fillContentDescriptionSection(DataTable dataTable) throws Exception {
		contentManagementRequestFormPage
				.fillContentDescriptionInCM(CucumberUtils.getValuesFromDataTable(dataTable, "Content Description"));
	}

	@When("user enters comments info in Feed Out Request form")
	@When("user enters comments info in File Ingest Request form")
	public void fillCommentsSection(DataTable dataTable) throws Exception {
		contentManagementRequestFormPage.fillCommentInCM(CucumberUtils.getValuesFromDataTable(dataTable, "Comments"));
	}

	@And("user enters fulfillment info in File Ingest Fulfillment section")
	public void user_enters_FileIngest_fulfillment_details(DataTable dataTable) throws Exception {
		contentManagementRequestFormPage.fileIngestFillFulfullmentSection(
				CucumberUtils.getValuesFromDataTable(dataTable, "Method Of Ingest"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Destinations"),
				CucumberUtils.getValuesFromDataTable(dataTable, "File Format"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Gig Size"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Clip Count"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Folder Format"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Bin Name"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Media ID"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Assistant Editor Assigned"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Device Timer Hours"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Device Timer Minutes"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Device Timer Seconds"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Fulfiller Comments"));
	}

	@When("user enters source info in Feed Out Request form")
	public void fillSourceInFeedOut(DataTable dataTable) throws Exception {
		contentManagementRequestFormPage.fillSourceFeedOut(CucumberUtils.getValuesFromDataTable(dataTable, "Source"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Slug"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Quantity"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Comments"));
	}

	@And("user enters fulfillment info in Feed Out Fulfillment section")
	public void user_enters_Feedout_fulfillment_details(DataTable dataTable) throws Exception {
		contentManagementRequestFormPage.feedOutFillFulfullmentSection(
				CucumberUtils.getValuesFromDataTable(dataTable, "Destinations"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Media ID"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Feed Time"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Device Timer Hours"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Device Timer Minutes"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Device Timer Seconds"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Clip Count"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Fulfiller Comments"));
	}

	@When("user enters source info in MTD Request form")
	public void fillSourceInMTD(DataTable dataTable) throws Exception {
		contentManagementRequestFormPage.fillSourceInMTD(CucumberUtils.getValuesFromDataTable(dataTable, "Source"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Source Details"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Time Codes"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Camera"));
	}

	@When("user selects Final Destination in MTD Request form")
	public void fillFinalDestinationSectionINMTD(DataTable dataTable) throws Exception {
		contentManagementRequestFormPage.fillDestinationInMTD(
				CucumberUtils.getValuesFromDataTable(dataTable, "Destination"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Quantity"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Details"));
	}

	@When("user enters Instructions info in MTD Request form")
	public void fillInstructionsSection(DataTable dataTable) throws Exception {
		contentManagementRequestFormPage
				.fillInstructionsInCM(CucumberUtils.getValuesFromDataTable(dataTable, "Instructions"));
	}

	@And("user enters fulfillment info in MTD Fulfillment section")
	public void user_enters_MTD_fulfillment_details(DataTable dataTable) throws Exception {
		contentManagementRequestFormPage.MTDFillFulfullmentSection(
				CucumberUtils.getValuesFromDataTable(dataTable, "Destinations"),
				CucumberUtils.getValuesFromDataTable(dataTable, "File Format"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Gig Size"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Clip Count"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Device Timer Hours"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Device Timer Minutes"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Device Timer Seconds"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Fulfiller Comments"));
	}

	@Then("verify {string} of {string} status is {string} in ECM fullfiller dashboard")
	public void verifyStatusColorinECM(String cssType, String status, String expectedColor) throws Exception {
		contentManagementRequestFormPage.verifyStatusBackgroundColorInECM(cssType, status, expectedColor);
	}

}