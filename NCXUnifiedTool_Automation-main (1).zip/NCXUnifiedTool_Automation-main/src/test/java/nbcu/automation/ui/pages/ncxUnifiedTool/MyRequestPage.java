package nbcu.automation.ui.pages.ncxUnifiedTool;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import nbcu.automation.ui.constants.ncxUnifiedTool.Constants;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.utils.ui.Waits;
import nbcu.framework.utils.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.utils.ui.WebAction;
import nbcu.framework.factory.DriverFactory;
import static nbcu.framework.factory.DriverFactory.getCurrentDriver;

public class MyRequestPage {

	// Forms page button
	@FindBy(xpath = "//button[span[contains(text(),'New Request')]]")
	WebElement formsButton;

	@FindBy(xpath = "//div[contains(text(),'Select Request')]")
	WebElement selectRequestTitle;

	String dropDownvaluesXpath = "//div[@class='cdk-virtual-scroll-content-wrapper']/nz-option-item";

	@FindBy(xpath = "//div[@class='cdk-virtual-scroll-content-wrapper']/nz-option-item | //nz-option-item ")
	List<WebElement> dropDownvalues;

	String RequestType = "//div[@class='request-area']//span[contains(text(),'<<formName>>')]";

	@FindBy(xpath = "//a[contains(@href,'unified-requests/edit-self-reporting')]")
	WebElement editSelfReportingRequest;

	// Menu fold unfold icon
	@FindBy(xpath = "//*[@data-icon='menu-fold']")
	WebElement menuIconFold;

	@FindBy(xpath = "//*[@data-icon='menu-unfold']")
	WebElement menuIconUnfold;

	@FindBy(xpath = "//*[text()='Edit & Content Mgmt']")
	WebElement ecmIcon;

	// To fetch Request ID from success message
	String requestNumbersXpath = "//*[contains(@class,'modal-confirm-content')]/descendant::p[contains(@style,'color')]";
	// *[contains(@class,'modal-confirm-content')]/div

	@FindBy(xpath = "//*[contains(@class,'modal-confirm-content')]/descendant::p[contains(@style,'color')]")
	List<WebElement> requestIDFromSuccessMessage;

	// My request rows
	@FindBy(xpath = "//tr[contains(@class,'trCls')]")
	List<WebElement> myRequestRows;

	// to retrieve status by request id
	String findRequestById = "//td[p[a[text()='<<RequestId>>']]]";

	@FindBy(xpath = "//nz-avatar[i[*[@data-icon='user']]]")
	WebElement profileIcon;

	@FindBy(xpath = "//button[contains(text(),'Logout')]")
	WebElement logOutButton;

	@FindBy(xpath = "//*[contains(text(),'You have been logged out of this application')]")
	WebElement logOutMessage;

	@FindBy(xpath = "//input[@placeholder='Search']")
	WebElement searchTextBox;

	Map<String, String> map = new HashMap<>();

	@FindBy(xpath = "//*[@data-id='banner']//i")
	WebElement bannerCloseButton;

	@FindBy(xpath = "//section[@class='sub-header']//div[1]/nz-tag/span[2]")
	WebElement requestStatusLabel;

	@FindBy(xpath = "//span[text()='Request Submitted']/parent::span//following-sibling::div/div[text()]")
	WebElement reqSubmittedMsg;

	@FindBy(xpath = "//li//button[text()=' All Requests ']")
	WebElement allRequestsInDropdown;

	@FindBy(xpath = "//li//button[text()=' My Requests ']")
	WebElement myRequestsInDropdown;

	@FindBy(xpath = "//button[span[text()=' Yes ']]")
	WebElement cancel_Yes;

	@FindBy(xpath = "//button[span[text()=' No ']]")
	WebElement cancel_No;

	@FindBy(xpath = "//span[i[*[@data-icon='close']]]")
	WebElement closeMessagePopup;

	@FindBy(xpath = "//button[span[text()=' OK ']]")
	WebElement cancel_Ok;

	@FindBy(xpath = "//button[span[contains(text(),' Edit & Content Management')]]")
	WebElement EditContentManagementECMRequest;

	@FindBy(xpath = "//button[span[contains(text(),' Edit Self Reporting')]]")
	WebElement EditSelfReportingECMRequest;

	@FindBy(xpath = "//span[text()='Cancel Request']")
	WebElement cancelButton;

	@FindBy(xpath = "//button[span[contains(text(),'Confirm Cancel Request')]] | //button[span[contains(text(),'Confirm Cancellation')]]")
	WebElement confirmCancelRequestButton;

	@FindBy(xpath = "//a[text()='My Requests']")
	WebElement myRequestsDashboard;

	// Other WebElements

	@FindBy(xpath = "//*[@role='menuitem']/div")
	List<WebElement> SearchList;

	@FindBy(xpath = "//div[contains(@class, 'story-list-elem')]/button")
	List<WebElement> ncxStoryNamesdropDownvalues;

	// Next button
	@FindBy(xpath = "//span[text()='Next']")
	WebElement nextButton;

	@FindBy(xpath = "//span[text()='Exit ']")
	WebElement exitButton;

	@FindBy(xpath = "//span[contains(text(),'Submit')]")
	WebElement submitButton;

	@FindBy(xpath = "//*[@title='Producer Dashboard']")
	WebElement nbcuLogo;

	@FindBy(xpath = "(//span[contains(text(),'Edit')])[last()] |button[@class='ecm-fulfillment-btn ant-btn ant-btn-primary ant-btn-round ng-star-inserted']")
	WebElement editButton;

	@FindBy(xpath = "(//span[text()=' Add '])[1]")
	WebElement AddButtonForHandler;

	@FindBy(xpath = "(//span[text()=' Add '])[2]")
	WebElement AddButtonForAnimal;

	// Cancel Request button
	@FindBy(xpath = "(//button[span[contains(text(),'Cancel Request')]])[last()]")
	WebElement cancelRequestButton;

	@FindBy(xpath = "//*[@class='sub-headerText']//p")
	WebElement requestIdDisplayed;

	@FindBy(xpath = "//div[@class='title ng-star-inserted']")
	WebElement textDisplayed;

	@FindBy(xpath = "//div[@class='status-title']/p")
	WebElement statusText;

	@FindBy(xpath = "//*[@class='anticon anticon-down']")
	WebElement myRequestDropdownIcon;

	@FindBy(xpath = "(//span[@class='ng-star-inserted'])[2]")
	WebElement OkButton;

	@FindBy(xpath = "//*[@sectiontitle='Resources']//span[text()=' View Estimated Cost Breakdown ']")
	WebElement viewEstimatedCostBreakdown;

	@FindBy(xpath = "//*[@href='#/']")
	WebElement requestsDashboardButton;

	@FindBy(xpath = "//*[@data-id='subHeaderContainer']//button//i")
	WebElement changeViewButton;

	@FindBy(xpath = "//button[contains(text(),'My Requests')]")
	WebElement myRequestsButton;

	@FindBy(xpath = "//button[contains(text(),'All Requests')]")
	WebElement allRequestsButton;

	@FindBy(xpath = "//*[contains(@class,'ant-spin-dot-spin')]")
	WebElement loadingSpinner;

	@FindBy(xpath = "//td[2]//a")
	List<WebElement> requestIdsInTable;

	public MyRequestPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify my requests page loaded
	 * 
	 * @throws Exception
	 */
	public void verifyMyRequestsPageDisplayed() throws Exception {
		Waits.waitForElement(formsButton, WAIT_CONDITIONS.CLICKABLE);
	}

	/**
	 * To verify form selection page loaded
	 * 
	 * @throws Exception
	 */
	public void verifySelectRequestPanelDisplayed() throws Exception {
		Waits.waitForElement(selectRequestTitle, WAIT_CONDITIONS.VISIBLE);
	}

	/**
	 * To click + button
	 * 
	 * @throws Exception
	 */
	public void clickFormsButton() throws Exception {
		WebAction.click(formsButton);
	}

	/**
	 * To select given form from request
	 * 
	 * @throws Exception
	 */
	public void selectRequestForm(String formName) throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			if (formName.toUpperCase().equalsIgnoreCase("CNBC CREW")) {
				// To select CNBC crew request
				RequestType = "(//div[@class='request-area'])[2]//*[contains(text(),'CNBC')]";
				Waits.waitForElement(driver.findElement(By.xpath(RequestType)), WAIT_CONDITIONS.VISIBLE);
				Waits.waitForElement(driver.findElement(By.xpath(RequestType)), WAIT_CONDITIONS.CLICKABLE);
				WebAction.click(driver.findElement(By.xpath(RequestType)));
			} else if (formName.toUpperCase().equalsIgnoreCase("NEWS GEAR")) {
				// To select News gear request
				RequestType = "(//div[@class='request-area'])[4]//*[contains(text(),'News')]";
				Waits.waitForElement(driver.findElement(By.xpath(RequestType)), WAIT_CONDITIONS.VISIBLE);
				Waits.waitForElement(driver.findElement(By.xpath(RequestType)), WAIT_CONDITIONS.CLICKABLE);
				WebAction.click(driver.findElement(By.xpath(RequestType)));
			} else if (formName.toUpperCase().equalsIgnoreCase("STANDARD EDIT")
					|| formName.toUpperCase().equalsIgnoreCase("LONG EDIT")) {
				// To select edit request
				RequestType = RequestType.replace("<<formName>>", "Edit");
				Waits.waitForElement(driver.findElement(By.xpath(RequestType)), WAIT_CONDITIONS.VISIBLE);
				Waits.waitForElement(driver.findElement(By.xpath(RequestType)), WAIT_CONDITIONS.CLICKABLE);
				WebAction.click(driver.findElement(By.xpath(RequestType)));
			} else if (formName.toUpperCase().equalsIgnoreCase("EDIT SELF REPORTING")) {
				// To select edit self reporting request
				Waits.waitForElement(menuIconUnfold, WAIT_CONDITIONS.CLICKABLE);
				WebAction.click(menuIconUnfold);
				Waits.waitForElement(ecmIcon, WAIT_CONDITIONS.CLICKABLE);
				WebAction.click(ecmIcon);
				Waits.waitForElement(editSelfReportingRequest, WAIT_CONDITIONS.CLICKABLE);
				WebAction.click(editSelfReportingRequest);
			} else if (formName != null) {
				// To select request
				RequestType = RequestType.replace("<<formName>>", formName);
				Waits.waitForElement(driver.findElement(By.xpath(RequestType)), WAIT_CONDITIONS.VISIBLE);
				Waits.waitForElement(driver.findElement(By.xpath(RequestType)), WAIT_CONDITIONS.CLICKABLE);
				WebAction.click(driver.findElement(By.xpath(RequestType)));
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify background color of status in my request page
	 * 
	 * @param typeValueCSS  - type of css like background color, font family, etc.,
	 * @param status        - status of the request
	 * @param expectedColor - expected color of the status
	 * @throws Exception
	 */
	public void verifyStatusBackgroundColor(String typeOfCss, String status, String expectedColor) throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			String requestNumber = Constants.getRequestNumber();

			System.out.println("Req Number:" + requestNumber);
			// To add request number in allure report
			// AllureUtility.addParameter("Request Number", requestNumber);

			String statusXpath = findRequestById.replace("<<RequestId>>", requestNumber)
					+ "//preceding::td[1]//following-sibling::td[2]//span";
			WebElement statusElement = driver.findElement(By.xpath(statusXpath));
			String actualStatus = WebAction.getText(statusElement).trim();
			if (!(actualStatus.equalsIgnoreCase(status))) {
				throw new Exception("Status of the request is not correct. Expected status is '" + status
						+ "' and actual status is '" + actualStatus + "'");
			}
			// !
			CommonValidations.verifyCssValueOfWebElement(statusElement, typeOfCss, expectedColor);

		} catch (Exception e) {
			// AllureUtility.captureScreenshot("Status color Validation error");
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To logout of the application
	 * 
	 * @throws Exception
	 */
	public void logOut() throws Exception {
		Waits.waitForElement(profileIcon, WAIT_CONDITIONS.VISIBLE);
		try {
			WebAction.mouseOver(profileIcon);
			Thread.sleep(2000);
		} catch (Exception e) {
			WebAction.clickUsingJs(profileIcon);
		}

		WebAction.click(logOutButton);
		Thread.sleep(2000);
		WebAction.switchToFrame("header");
		Waits.waitForElement(logOutMessage, WAIT_CONDITIONS.VISIBLE);
		WebAction.switchToDefaultContent();
	}

	/**
	 * To search the request in requester table
	 * 
	 * @throws Exception
	 */
	public void searchRequest() throws Exception {
		try {

			// for (int i=0; i < map.size() ; i++)
			for (Map.Entry<String, String> e : map.entrySet()) {
				// System.out.println(e.getKey() + " " + e.getValue());
				Constants.setRequestNumber(e.getKey());
				break;
			}
			String requestNumber = Constants.getRequestNumber();
			Waits.waitForElement(searchTextBox, WAIT_CONDITIONS.CLICKABLE);
			WebAction.click(searchTextBox);
			Waits.waitUntilElementSizeGreater(myRequestRows, 0);
			WebAction.sendKeys(searchTextBox, requestNumber);
		} catch (Exception e) {
			// AllureUtility.captureScreenshot("Search request is not working in my request
			// page");
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click edit link of the request
	 * 
	 * @throws Exception
	 */
	public void clickEditLink() throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			String requestNumber = Constants.getRequestNumber();
			Waits.waitForElement(By.xpath(findRequestById.replace("<<RequestId>>", requestNumber)),
					WAIT_CONDITIONS.CLICKABLE);

			// To click edit link
			String editLinkXpath = findRequestById.replace("<<RequestId>>", requestNumber)
					+ "/following-sibling::td[a[text()='Edit']]/a";
			Waits.waitForElement(By.xpath(editLinkXpath), WAIT_CONDITIONS.CLICKABLE);
			WebAction.click(driver.findElement(By.xpath(editLinkXpath)));

		} catch (Exception e) {
			// AllureUtility.captureScreenshot("Request not found in my request page");
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click request ID link of the request
	 * 
	 * @throws Exception
	 */
	public void clickRequestIdLink() throws Exception {
		WebDriver driver = DriverFactory.getCurrentDriver();
		try {
			String requestNumber = Constants.getRequestNumber();
			// To click request ID link
			String requestIdLinkXpath = "//a[contains(text(),'" + requestNumber + "')]";
			Waits.waitForElement(By.xpath(requestIdLinkXpath), WAIT_CONDITIONS.CLICKABLE);
			WebAction.click(driver.findElement(By.xpath(requestIdLinkXpath)));

		} catch (Exception e) {
			// AllureUtility.captureScreenshot("Request not found");
			e.printStackTrace();
			throw e;
		}

	}

	/**
	 * To get request ids from successful message after user clicks submit button
	 * 
	 * @param formName - form name
	 * @throws Exception
	 */
	public void getRequestID() throws Exception {
		String requestNumber = "";
		try {
			WebDriver driver = DriverFactory.getCurrentDriver();
			WebElement requestNumberWebElement = driver
					.findElement(By.xpath("//*[contains(@class,'modal-confirm-content')]/descendant::div"));
			Waits.waitForElement(requestNumberWebElement, WAIT_CONDITIONS.VISIBLE);
			String requestNumberWithSuccessMessage = WebAction.getText(requestNumberWebElement);
			if (!(requestNumberWithSuccessMessage.contains("The request is NOT booked"))) {
				String[] requestNumberWithRequestTypearr = requestNumberWithSuccessMessage.split("\"");
				requestNumber = requestNumberWithRequestTypearr[1].trim();
				// requestNumber =
				// requestNumberWithRequestTypearr[0].substring(1,requestNumberWithRequestTypearr[0].length()
				// - 1);
				Constants.setRequestNumber(requestNumber);
			}
			if (requestNumber.isEmpty()) {
				clickOption("close");
				throw new Exception("Submitted request ID is not present in success pop up");
			}
		} catch (Exception e) {
			// AllureUtility.captureScreenshot("Request ID not present in success pop up");
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click x button in Test Version Banner
	 * 
	 * @throws Exception
	 */
	public void clickCloseButtonInTestVersionBanner() throws Exception {
		if (WebAction.isDisplayed(bannerCloseButton)) {
			WebAction.click(bannerCloseButton);
		}

	}

	/**
	 * To verify submitted request is present in the my request page
	 * 
	 * @param formName - form name
	 * @throws Exception
	 */
	public void verifyProductionRequestInmyRequestPage(String formName, String status) throws Exception {
		String requestNumber = "";
		String RequestType = "";
		try {
			// To check form name
			if (formName.toUpperCase().equalsIgnoreCase("NEWS GEAR")) {
				formName = "News Gear";
				RequestType = "GEAR REQUEST";
			} else if (formName.toUpperCase().equalsIgnoreCase("ROCK CENTER")) {
				formName = "Rock Center Production Request";
				RequestType = "PRODUCTION REQUEST";
			} else if (formName.toUpperCase().equalsIgnoreCase("CNBC")) {
				formName = "CNBC Production Request";
				RequestType = "PRODUCTION REQUEST";
			} else if (formName.toUpperCase().equalsIgnoreCase("ANIMALS ON PREMISES")) {
				formName = "Animals on Premises";
				RequestType = "PRODUCTION REQUEST";
			} else if (formName.toUpperCase().equalsIgnoreCase("FIREARMS ON PREMISES")) {
				formName = "FireArms Request";
				RequestType = "PRODUCTION REQUEST";
			} else if (formName.toUpperCase().equalsIgnoreCase("SINGLE CAMERA LIVE SHOT")) {
				formName = "Single Camera Live Shot";
				RequestType = "PRODUCTION REQUEST";
			} else if (formName.toUpperCase().contains("EXTEND OR BRIDGE CREW & FACILITIES")) {
				formName = "Extended or Bridge Crew and Facilities";
				RequestType = "PRODUCTION REQUEST";
			} else if (formName.toUpperCase().equalsIgnoreCase("NBC NEWS")) {
				formName = "General Crew Request";
				RequestType = "CREW REQUEST";
			} else if (formName.toUpperCase().equalsIgnoreCase("CNBC CREW")) {
				formName = "CNBC Crew";
				RequestType = "CREW REQUEST";
			} else if (formName.toUpperCase().equalsIgnoreCase("TELEMUNDO NEWS")) {
				formName = "Telemundo Crew";
				RequestType = "CREW REQUEST";
			} else if (formName.toUpperCase().equalsIgnoreCase("DIGITAL JOURNALIST / DJ SHOOT")) {
				formName = "Digital Journalist";
				RequestType = "CREW REQUEST";
			} else if (formName.toUpperCase().equalsIgnoreCase("NBC BREAKING NEWS")) {
				formName = "Breaking News";
				RequestType = "CREW REQUEST";
			} else if (formName.toUpperCase().equalsIgnoreCase("NBC BUREAU CAMERA")) {
				formName = "Bureau Camera";
				RequestType = "CREW REQUEST";
			} else if (formName.toUpperCase().equalsIgnoreCase("STANDARD EDIT")) {
				formName = "Standard Edit";
				RequestType = "EDIT";
			} else if (formName.toUpperCase().equalsIgnoreCase("LONG EDIT")) {
				formName = "Long Form Edit";
				RequestType = "EDIT";
			} else if (formName.toUpperCase().equalsIgnoreCase("FILE INGEST")) {
				formName = "File Ingest";
				RequestType = "CONTENT MANAGEMENT";
			} else if (formName.toUpperCase().equalsIgnoreCase("FEED OUT")) {
				formName = "Feed Out";
				RequestType = "CONTENT MANAGEMENT";
			} else if (formName.toUpperCase().equalsIgnoreCase("Media Transcoding / Transferring / Duplication")) {
				formName = "MTD";
				RequestType = "CONTENT MANAGEMENT";
			} else if (formName.toUpperCase().equalsIgnoreCase("EDIT SELF REPORTING")) {
				formName = "Edit Self Reporting";
				RequestType = "EDIT";
			}

			for (WebElement row : myRequestRows) {
				if ((WebAction.getText(row.findElement(By.xpath("td[1]/p[1]"))).equalsIgnoreCase(RequestType))
						&& (WebAction.getText(row.findElement(By.xpath("td[1]/p[2]"))).equalsIgnoreCase(formName))
						&& (WebAction.getText(row.findElement(By.xpath("td[3]//span"))).equalsIgnoreCase(status))) {
					requestNumber = WebAction.getText(row.findElement(By.xpath("td[2]/p/a")));
					Constants.setRequestNumber(requestNumber);
					break; // td[3]/tz-nag
				}
			}
			if (requestNumber.isEmpty())
				throw new Exception("Submitted " + formName + "is not present in my request table");

			// To close the update popup
			if (WebAction.isDisplayed(closeMessagePopup)) {
				WebAction.click(closeMessagePopup);
			}
		}

		catch (Exception e) {
			// AllureUtility.captureScreenshot("Request not present in my request table");
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify text displayed on the request
	 * 
	 * @param text - form name
	 * @throws Exception
	 */
	public void verifyTextDisplayed(String text) throws Exception {
		try {
			Thread.sleep(3000);
			Waits.waitForElement(textDisplayed, WAIT_CONDITIONS.VISIBLE);
			CommonValidations.verifyTextValue(textDisplayed, text);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}

	public void verifyStatus(String status) throws Exception {
		try {
			Thread.sleep(3000);
			Waits.waitForElement(requestStatusLabel, WAIT_CONDITIONS.VISIBLE);
			CommonValidations.verifyTextValue(requestStatusLabel, status);

			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To get status of the request on the form
	 * 
	 * @param status - status text
	 * @throws Exception
	 */
	public void verifyRequestStatusText(String status) throws Exception {
		try {
			Thread.sleep(3000);
			Waits.waitForElement(statusText, WAIT_CONDITIONS.VISIBLE);
			CommonValidations.verifyTextValue(statusText, status);

			Thread.sleep(2000);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To get request ids from successful message after user clicks submit button
	 * 
	 * @param formName - form name
	 * @throws Exception
	 */
	public void getRequestIDs() throws Exception {
		String requestNumber = "";
		String requestType = null;
		try {
			WebDriver driver = DriverFactory.getCurrentDriver();

			Waits.waitUntilElementSizeGreater(By.xpath(requestNumbersXpath), 0);
			for (int i = 1; i <= requestIDFromSuccessMessage.size(); i++) {
				String newRequestNumbersXpath = requestNumbersXpath + "[" + i + "]";
				WebElement requestNumberWebElement = driver.findElement(By.xpath(newRequestNumbersXpath));
				String requestNumberWithRequestType = WebAction.getText(requestNumberWebElement);
				if (requestNumberWithRequestType.contains(" ")) {
					String[] requestNumberWithRequestTypearr = requestNumberWithRequestType.split(" ", 2);
					requestNumber = requestNumberWithRequestTypearr[0];
					requestType = requestNumberWithRequestTypearr[1].substring(1,
							requestNumberWithRequestTypearr[1].length() - 1);
				} else {
					requestNumber = requestNumberWithRequestType;
				}
				map.put(requestNumber, requestType);
			}
			for (Map.Entry<String, String> e : map.entrySet()) {
				System.out.println(e.getKey() + " " + e.getValue());
			}
			for (Map.Entry<String, String> e : map.entrySet()) {
				// System.out.println(e.getKey() + " " + e.getValue());
				Constants.setRequestNumber(e.getKey());
				break;
			}
		} catch (Exception e) {
			// AllureUtility.captureScreenshot("Request not present in success message");
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To get the request id from form and storing for future purpose.
	 * 
	 * @throws Exception
	 */
	public void getRequestIDFromSuccMsg() throws Exception {
		try {
			String msg = WebAction.getText(reqSubmittedMsg);
			String[] splitterString = msg.split("\"");
			Constants.setRequestNumber(splitterString[1]);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To click yes/No in the cancel alert message
	 * 
	 * @param confirmation - Yes/No
	 * @throws Exception
	 */
	public void clickOption(String confirmation) throws Exception {
		try {
			switch (confirmation.toUpperCase()) {
			case "YES":
				WebAction.click(cancel_Yes);
				break;
			case "OK":
				Waits.waitForElement(cancel_Ok, WAIT_CONDITIONS.CLICKABLE);
				WebAction.click(cancel_Ok);
				break;
			case "NO":
				WebAction.click(cancel_No);
				break;
			case "CLOSE":
				WebAction.click(closeMessagePopup);
				break;
			}
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To Open the request
	 * 
	 * @throws Exception
	 */

	public void openRequestInReadMode() {
		String requestID = Constants.getRequestNumber();
		Assert.assertEquals(requestIdDisplayed.getText(), requestID, "request open is not the same as searched");
	}

	public void checkRequestCreatedModal(String formName) throws Exception {
		WebDriver driver = getCurrentDriver();
		Waits.waitForElement(getBy("requestCreatedModalTitleBy"), WAIT_CONDITIONS.VISIBLE);
		List<WebElement> modalMessageElement = driver.findElements(getBy("requestCreatedModalMessageBy"));
		List<WebElement> modalTitleElement = driver.findElements(getBy("requestCreatedModalTitleBy"));
		String expectedTitle = "Request Submitted";
		String displayedTitle = WebAction.getText(modalTitleElement.get(0));
		Assert.assertEquals(displayedTitle, expectedTitle, "Request created modal title is not matching");
		String displayedMessage = WebAction.getText(modalMessageElement.get(0));
		Assert.assertTrue(displayedMessage.startsWith(String.format("The %s Request", formName)));
		Assert.assertTrue(displayedMessage.endsWith("was submitted successfully."));
		int firstIndex = displayedMessage.indexOf("\"");
		if (firstIndex >= 0) {
			String requestId = displayedMessage.substring(firstIndex + 1, displayedMessage.lastIndexOf("\""));
			Constants.setRequestNumber(requestId);
		}
	}

	public By getBy(String name) {
		if (name.equals("requestCreatedModalMessageBy")) {
			return By.xpath("//*[contains(@class,'ant-modal-confirm-content')]/*");
		} else if (name.equals("requestCreatedModalTitleBy")) {
			return By.xpath("//*[contains(@class,'ant-modal-confirm-title')]/*");
		}
		Assert.fail(String.format("Cannot find the by locator for %s", name));
		return null;
	}

	public void openRequestsDashboard(String view) {
		try {
			requestsDashboardButton.click();
			Waits.waitForElement(changeViewButton, WAIT_CONDITIONS.CLICKABLE);
			WebAction.mouseOver(changeViewButton);
			if (view.equalsIgnoreCase("My Requests")) {
				Waits.waitForElement(myRequestsButton, WAIT_CONDITIONS.CLICKABLE);
				WebAction.click(myRequestsButton);
			} else if (view.equalsIgnoreCase("All Requests")) {
				Waits.waitForElement(allRequestsButton, WAIT_CONDITIONS.CLICKABLE);
				WebAction.click(allRequestsButton);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void searchAndOpenRequest(String requestNumber) {
		try {
			WebAction.sendKeys(searchTextBox, requestNumber);
			Waits.waitForElement(loadingSpinner, WAIT_CONDITIONS.INVISIBLE);
			Assert.assertTrue(requestIdsInTable.size() == 1, "0 or more than 1 search results found!");
			Optional<WebElement> requestLinkOptional = requestIdsInTable.stream()
					.filter((requestIdElement) -> WebAction.getText(requestIdElement).equals(requestNumber))
					.findFirst();
			WebAction.click(requestLinkOptional.get());
			Waits.waitForElement(loadingSpinner, WAIT_CONDITIONS.VISIBLE);
			Waits.waitForElement(loadingSpinner, WAIT_CONDITIONS.INVISIBLE);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void openCreatedRequest() {
		openRequestsDashboard("All Requests");
		searchAndOpenRequest(Constants.getRequestNumber());
	}
}
