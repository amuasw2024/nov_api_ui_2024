
package nbcu.automation.ui.pages.ncxUnifiedTool;

import java.lang.reflect.Array;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import nbcu.automation.ui.constants.ncxUnifiedTool.Constants;
import nbcu.automation.ui.pojos.ncxUnifiedTool.ControlRoomAndCrewRecord;
import nbcu.automation.ui.pojos.ncxUnifiedTool.LocationRecord;
import nbcu.automation.ui.pojos.ncxUnifiedTool.RequesterRecord;
import nbcu.automation.ui.pojos.ncxUnifiedTool.TpmOrTmInformation;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.factory.DriverFactory;
import nbcu.framework.utils.Other.DateFunctions;
import nbcu.framework.utils.report.ReportGenerate;
import nbcu.framework.utils.ui.Waits;
import nbcu.framework.utils.ui.Waits.WAIT_CONDITIONS;
import nbcu.framework.utils.ui.WebAction;
import static nbcu.framework.utils.ui.WebAction.scrollIntoView;
import static nbcu.framework.utils.ui.WebAction.getText;
import static nbcu.framework.utils.ui.WebAction.click;
import static nbcu.framework.utils.ui.Waits.waitForElement;
import static nbcu.framework.factory.DriverFactory.getCurrentDriver;

public class ProdExtendorBridgeCrewRequestFormPage {

	ProducerDashboardGeneralPage producerDashboardGeneralPage = new ProducerDashboardGeneralPage();

	public ProducerDashboardGeneralPage getProducerDashboardGeneralPage() {
		return producerDashboardGeneralPage;
	}

	@FindBy(xpath = "//*[contains(@forminputname,'requestFor')]/ancestor::div[1]//div[contains(@class,'error')]")
	WebElement requestForError;

	@FindBy(xpath = "//*[contains(@forminputname,'controlRoom')]/ancestor::div[1]//div[contains(@class,'error')]")
	WebElement controlRoomAndCrewError;

	@FindBy(xpath = "//*[@forminputname='requestFor']//label[@label-value='Extend']")
	WebElement requestFor_Extend;

	@FindBy(xpath = "//*[@forminputname='requestFor']//label[@label-value='Bridge']")
	WebElement requestFor_Bridge;

	@FindBy(xpath = "//*[@forminputname='controlRoom']//label[@label-value='Eob_Yes']")
	WebElement controlRoom_Eob_Yes;

	@FindBy(xpath = "//*[@forminputname='controlRoom']//label[@label-value='Eob_Yes']")
	WebElement controlRoom_Eob_No;

	@FindBy(xpath = "//phase-two-container//*[contains(@class,'status-title-area')]//p[contains(@class,'left-hand-title')]")
	List<WebElement> formSectionTitles;

	@FindBy(xpath = "//*[contains(text(),' Request For ')]/../following::*[1]//span[text()]")
	List<WebElement> requestForRadioLabels;

	@FindBy(xpath = "//*[contains(text(),' Is Budget Code Available? ')]/../following::*[1]//span[text()]")
	List<WebElement> isBudgetCodeAvailableRadioLabels;

	@FindBy(xpath = "//*[contains(text(),' Control Room & Crew ')]/../following::*[1]//span[text()]")
	List<WebElement> controlRoomAndCrewRadioLabels;

	@FindBy(xpath = "//label[text()=' Same as requester? ']/ancestor::nz-form-label/following::input[1]")
	WebElement sameAsRequesterCheckbox;

	@FindBy(xpath = "//label[contains(text(),'Division')]/ancestor::nz-form-label/following::input[1]")
	WebElement divisionInput;

	@FindBy(xpath = "//label[text()=' Control Room ']/ancestor::nz-form-label/following::input[1]")
	WebElement controlRoomInput;

	@FindBy(xpath = "//label[text()=' Control Room Location ']/ancestor::nz-form-label/following::input[1]")
	WebElement controlRoomLocationInput;

	@FindBy(xpath = "//label[text() = ' Budget Code ']/ancestor::nz-form-label/following::input[1]")
	WebElement budgetCodeInput;

	@FindBy(xpath = "//label[contains(text(),'Show Unit or Project Name')]/ancestor::nz-form-label/following::input[1]")
	WebElement showUnitOrProjectNameInput;

	@FindBy(xpath = "//label[text()=' Air Platform ']/ancestor::nz-form-label/following::input[1]")
	WebElement airPlatformInput;

	@FindBy(xpath = "//label[text()=' Work Order # ']/ancestor::nz-form-label/following::input[1]")
	WebElement workOrderInput;

	@FindBy(xpath = "//label[text()=' Start Date ']/ancestor::nz-form-label/following::input[1]")
	WebElement startDateInput;

	@FindBy(xpath = "//label[text()=' Start Time ']/ancestor::nz-form-label/following::input[1]")
	WebElement startTimeInput;

	@FindBy(xpath = "//label[text()=' End Time ']/ancestor::nz-form-label/following::input[1]")
	WebElement endTimeInput;

	@FindBy(xpath = "//label[text()=' Other ']/ancestor::nz-form-label/following::input[1]")
	WebElement otherInput;

	@FindBy(xpath = "//*[text()=' Details and Notes ']/../following::*[1]//textarea")
	WebElement detailsAndNotesInput;

	@FindBy(xpath = "//*[contains(text(),'SET LOCATION & CREW')]/ancestor::phase-two-container"
			+ "//label[text()=' Address ']/ancestor::nz-form-label/following::input[1]")
	WebElement addressInputInSetLocationAndCrewSection;

	@FindBy(xpath = "//*[contains(text(),'CONTROL ROOM & CREW')]/ancestor::phase-two-container"
			+ "//label[text()=' Address ']/ancestor::nz-form-label/following::input[1]")
	WebElement addressInputInControlRoomAndCrewSection;

	@FindBy(xpath = "//*[@sectiontitle='General Details']//nz-form-label//label")
	List<WebElement> generalDetailsSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='TPM / TM Information']//nz-form-label//label")
	List<WebElement> tpmOrTmInformationSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='Requester(s)']//nz-form-label//label")
	List<WebElement> requestersSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='Talent']//nz-form-label//label")
	List<WebElement> talentSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='Show Info']//nz-form-label//label")
	List<WebElement> showInfoSectionFieldLabels;

	@FindBy(xpath = "//*[text()='EXTEND SET LOCATION & CREW']/ancestor::phase-two-container//nz-form-label//label")
	List<WebElement> extendSetLocationAndCrewSectionFieldLabels;

	@FindBy(xpath = "//*[text()='BRIDGE SET LOCATION & CREW']/ancestor::phase-two-container//nz-form-label//label")
	List<WebElement> bridgeSetLocationAndCrewSectionFieldLabels;

	@FindBy(xpath = "//*[text()='BRIDGE CONTROL ROOM & CREW']/ancestor::phase-two-container//nz-form-label//label")
	List<WebElement> bridgeControlRoomAndCrewSectionFieldLabels;

	@FindBy(xpath = "//*[text()='EXTEND CONTROL ROOM & CREW']/ancestor::phase-two-container//nz-form-label//label")
	List<WebElement> extendControlRoomAndCrewSectionFieldLabels;

	@FindBy(xpath = "//*[text()=' SET LOCATION & CREW']/ancestor::phase-two-container//nz-form-label//label")
	List<WebElement> setLocationAndCrewSectionFieldLabels;

	@FindBy(xpath = "//*[text()=' CONTROL ROOM & CREW']/ancestor::phase-two-container//nz-form-label//label")
	List<WebElement> controlRoomAndCrewSectionFieldLabels;

	@FindBy(xpath = "//*[@sectiontitle='Details']//nz-form-label//label")
	List<WebElement> detailsSectionFieldLabels;

	public ProdExtendorBridgeCrewRequestFormPage() {
		PageFactory.initElements(DriverFactory.getCurrentDriver(), this);
	}

	/**
	 * To verify request for details info missing field error message
	 *
	 * @throws Exception
	 */
	public void verifyShowInfoMissingFieldError(String requestForErrorMessage, String airPlatformErrorMessage,
			String showUnitErrorMessage, String budgetCodeErrorMessage, String startDateErrorMessage,
			String startTimeErrorMessage, String endTimeErrorMessage) throws Exception {
		try {
			CommonValidations.verifyTextValue(requestForError, requestForErrorMessage);
			producerDashboardGeneralPage.verifyShowInfoMissingFieldError(airPlatformErrorMessage, showUnitErrorMessage,
					budgetCodeErrorMessage, startDateErrorMessage, startTimeErrorMessage, endTimeErrorMessage);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * To verify control room and crew section missing field error message
	 *
	 * @throws Exception
	 */
	public void verifyControlRoomAndCrewMissingFieldError(String controlRoomAndCrewErrorMessage,
			String controlRoomLocationErrorMessage, String controlRoomErrorMessage) throws Exception {
		WebAction.scrollIntoView(producerDashboardGeneralPage.controlRoomAndCrewSection);
		try {
			CommonValidations.verifyTextValue(controlRoomAndCrewError, controlRoomAndCrewErrorMessage);
			producerDashboardGeneralPage.controlRoomLocationErrorMessage(controlRoomLocationErrorMessage);
			producerDashboardGeneralPage.controlRoomErrorMessage(controlRoomErrorMessage);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void addShowInfoExtendorBridgeCrewProduction(String requestFor, String airPlatformText, String showText,
			String startDateText, String startTimeText, String endTimeText) throws Exception {
		if (requestFor != null) {
			if (requestFor.equalsIgnoreCase("Extend")) {
				WebAction.click(requestFor_Extend);
				ReportGenerate.test.log(Status.INFO,
						"User selects " + requestFor + " for Request For section in Extend or Bridge Form");
			} else {
				WebAction.click(requestFor_Bridge);
				ReportGenerate.test.log(Status.INFO,
						"User selects Bridge for Request For section in Extend or Bridge Form");
			}
		}
		WebAction.scrollIntoView(producerDashboardGeneralPage.talentSection);
		producerDashboardGeneralPage.selectAirPlatform(airPlatformText);
		producerDashboardGeneralPage.enterShow(showText);
		producerDashboardGeneralPage.selectStartDate(startDateText);
		producerDashboardGeneralPage.selectStartTime(startTimeText);
		producerDashboardGeneralPage.selectEndTime(endTimeText);
	}

	public void selectControlRoomAndCrewOption(String controlRoomAndCrewOptionText) throws Exception {
		if (controlRoomAndCrewOptionText != null) {
			if (controlRoomAndCrewOptionText.equalsIgnoreCase("Yes")) {
				WebAction.click(controlRoom_Eob_Yes);
				ReportGenerate.test.log(Status.INFO, "User selects " + controlRoomAndCrewOptionText
						+ " for Control Room & Crew section in Extend or Bridge Form");
			} else {
				WebAction.click(controlRoom_Eob_No);
				ReportGenerate.test.log(Status.INFO,
						"User selects No for Control Room & Crew section in Extend or Bridge Form");
			}
		}
	}

	public void addControlRoomAndCrewInfo(String controlRoomAndCrewOptionText, String controlRoomLocationText,
			String controlRoomText) throws Exception {
		try {
			WebAction.scrollIntoView(producerDashboardGeneralPage.controlRoomAndCrewSection);
			selectControlRoomAndCrewOption(controlRoomAndCrewOptionText);
			Constants.setControlRoomOption(controlRoomAndCrewOptionText);
			if (controlRoomAndCrewOptionText.equalsIgnoreCase("Yes")) {
				producerDashboardGeneralPage.addControlRoomLocation(controlRoomLocationText);
				producerDashboardGeneralPage.addControlRoom(controlRoomText, controlRoomLocationText);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public By getBy(String name) {
		if (name.equals("dropdownOptionsBy")) {
			return By.xpath("//*[contains(@class,'ant-select-item') and text()]");
		} else if (name.equals("locationInputBy")) {
			return By.xpath("//*[text()=' Location ']/../following::*[1]//input");
		} else if (name.equals("setLocationInputBy")) {
			return By.xpath("//*[text()=' Set Location ']/../following::*[1]//input");
		} else if (name.equals("addressInputBy")) {
			return By.xpath("//*[text()=' Address ']/../following::*[1]//input");
		} else if (name.equals("divisionInputPlaceholderBy")) {
			return By.xpath("//*[text()=' Division ']/../following::*[1]//nz-select-placeholder");
		} else if (name.equals("airPlatformInputPlaceholderBy")) {
			return By.xpath("//*[text()=' Air Platform ']/../following::*[1]//nz-select-placeholder");
		} else if (name.equals("showUnitOrProjectNameInputPlaceholderBy")) {
			return By.xpath("//*[text()=' Show Unit or Project Name ']/../following::*[1]//nz-select-placeholder");
		} else if (name.equals("locationInputPlaceholderBy")) {
			return By.xpath("//*[text()=' Location ']/../following::*[1]//nz-select-placeholder");
		} else if (name.equals("setLocationInputPlaceholderBy")) {
			return By.xpath("//*[text()=' Set Location ']/../following::*[1]//nz-select-placeholder");
		} else if (name.equals("controlRoomLocationInputPlaceholderBy")) {
			return By.xpath("//*[text()=' Control Room Location ']/../following::*[1]//nz-select-placeholder");
		} else if (name.equals("controlRoomInputPlaceholderBy")) {
			return By.xpath("//*[text()=' Control Room ']/../following::*[1]//nz-select-placeholder");
		} else if (name.equals("locationRequiredErrorBy")) {
			return By.xpath(
					"//*[text()=' Location ']/../following::*[1]//*[contains(@class,'ant-form-item-explain-error')]");
		} else if (name.equals("setLocationRequiredErrorBy")) {
			return By.xpath(
					"//*[text()=' Set Location ']/../following::*[1]//*[contains(@class,'ant-form-item-explain-error')]");
		} else if (name.equals("addressRequiredErrorInControlRoomAndCrewBy")) {
			return By.xpath(
					"//*[contains(text(),'CONTROL ROOM & CREW')]/ancestor::phase-two-container//label[text()=' Address ']"
							+ "/../following::*[1]//*[contains(@class,'ant-form-item-explain-error')]");
		} else if (name.equals("addressRequiredErrorInSetLocationAndCrewBy")) {
			return By.xpath(
					"//*[contains(text(),'SET LOCATION & CREW')]/ancestor::phase-two-container//label[text()=' Address ']"
							+ "/../following::*[1]//*[contains(@class,'ant-form-item-explain-error')]");
		} else if (name.equals("airPlatformRequiredErrorBy")) {
			return By.xpath(
					"//*[text()=' Air Platform ']/../following::*[1]//*[contains(@class,'ant-form-item-explain-error')]");
		} else if (name.equals("showUnitOrProjectNameRequiredErrorBy")) {
			return By.xpath(
					"//*[text()=' Show Unit or Project Name ']/../following::*[1]//*[contains(@class,'ant-form-item-explain-error')]");
		} else if (name.equals("otherRequiredErrorBy")) {
			return By.xpath(
					"//*[text()=' Other ']/../following::*[1]//*[contains(@class,'ant-form-item-explain-error')]");
		} else if (name.equals("startDateRequiredErrorBy")) {
			return By.xpath(
					"//*[text()=' Start Date ']/../following::*[1]//*[contains(@class,'ant-form-item-explain-error')]");
		} else if (name.equals("startTimeRequiredErrorBy")) {
			return By.xpath(
					"//*[text()=' Start Time ']/../following::*[1]//*[contains(@class,'ant-form-item-explain-error')]");
		} else if (name.equals("endTimeRequiredErrorBy")) {
			return By.xpath(
					"//*[text()=' End Time ']/../following::*[1]//*[contains(@class,'ant-form-item-explain-error')]");
		} else if (name.equals("divisionRequiredErrorBy")) {
			return By.xpath(
					"//*[text()=' Division ']/../following::*[1]//*[contains(@class,'ant-form-item-explain-error')]");
		} else if (name.equals("requestForRequiredErrorBy")) {
			return By.xpath(
					"//*[text()=' Request For ']/../following::*[1]//*[contains(@class,'ant-form-item-explain-error')]");
		} else if (name.equals("budgetCodeRequiredErrorBy")) {
			return By.xpath(
					"//*[text()=' Budget Code ']/../following::*[1]//*[contains(@class,'ant-form-item-explain-error')]");
		} else if (name.equals("controlRoomAndCrewRequiredErrorBy")) {
			return By.xpath(
					"//*[text()=' Control Room & Crew ']/../following::*[1]//*[contains(@class,'ant-form-item-explain-error')]");
		} else if (name.equals("controlRoomLocationRequiredErrorBy")) {
			return By.xpath(
					"//*[text()=' Control Room Location ']/../following::*[1]//*[contains(@class,'ant-form-item-explain-error')]");
		} else if (name.equals("controlRoomRequiredErrorBy")) {
			return By.xpath(
					"//*[text()=' Control Room ']/../following::*[1]//*[contains(@class,'ant-form-item-explain-error')]");
		} else if (name.equals("IsATpmorTmNeededRadioLabels")) {
			return By.xpath(
					"//*[contains(text(),' Is a TPM or TM Needed? ')]/../following::*[1]//label[contains(@class,'ant-radio-button')]");
		} else if (name.equals("tpmOrTmNameInput")) {
			return By.xpath("//label[text()=' TPM/TM Name ']/ancestor::nz-form-label/following::input[1]");
		}
		Assert.fail(String.format("Could not find the By locator for '%s'", name));
		return By.xpath("");
	}

	public void verifyTheFormSectionsInExtendOrBrigeCrewAndFacilitiesProductionForm() {
		List<String> expectedHeaders = new ArrayList<String>();
		expectedHeaders
				.addAll(Arrays.asList("STATUS", "GENERAL DETAILS", "REQUESTER(S)", "TALENT", "DETAILS", "SHOW INFO"));
		String requestFor = Constants.getRequestFor();
		if (requestFor != null && requestFor.equals("Bridge")) {
			expectedHeaders.addAll(Arrays.asList("BRIDGE SET LOCATION & CREW", "BRIDGE CONTROL ROOM & CREW"));
		} else if (requestFor != null && requestFor.equals("Extend")) {
			expectedHeaders.addAll(Arrays.asList("EXTEND SET LOCATION & CREW", "EXTEND CONTROL ROOM & CREW"));
		} else {
			expectedHeaders.addAll(Arrays.asList("SET LOCATION & CREW", "CONTROL ROOM & CREW"));
		}
		expectedHeaders.add("TPM / TM INFORMATION");
		if (expectedHeaders.size() != formSectionTitles.size()) {
			Assert.assertEquals(formSectionTitles.size(), expectedHeaders.size(),
					"Total number of sections are not the same as expected");
		} else {
			boolean allFormSectionsArePresent = true;
			for (int itr = 0; itr < expectedHeaders.size(); itr++) {
				String expectedName = expectedHeaders.get(itr);
				String displayedName = WebAction.getText(formSectionTitles.get(itr));
				if (!expectedName.equals(displayedName)) {
					allFormSectionsArePresent = false;
					Assert.assertEquals(displayedName, expectedName,
							"Expected section name is not same as displayed name");
				}
			}
			Assert.assertTrue(allFormSectionsArePresent,
					"All expected sections are not present on Extend or Bridge Crew & Facilities Production form");
		}
	}

	public void selectRadioOption(String field, String option, Integer position, String sectionName) throws Exception {
		Boolean optionSelected = false;
		List<WebElement> radioLabels = getRadioLabelElements(field);
		for (int itr = 0; itr < radioLabels.size(); ++itr) {
			WebElement optionNameElement = radioLabels.get(itr);
			String val = WebAction.getText(optionNameElement);
			if (val.equals(option)) {
				WebAction.scrollIntoView(optionNameElement);
				int trials = 3;
				while (trials-- > 0) {
					try {
						optionNameElement.click();
						break;
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				optionSelected = true;
				storeInConstants(field, option, position, sectionName);
			}
		}
		if (!optionSelected) {
			Assert.assertTrue(optionSelected,
					"Option '" + option + "' is not displayed for '" + field + "' indexed " + position);
		}
	}

	public List<WebElement> getRadioLabelElements(String field) {
		WebDriver driver = getCurrentDriver();
		if (field.equals("Request For")) {
			return requestForRadioLabels;
		} else if (field.equals("Is Budget Code Available?")) {
			return isBudgetCodeAvailableRadioLabels;
		} else if (field.equals("Control Room & Crew")) {
			return controlRoomAndCrewRadioLabels;
		} else if (field.equals("Is a TPM or TM Needed?")) {
			return driver.findElements(getBy("IsATpmorTmNeededRadioLabels"));
		}
		return new ArrayList<WebElement>();
	}

	public void storeInConstants(String fieldName, Object option, Integer position, String sectionName) {
		if (sectionName.contains("SET LOCATION & CREW")) {
			if (fieldName.equals("Location") || fieldName.equals("Set Location") || fieldName.equals("Address")) {
				List<LocationRecord> locationRecords = Constants.getLocation();
				int count = locationRecords.size();
				int totalRecords = position + 1;
				while (count++ < totalRecords) {
					locationRecords.add(new LocationRecord());
				}
				if (fieldName.equals("Location")) {
					locationRecords.get(position).setLocation((String) option);
				} else if (fieldName.equals("Set Location")) {
					locationRecords.get(position).setSetLocation((String) option);
				} else if (fieldName.equals("Address")) {
					locationRecords.get(position).setAddress((String) option);
				}
			}
		} else if (sectionName.contains("CONTROL ROOM & CREW")) {
			if (fieldName.equals("Control Room & Crew") || fieldName.equals("Control Room Location")
					|| fieldName.equals("Control Room") || fieldName.equals("Address")) {
				List<ControlRoomAndCrewRecord> records = Constants.getControlRoomAndCrew();
				int count = records.size();
				int totalRecords = position + 1;
				while (count++ < totalRecords) {
					records.add(new ControlRoomAndCrewRecord());
				}
				if (fieldName.equals("Control Room & Crew")) {
					String val = (String) option;
					records.get(position).setControlRoomAndCrew(val);
					if (val.equalsIgnoreCase("No")) {
						records.get(position).setControlRoomLocation("");
						records.get(position).setControlRoom("");
						records.get(position).setAddress("");
					}
				} else if (fieldName.equals("Control Room Location")) {
					records.get(position).setControlRoomLocation((String) option);
				} else if (fieldName.equals("Control Room")) {
					records.get(position).setControlRoom((String) option);
				} else if (fieldName.equals("Address")) {
					records.get(position).setAddress((String) option);
				}
			}
		} else if (sectionName.equals("TPM / TM INFORMATION")) {
			TpmOrTmInformation rec = Constants.getTpmOrTmInformation();
			if (fieldName.equals("Is a TPM or TM Needed?")) {
				String choice = (String) option;
				rec.setIsATpmOrTmNeeded(choice);
				if (choice.equalsIgnoreCase("No")) {
					rec.setSameAsRequester(false);
					rec.setTpmOrTmName("");
				}
			} else if (fieldName.equals("Same as requester?")) {
				Boolean choice = (Boolean) option;
				rec.setSameAsRequester(choice);
				if (choice == false) {
					rec.setTpmOrTmName("");
				} else {
					List<RequesterRecord> list = Constants.getRequesters();
					if (list.size() > 0) {
						rec.setTpmOrTmName(list.get(0).getName());
					}
				}
			} else if (fieldName.equals("TPM/TM Name")) {
				rec.setTpmOrTmName((String) option);
			}
		} else if (fieldName.equals("Division")) {
			Constants.setDivision((String) option);
		} else if (fieldName.equals("Details and Notes")) {
			Constants.setDetailsAndNotes((String) option);
		} else if (fieldName.equals("Request For")) {
			Constants.setRequestFor((String) option);
		} else if (fieldName.equals("Show Unit or Project Name")) {
			Constants.setShowUnitOrProjectName((String) option);
		} else if (fieldName.equals("Air Platform")) {
			Constants.setAirPlatform((String) option);
		} else if (fieldName.equals("Is Budget Code Available?")) {
			Constants.setIsBudgetCodeAvailable((String) option);
		} else if (fieldName.equals("Budget Code")) {
			Constants.setBudgetCode((String) option);
		} else if (fieldName.equals("Start Date")) {
			Constants.setStartDate((String) option);
		} else if (fieldName.equals("Start Time")) {
			Constants.setStartTime((String) option);
		} else if (fieldName.equals("End Time")) {
			Constants.setEndTime((String) option);
		} else if (fieldName.equals("Work Order #")) {
			Constants.setWorkOrder((String) option);
		} else if (fieldName.equals("Other")) {
			Constants.setOtherInShowInfo((String) option);
		}
	}

	public void selectValueInDropdown(String option, String fieldName, Integer position, String sectionName) {
		try {
			WebDriver driver = getCurrentDriver();
			WebElement input = getInputElement(fieldName, position);
			try {
				waitForElement(input, WAIT_CONDITIONS.VISIBLE);
			} catch (Exception e) {
				e.printStackTrace();
			}
			scrollIntoView(input);
			input.sendKeys(option);
			By dropdownOptionsBy = getBy("dropdownOptionsBy");
			waitForElement(dropdownOptionsBy, WAIT_CONDITIONS.VISIBLE);
			List<WebElement> options = driver.findElements(dropdownOptionsBy);
			Optional<WebElement> optional = options.stream()
					.filter((WebElement divisionOption) -> getText(divisionOption).equals(option)).findAny();
			if (optional.isPresent()) {
				WebElement optionToSelect = optional.get();
				scrollIntoView(optionToSelect);
				click(optionToSelect);
				storeInConstants(fieldName, option, position, sectionName);
			} else {
				Assert.assertTrue(false, "'" + option + "' is not present as an option in '" + fieldName
						+ "' on Extend or Bridge Crew production form");
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Error while selecting '" + option + "' in '" + fieldName
					+ "' on Extend or Bridge Crew Production form");
		}
	}

	/*
	 * metadata is a collection of strings first string should be a section name of
	 * the form
	 */
	public WebElement getInputElement(String fieldName, int position, String... metadata) {
		WebDriver driver = getCurrentDriver();
		if (fieldName.equals("Location")) {
			return driver.findElements(getBy("locationInputBy")).get(position);
		} else if (fieldName.equals("Set Location")) {
			return driver.findElements(getBy("setLocationInputBy")).get(position);
		} else if (fieldName.equals("Division")) {
			return divisionInput;
		} else if (fieldName.equals("Show Unit or Project Name")) {
			return showUnitOrProjectNameInput;
		} else if (fieldName.equals("Details and Notes")) {
			return detailsAndNotesInput;
		} else if (fieldName.equals("Air Platform")) {
			return airPlatformInput;
		} else if (fieldName.equals("Show Unit or Project Name")) {
			return showUnitOrProjectNameInput;
		} else if (fieldName.equals("Start Date")) {
			return startDateInput;
		} else if (fieldName.equals("Start Time")) {
			return startTimeInput;
		} else if (fieldName.equals("End Time")) {
			return endTimeInput;
		} else if (fieldName.equals("Work Order #")) {
			return workOrderInput;
		} else if (fieldName.equals("Other")) {
			return otherInput;
		} else if (fieldName.equals("Budget Code")) {
			return budgetCodeInput;
		} else if (fieldName.equals("Control Room Location")) {
			return controlRoomLocationInput;
		} else if (fieldName.equals("Control Room")) {
			return controlRoomInput;
		} else if (fieldName.equals("TPM/TM Name")) {
			return driver.findElement(getBy("tpmOrTmNameInput"));
		} else if (fieldName.equals("Address")) {
			String sectionName = metadata.length > 0 ? metadata[0] : "";
			if (sectionName.contains("SET LOCATION & CREW")) {
				return addressInputInSetLocationAndCrewSection;
			} else if (sectionName.contains("CONTROL ROOM & CREW")) {
				return addressInputInControlRoomAndCrewSection;
			}
		}
		return null;
	}

	public WebElement getCheckboxForField(String fieldName) {
		if (fieldName.equals("Same as requester?")) {
			return sameAsRequesterCheckbox;
		}
		return null;
	}

	public void fillTextbox(String field, String text, Integer position, String sectionName) throws Exception {
		WebElement element = getInputElement(field, position, sectionName);
		scrollIntoView(element);
		WebAction.clear(element);
		element.sendKeys(text);
		WebAction.blur(element);
		storeInConstants(field, text, position, sectionName);
		checkPlaceholderForInputsHavingPlaceholderAttribute(field, position, sectionName);
	}

	public void checkPlaceholderForInputsHavingPlaceholderAttribute(String field, Integer position,
			String sectionName) {
		// verify the placeholder of the inputs or textarea that has placeholder
		// attribute
		WebElement element = getInputElement(field, position, sectionName);
		String displayed = WebAction.getAttribute(element, "placeholder");
		String expected = getExpectedPlaceholder(field, sectionName);
		Assert.assertEquals(displayed.trim(), expected, "Placeholder for '" + field + "' textarea is not correct");
	}

	public String getExpectedPlaceholder(String field, String... metadata) {
		if (field.equals("Division")) {
			return "Select Division";
		} else if (field.equals("Location")) {
			return "Select Location";
		} else if (field.equals("Air Platform")) {
			return "Select Air Platform";
		} else if (field.equals("Show Unit or Project Name")) {
			return "Show or Project Name";
		} else if (field.equals("Budget Code")) {
			return "Budget Code";
		} else if (field.equals("Details and Notes")) {
			return "Type additional details here...";
		} else if (field.equals("Start Date")) {
			return "Select Date";
		} else if (field.equals("Start Time")) {
			return "Select time";
		} else if (field.equals("End Time")) {
			return "Select time";
		} else if (field.equals("Work Order #")) {
			return "Enter work order here";
		} else if (field.equals("Other")) {
			return "Enter Show or Project title";
		} else if (field.equals("Set Location")) {
			return "Select Set Location";
		} else if (field.equals("TPM/TM Name")) {
			return "FirstName LastName";
		} else if (field.equals("Address")) {
			String sectionName = metadata.length > 0 ? metadata[0] : "";
			if (sectionName.contains("SET LOCATION & CREW")) {
				return "Enter address here";
			} else if (sectionName.contains("CONTROL ROOM & CREW")) {
				return "Enter address here";
			}
		}
		return "";
	}

	public void checkFieldsInSectionOfExtendOrBridgeCrewAndFacilitiesProduction(String sectionName) {
		List<WebElement> sectionLabelElements = getSectionLabelElements(sectionName);
		Assert.assertTrue(sectionLabelElements != null, String.format(
				"%s section is not present in Extend or Bridge Crew & Facilities production form", sectionName));
		List<String> expectedFieldNamesList = getExpectedFieldsSectionWise(sectionName);
		System.out.println("required validation : expected fields : " + expectedFieldNamesList);
		Assert.assertEquals(sectionLabelElements.size(), expectedFieldNamesList.size(), String.format(
				"Number of displayed fields and expected fields not equal in %s section of Extend or Bridge Crew & Facilities Production",
				sectionName));
		List<String> expectedRequiredFieldList = getRequiredFieldsSectionWise(sectionName);
		System.out.println("required validation : required fields : " + expectedRequiredFieldList);
		for (int itr = 0; itr < expectedFieldNamesList.size(); itr++) {
			String expectedName = expectedFieldNamesList.get(itr);
			String displayedField = WebAction.getText(sectionLabelElements.get(itr));
			Assert.assertEquals(displayedField, expectedName, String.format(
					"Displayed field is not same as expected field in %s section of Extend or Bridge Crew & Facilities Production",
					sectionName));
			String cssClasses = WebAction.getAttribute(sectionLabelElements.get(itr), "class");
			System.out.println("required cssClasses : " + cssClasses);
			if (cssClasses.contains(" ant-form-item-required") && !expectedRequiredFieldList.contains(displayedField)) {
				Assert.assertTrue(
						cssClasses.contains(" ant-form-item-required")
								&& !expectedRequiredFieldList.contains(displayedField),
						String.format(
								"'%s' is not a required field in %s section but displayed with *(required symbol)",
								displayedField, sectionName));
			} else if (!cssClasses.contains(" ant-form-item-required")
					&& expectedRequiredFieldList.contains(displayedField)) {
				Assert.assertTrue(
						!cssClasses.contains(" ant-form-item-required")
								&& expectedRequiredFieldList.contains(displayedField),
						String.format(
								"'%s' is a required field in %s section but not displayed with *(required symbol)",
								displayedField, sectionName));
			}
		}
	}

	public List<WebElement> getSectionLabelElements(String sectionName) {
		if (sectionName.equalsIgnoreCase("GENERAL DETAILS")) {
			return generalDetailsSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("REQUESTER(S)")) {
			return requestersSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("TALENT")) {
			return talentSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("SHOW INFO")) {
			return showInfoSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("SET LOCATION & CREW")) {
			return setLocationAndCrewSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("CONTROL ROOM & CREW")) {
			return controlRoomAndCrewSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("EXTEND SET LOCATION & CREW")) {
			return extendSetLocationAndCrewSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("BRIDGE SET LOCATION & CREW")) {
			return bridgeSetLocationAndCrewSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("EXTEND CONTROL ROOM & CREW")) {
			return extendControlRoomAndCrewSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("BRIDGE CONTROL ROOM & CREW")) {
			return bridgeControlRoomAndCrewSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("DETAILS")) {
			return detailsSectionFieldLabels;
		} else if (sectionName.equalsIgnoreCase("TPM / TM INFORMATION")) {
			return tpmOrTmInformationSectionFieldLabels;
		}
		return null;
	}

	public List<String> getExpectedFieldsSectionWise(String sectionName) {
		List<String> fieldNamesList = new ArrayList<String>();
		if (sectionName.equalsIgnoreCase("GENERAL DETAILS")) {
			fieldNamesList.addAll((Arrays.asList("Division")));
		} else if (sectionName.equalsIgnoreCase("REQUESTER(S)")) {
			fieldNamesList.addAll((Arrays.asList("Add Requester(s)")));
		} else if (sectionName.equalsIgnoreCase("TALENT")) {
			fieldNamesList.addAll((Arrays.asList("Talent")));
		} else if (sectionName.equalsIgnoreCase("DETAILS")) {
			fieldNamesList.addAll((Arrays.asList("Details and Notes")));
		} else if (sectionName.equalsIgnoreCase("SHOW INFO")) {
			fieldNamesList.addAll(Arrays.asList("Request For", "Air Platform", "Show Unit or Project Name"));
			String showUnitOrProjectName = Constants.getShowUnitOrProjectName();
			if (showUnitOrProjectName != null && showUnitOrProjectName.equalsIgnoreCase("Other")) {
				fieldNamesList.add("Other");
			}
			fieldNamesList.addAll(Arrays.asList("Is Budget Code Available?", "Budget Code"));
			String division = Constants.getDivision();
			if (division != null && division.equals("CNBC")) {
				fieldNamesList.add("Work Order #");
			}
			fieldNamesList.addAll(Arrays.asList("Start Date", "Start Time", "End Time"));
		} else if (sectionName.equalsIgnoreCase("SET LOCATION & CREW")
				|| sectionName.equalsIgnoreCase("BRIDGE SET LOCATION & CREW")
				|| sectionName.equalsIgnoreCase("EXTEND SET LOCATION & CREW")) {
			fieldNamesList.addAll(Arrays.asList("Location"));
			List<LocationRecord> locationRecords = Constants.getLocation();
			String location = locationRecords.size() > 0 ? locationRecords.get(0).getLocation() : null;
			if (location != null && location.equals("Field")) {
				fieldNamesList.addAll(Arrays.asList("Address"));
			} else if (location != null && location.equals("None")) {
				fieldNamesList.addAll(Arrays.asList());
			} else {
				fieldNamesList.addAll(Arrays.asList("Set Location"));
			}
		} else if (sectionName.equalsIgnoreCase("CONTROL ROOM & CREW")
				|| sectionName.equalsIgnoreCase("BRIDGE CONTROL ROOM & CREW")
				|| sectionName.equalsIgnoreCase("EXTEND CONTROL ROOM & CREW")) {
			fieldNamesList.addAll((Arrays.asList("Control Room & Crew", "Control Room Location")));
			List<ControlRoomAndCrewRecord> records = Constants.getControlRoomAndCrew();
			if (records == null || records.size() == 0) {
				fieldNamesList.addAll((Arrays.asList("Control Room")));
			} else {
				String controlRoomLocation = records.get(0).getControlRoomLocation();
				String controlRoomAndCrew = records.get(0).getControlRoomAndCrew();
				if (controlRoomLocation == null || controlRoomAndCrew == null) {
					fieldNamesList.addAll((Arrays.asList("Control Room")));
				} else if (controlRoomLocation.equals("Rock Center") || controlRoomAndCrew.equals("No")) {
					fieldNamesList.addAll((Arrays.asList("Control Room")));
				} else if (controlRoomLocation.equals("Field")) {
					fieldNamesList.addAll((Arrays.asList("Address")));
				} else if (controlRoomLocation.equals("No Control Room")) {
					fieldNamesList.addAll((Arrays.asList()));
				}
			}
		} else if (sectionName.equals("TPM / TM INFORMATION")) {
			fieldNamesList.addAll(Arrays.asList("Is a TPM or TM Needed?", "Same as requester?", "TPM/TM Name"));
		}
		return fieldNamesList;
	}

	public List<String> getRequiredFieldsSectionWise(String sectionName) {
		List<String> fieldNamesList = new ArrayList<String>();
		if (sectionName.equalsIgnoreCase("GENERAL DETAILS")) {
			fieldNamesList.addAll((Arrays.asList("Division")));
		} else if (sectionName.equalsIgnoreCase("REQUESTER(S)") || sectionName.equalsIgnoreCase("TALENT")) {
			fieldNamesList.addAll((Arrays.asList()));
		} else if (sectionName.equalsIgnoreCase("SHOW INFO")) {
			fieldNamesList.addAll((Arrays.asList("Air Platform", "Show Unit or Project Name", "Other", "Start Date",
					"Start Time", "End Time", "Request For", "Is Budget Code Available?", "Budget Code")));
		} else if (sectionName.equalsIgnoreCase("SET LOCATION & CREW")
				|| sectionName.equalsIgnoreCase("BRIDGE SET LOCATION & CREW")
				|| sectionName.equalsIgnoreCase("EXTEND SET LOCATION & CREW")) {
			fieldNamesList.addAll((Arrays.asList("Location", "Set Location", "Address")));
		} else if (sectionName.equalsIgnoreCase("CONTROL ROOM & CREW")
				|| sectionName.equalsIgnoreCase("BRIDGE CONTROL ROOM & CREW")
				|| sectionName.equalsIgnoreCase("EXTEND CONTROL ROOM & CREW")) {
			List<ControlRoomAndCrewRecord> records = Constants.getControlRoomAndCrew();
			if (records == null || records.size() == 0) {
				fieldNamesList.addAll(
						(Arrays.asList("Control Room & Crew", "Control Room Location", "Control Room", "Address")));
			} else {
				String controlRoomAndCrew = records.get(0).getControlRoomAndCrew();
				System.out.println("getControlRoomAndCrew : " + controlRoomAndCrew);
				if (controlRoomAndCrew.equalsIgnoreCase("No")) {
					fieldNamesList.addAll((Arrays.asList("Control Room & Crew")));
				} else if (controlRoomAndCrew.equalsIgnoreCase("Yes")) {
					fieldNamesList.addAll(
							(Arrays.asList("Control Room & Crew", "Control Room Location", "Control Room", "Address")));
				}
			}
		} else if (sectionName.equalsIgnoreCase("DETAILS")) {
			fieldNamesList.addAll((Arrays.asList()));
		} else if (sectionName.equals("TPM / TM INFORMATION")) {
			fieldNamesList.addAll(Arrays.asList());
		}
		return fieldNamesList;
	}

	public String getStringFromConstants(String fieldName, String sectionName) {
		if (fieldName.equals("Request For")) {
			return Constants.getRequestFor();
		} else if (fieldName.equals("Division")) {
			return Constants.getDivision();
		} else if (fieldName.equals("Details & Notes")) {
			return Constants.getDetailsAndNotes();
		} else if (sectionName.contains("SET LOCATION & CREW")
				&& (fieldName.equals("Location") || fieldName.equals("Set Location") || fieldName.equals("Address"))) {
			if (Constants.getLocation().size() > 0) {
				LocationRecord rec = Constants.getLocation().get(0);
				if (fieldName.equals("Location")) {
					return rec.getLocation();
				} else if (fieldName.equals("Set Location")) {
					return rec.getSetLocation();
				} else if (fieldName.equals("Address")) {
					return rec.getAddress();
				}
			}
		} else if (fieldName.equals("Show Unit or Project Name")) {
			return Constants.getShowUnitOrProjectName();
		} else if (fieldName.equals("Is Budget Code Available?")) {
			return Constants.getIsBudgetCodeAvailable();
		} else if (sectionName.contains("SET LOCATION & CREW")
				&& (fieldName.equals("Control Room Location") || fieldName.equals("Control Room")
						|| fieldName.equals("Control Room & Crew") || fieldName.equals("Address"))) {
			List<ControlRoomAndCrewRecord> records = Constants.getControlRoomAndCrew();
			if (records.size() > 0) {
				ControlRoomAndCrewRecord rec = records.get(0);
				if (fieldName.equals("Control Room Location")) {
					return rec.getControlRoomLocation();
				} else if (fieldName.equals("Control Room")) {
					return rec.getControlRoom();
				} else if (fieldName.equals("Control Room & Crew")) {
					return rec.getControlRoomAndCrew();
				} else if (fieldName.equals("Address")) {
					return rec.getAddress();
				}
			}
		} else if (fieldName.equals("Is a TPM or TM Needed?")) {
			String choice = Constants.getTpmOrTmInformation().getIsATpmOrTmNeeded();
			if (choice == null) {
				storeInConstants(fieldName, "No", 0, sectionName);
			}
			return Constants.getTpmOrTmInformation().getIsATpmOrTmNeeded();
		}
		return null;
	}

	public void checkPlaceholderOfSelectFields(String fieldName, String sectionName) {
		List<WebElement> placeholderElement = getPlaceholderElementForField(fieldName);
		String requestForValue = getStringFromConstants(fieldName, sectionName);
		if (requestForValue == null) {
			if (placeholderElement.size() == 0) {
				Assert.assertEquals(placeholderElement.size(), 1,
						"Placeholder for '" + fieldName + "' field is not present");
			}
			if (placeholderElement.size() > 1) {
				Assert.assertEquals(placeholderElement.size(), 1,
						"More than 1 placeholder for '" + fieldName + "' field is present");
			} else {
				String displayed = WebAction.getText(placeholderElement.get(0));
				String expected = getExpectedPlaceholder(fieldName);
				Assert.assertEquals(displayed, expected, "Placeholder for '" + fieldName + "' field is not correct");
			}
		} else {
//			if(placeholderElement.size() > 0) {
//				Assert.assertEquals(placeholderElement.size(),0, "Placeholder for '"+fieldName+"' field should not "
//						+ "display if value is selected");
//			}
		}
	}

	public List<WebElement> getPlaceholderElementForField(String field) {
		WebDriver driver = getCurrentDriver();
		if (field.equals("Division")) {
			return driver.findElements(getBy("divisionInputPlaceholderBy"));
		} else if (field.equals("Air Platform")) {
			return driver.findElements(getBy("airPlatformInputPlaceholderBy"));
		} else if (field.equals("Location")) {
			return driver.findElements(getBy("locationInputPlaceholderBy"));
		} else if (field.equals("Set Location")) {
			return driver.findElements(getBy("setLocationInputPlaceholderBy"));
		} else if (field.equals("Show Unit or Project Name")) {
			return driver.findElements(getBy("showUnitOrProjectNameInputPlaceholderBy"));
		} else if (field.equals("Control Room Location")) {
			return driver.findElements(getBy("controlRoomLocationInputPlaceholderBy"));
		} else if (field.equals("Control Room")) {
			return driver.findElements(getBy("controlRoomInputPlaceholderBy"));
		}
		return new ArrayList<WebElement>();
	}

	public void verifyErrorBelowFieldIfEmpty(String fieldName, String section) {
		List<WebElement> elements = getErrorElementForField(fieldName, section);
		Assert.assertFalse(elements.size() == 0,
				String.format("Error text for '%s' required field is not present", fieldName));
		WebElement element = elements.get(0);
		scrollIntoView(element);
		String displayed = getText(element);
		String expected = getExpectedErrorMessageForRequiredField(fieldName, section);
		Assert.assertEquals(displayed, expected,
				String.format("Error text for '%s' required field is not correct", fieldName));
	}

	public void verifyErrorBelowFieldIfNotEmpty(String fieldName, String section) {
		List<WebElement> elements = getErrorElementForField(fieldName, section);
		Assert.assertTrue(elements.size() == 0,
				String.format("Error text for '%s' required field should not display", fieldName));
	}

	public String getExpectedErrorMessageForRequiredField(String field, String sectionName) {
		if (field.equals("Division")) {
			return "Select a value";
		} else if (field.equals("Location")) {
			return "Select a value";
		} else if (field.equals("Air Platform")) {
			return "Select a value";
		} else if (field.equals("Show Unit or Project Name")) {
			return "Please select/enter a show or project name";
		} else if (field.equals("Start Date")) {
			return "Select a date";
		} else if (field.equals("Start Time")) {
			return "Enter a value";
		} else if (field.equals("End Time")) {
			return "Enter a value";
		} else if (field.equals("Set Location")) {
			return "Select a value";
		} else if (field.equals("Location")) {
			return "Select a value";
		} else if (field.equals("Control Room & Crew")) {
			return "Select a value";
		} else if (field.equals("Control Room")) {
			return "Select a value";
		} else if (field.equals("Control Room Location")) {
			return "Select a value";
		} else if (field.equals("Request For")) {
			return "Select a value";
		} else if (field.equals("Budget Code")) {
			return "Enter a value";
		} else if (field.equals("Other")) {
			return "Please enter Show or Project title";
		} else if (field.equals("Address")) {
			if (sectionName.contains("SET LOCATION & CREW")) {
				return "Enter a value";
			}
			if (sectionName.contains("CONTROL ROOM & CREW")) {
				return "Enter a value";
			}
		}
		return "";
	}

	public List<WebElement> getErrorElementForField(String field, String sectionName) {
		WebDriver driver = getCurrentDriver();
		if (field.equals("Division")) {
			return driver.findElements(getBy("divisionRequiredErrorBy"));
		} else if (field.equals("Location")) {
			return driver.findElements(getBy("locationRequiredErrorBy"));
		} else if (field.equals("Set Location")) {
			return driver.findElements(getBy("setLocationRequiredErrorBy"));
		} else if (field.equals("Air Platform")) {
			return driver.findElements(getBy("airPlatformRequiredErrorBy"));
		} else if (field.equals("Show Unit or Project Name")) {
			return driver.findElements(getBy("showUnitOrProjectNameRequiredErrorBy"));
		} else if (field.equals("Start Date")) {
			return driver.findElements(getBy("startDateRequiredErrorBy"));
		} else if (field.equals("Start Time")) {
			return driver.findElements(getBy("startTimeRequiredErrorBy"));
		} else if (field.equals("End Time")) {
			return driver.findElements(getBy("endTimeRequiredErrorBy"));
		} else if (field.equals("Other")) {
			return driver.findElements(getBy("otherRequiredErrorBy"));
		} else if (field.equals("Address")) {
			if (sectionName.contains("SET LOCATION & CREW")) {
				return driver.findElements(getBy("addressRequiredErrorInSetLocationAndCrewBy"));
			} else if (sectionName.contains("CONTROL ROOM & CREW")) {
				return driver.findElements(getBy("addressRequiredErrorInControlRoomAndCrewBy"));
			}
		} else if (field.equals("Control Room & Crew")) {
			return driver.findElements(getBy("controlRoomAndCrewRequiredErrorBy"));
		} else if (field.equals("Control Room")) {
			return driver.findElements(getBy("controlRoomRequiredErrorBy"));
		} else if (field.equals("Control Room Location")) {
			return driver.findElements(getBy("controlRoomLocationRequiredErrorBy"));
		} else if (field.equals("Budget Code")) {
			return driver.findElements(getBy("budgetCodeRequiredErrorBy"));
		} else if (field.equals("Request For")) {
			return driver.findElements(getBy("requestForRequiredErrorBy"));
		}
		return new ArrayList<WebElement>();
	}

	public void clearTextareaInput(String field, Integer position, String sectionName) {
		WebElement element = getInputElement(field, position);
		scrollIntoView(element);
		WebAction.clearInputOneCharAtTime(element);
		storeInConstants(field, "", position, sectionName);
	}

	public void isInputDisabled(String field, String sectionName) {
		WebElement element = getInputElement(field, 0, sectionName);
		String isDisabled = WebAction.getAttribute(element, "disabled");
		Assert.assertTrue(isDisabled != null, "field " + field + " in section " + sectionName + " is not disabled "
				+ " in Extend or Bridge Crew & Facilities form");
	}

	public void isInputReadOnly(String field, String sectionName) {
		WebElement element = getInputElement(field, 0, sectionName);
		String readOnly = WebAction.getAttribute(element, "readonly");
		Assert.assertTrue(readOnly != null, "field " + field + " in section " + sectionName + " is not read only "
				+ " in Extend or Bridge Crew & Facilities form");
	}

	public void isInputEnabled(String field, String sectionName) {
		WebElement element = getInputElement(field, 0, sectionName);
		String isDisabled = WebAction.getAttribute(element, "disabled");
		String readOnly = WebAction.getAttribute(element, "readonly");
		Assert.assertTrue(isDisabled == null && readOnly == null, "field " + field + " in section " + sectionName
				+ " is not enabled " + " in Extend or Bridge Crew & Facilities form");
	}

	public void isCheckboxDisabled(String field, String sectionName) {
		WebElement element = getCheckboxForField(field);
		String isDisabled = WebAction.getAttribute(element, "disabled");
		Assert.assertTrue(isDisabled != null, "field " + field + " in section " + sectionName + " is not disabled "
				+ " in Extend or Bridge Crew & Facilities form");
	}

	public void isCheckboxEnabled(String field, String sectionName) {
		WebElement element = getCheckboxForField(field);
		String isDisabled = WebAction.getAttribute(element, "disabled");
		String readOnly = WebAction.getAttribute(element, "readonly");
		Assert.assertTrue(isDisabled == null && readOnly == null, "field " + field + " in section " + sectionName
				+ " is not enabled " + " in Extend or Bridge Crew & Facilities form");
	}

	public void checkCorrectRadioIsSelected(String field, String sectionName) {
		String optionSelected = getStringFromConstants(field, sectionName);
		List<WebElement> labels = getRadioLabelElements(field);
		List<WebElement> suitableElements = labels.stream()
				.filter((WebElement ele) -> getText(ele).equals(optionSelected)).toList();
		Assert.assertEquals(suitableElements.size(), 1,
				String.format("0 or more than 1 radio options with value '%s' for field %s", optionSelected, field));
		if (suitableElements.size() > 0) {
			WebElement suitableElement = suitableElements.get(0);
			String cssClasses = WebAction.getAttribute(suitableElement, "class");
			Assert.assertTrue(cssClasses.contains("ant-radio-button-wrapper"), "Element is not a radio button label");
			Assert.assertTrue(cssClasses.contains(" ant-radio-button-wrapper-checked"),
					optionSelected + " radio option is not selected for field " + field);
		}
	}

	public void selectCheckbox(String field, String section, Boolean choice) {
		WebElement ele = getCheckboxForField(field);
		scrollIntoView(ele);
		if ((choice && !ele.isSelected()) || (!choice && ele.isSelected())) {
			try {
				ele.click();
				storeInConstants(field, choice, 0, section);
			} catch (Exception e) {
				Assert.fail("Unable to click " + field + " checkbox on Extend or Bridge Crew & Facilities form");
			}
		}
	}

	public void isCheckboxSelected(String field, String section) {
		WebElement ele = getCheckboxForField(field);
		Assert.assertTrue(ele.isSelected(),
				field + " checkbox is not selected on Extend or Bridge Crew & Facilities form");
	}

	public void isCheckboxNotSelected(String field, String section) {
		WebElement ele = getCheckboxForField(field);
		Assert.assertFalse(ele.isSelected(),
				field + " checkbox is selected on Extend or Bridge Crew & Facilities form");
	}

	public void selectDate(String field, String option, Integer pos, String section) throws Exception {
		if (option.contains("currentDate+")) {
			String offset = option.substring(option.indexOf("+") + 1);
			int offsetInt = 0;
			try {
				if (offset != null) {
					offsetInt = Integer.parseInt(offset);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			LocalDate date = LocalDate.now().plusDays(offsetInt);
			String text = date.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
			fillTextbox(field, text, pos, section);
		} else {
			Assert.fail("Unable to set the field " + field + " with value " + option);
		}
	}

	/**
	 * To verify values in the extend or bridge form are present in production dashboard columns
	 * 
	 * @throws Exception
	 */
	public void verifyExtendBridgeRequestValuesWithProductionDashboardValues(String additionalRequestersText,
			String ProdDateText, String ShowProjectText, String ProductionPurposeText, String SetLocationText,
			String ControlRoomText, String SubmittedText) throws Exception {
		try {
			String requestNumber = Constants.getRequestNumber();
			String columnCellString = "//a[contains(text(),'<<RequestId>>')]/ancestor::tr/td[contains(@class,'<<ColumnType>>')]";
			producerDashboardGeneralPage.verifyStatusColorBaseOnProductionDateInDashboard(requestNumber,
					columnCellString);
			producerDashboardGeneralPage.verifyDefaultAndAdditionalRequesterInDashboard(additionalRequestersText,
					requestNumber, columnCellString);

			verifyExtendBridgeFormProdDateInDashboard(ProdDateText, requestNumber, columnCellString);

			producerDashboardGeneralPage.verifyShowProjectInDashboard(ShowProjectText, requestNumber, columnCellString);
			producerDashboardGeneralPage.verifyProductionPurposeInDashboard(ProductionPurposeText, requestNumber,
					columnCellString);
			producerDashboardGeneralPage.verifySetLocationInDashboard(SetLocationText, requestNumber, columnCellString);
			if (Constants.getControlRoomOption().equalsIgnoreCase("Yes")) {
				producerDashboardGeneralPage.verifyControlRoomInDashboard(ControlRoomText, requestNumber,
						columnCellString);
			}
			producerDashboardGeneralPage.verifySubmittedInDashboard(SubmittedText, requestNumber, columnCellString);
			producerDashboardGeneralPage.verifyActionsColumnInDashboard(requestNumber, columnCellString);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public void verifyExtendBridgeFormProdDateInDashboard(String ProdDateText, String requestNumber,
			String columnCellString) throws Exception {
		try {
			String columnTypeText;
			// To validate production date,start time,end time
			if (ProdDateText != null) {
				String[] timeStampTextArrayList;
				timeStampTextArrayList = ProdDateText.split(",");
				columnTypeText = "timestamp";
				String columnCellTypeText = columnCellString.replace("<<RequestId>>", requestNumber)
						.replace("<<ColumnType>>", columnTypeText);
				if (timeStampTextArrayList[0] != null) {
					String date = producerDashboardGeneralPage.generateDate(timeStampTextArrayList[0], "MM/dd/yy");
					String dateTextIndashboard = columnCellTypeText.concat("/span[1]");
					producerDashboardGeneralPage
							.verifyExpectedValueInFormWithActualValueInDashboard(dateTextIndashboard, date);
				}
				if (timeStampTextArrayList[1] != null) {
					String startTime = Constants.getStartTime();
					String startTimeTextIndashboard = columnCellTypeText.concat("/span[2]");
					producerDashboardGeneralPage
							.verifyExpectedValueInFormWithActualValueInDashboard(startTimeTextIndashboard, startTime);
				}
				if (timeStampTextArrayList[2] != null) {
					String endTime = Constants.getEndTime();
					String endTimeTextIndashboard = columnCellTypeText.concat("/span[3]");
					producerDashboardGeneralPage
							.verifyExpectedValueInFormWithActualValueInDashboard(endTimeTextIndashboard, endTime);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
}