package nbcu.automation.ui.stepdefs.ncxUnifiedTool;

import java.util.List;
import java.util.Map;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nbcu.automation.ui.constants.ncxUnifiedTool.Constants;
import nbcu.automation.ui.pages.ncxUnifiedTool.ProdRockCenterRequestFormPage;
import nbcu.automation.ui.pages.ncxUnifiedTool.ProducerDashboardGeneralPage;
import nbcu.automation.ui.validation.common.CommonValidations;
import nbcu.framework.utils.cucumber.CucumberUtils;
import nbcu.framework.utils.propertyfilereader.ExcelReader;

public class ProdRockCenterRequestFormPageSteps {

	ProdRockCenterRequestFormPage prodRockCenterRequestFormPage = new ProdRockCenterRequestFormPage();
	CommonValidations commonValidations = new CommonValidations();
	ProducerDashboardGeneralPage producerDashboardGeneralPage = new ProducerDashboardGeneralPage();

	@Then("Verify error message is displayed for all mandatory fields in Control Room section In Rock Center Production Form")
	public void verifyControlRoomMissingFieldErrorInProductionSection(DataTable dataTable) throws Exception {
		prodRockCenterRequestFormPage.verifyControlRoomMissingFieldError(
				CucumberUtils.getValuesFromDataTable(dataTable, "Control Room Location Error"),
				CucumberUtils.getValuesFromDataTable(dataTable, "control Room Error"));
	}

	// Rock Center Production filling form

	@When("user enters control room information in Rock Center Production form")
	public void fillControlRoomInfoInRockCenterProduction(DataTable dataTable) throws Exception {
		prodRockCenterRequestFormPage.addControlRoomInfoInRockcenter(
				CucumberUtils.getValuesFromDataTable(dataTable, "Control Room Location"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Control Room"));
	}

	@When("user enters control room crew information in Rock Center Production form")
	public void fillControlRoomCrewInfoInRockCenterProduction(DataTable dataTable) throws Exception {
		prodRockCenterRequestFormPage.selectControlRoomCrew(
				CucumberUtils.getValuesFromDataTable(dataTable, "Capture Manager"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Control Room Crew"));
	}

	@When("user enters additional crew information in Rock Center Production form")
	public void fillAdditionalCrewInfoInRockCenterProduction(DataTable dataTable) throws Exception {
		prodRockCenterRequestFormPage
				.selectAdditionalCrew(CucumberUtils.getValuesFromDataTable(dataTable, "Additional Crew"));
	}
	@When("user enters adds additional crew in Rock Center Production form")
	public void additionalCrewInfoInProductionForm(DataTable dataTable) throws Exception {
		prodRockCenterRequestFormPage
				.addtionalCrewSelection(CucumberUtils.getValuesFromDataTable(dataTable, "Additional Crew"));
	}

	@When("user enters system information in Rock Center Production form")
	public void fillSystemInfoInRockCenterProduction(DataTable dataTable) throws Exception {
		prodRockCenterRequestFormPage.addSystemInfo(CucumberUtils.getValuesFromDataTable(dataTable, "Ultimatte"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Voice Activated Prompter"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Notes"));
	}

	@When("user enters staging information in Rock Center Production form")
	public void fillStagingInfoInRockCenterProduction(DataTable dataTable) throws Exception {
		prodRockCenterRequestFormPage.addStagingInfoInRockCenter(
				CucumberUtils.getValuesFromDataTable(dataTable, "Staging"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Carpentry"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Lighting"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Props"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Describe Staging Needs"));
	}

	@Then("user verifies the form sections on Rock Center production form")
	public void verifyTheFormSectionsInRockCenterForm() {
		prodRockCenterRequestFormPage.verifyTheFormSectionsInRockCenterForm();
	}

	@Then("user verifies the fields present in {string} section of Rock Center Production form")
	public void verifyFieldsPresentOnSectionOfRockCenter(String sectionName) {
		if (sectionName != null) {
			prodRockCenterRequestFormPage.checkFieldsInSectionOfRockCenter(sectionName);
		}
	}

	@When("user selects division from the dropdown for Rock Center production form")
	public void addProducerInfoinGeneralSectionInProductionForm(DataTable dataTable) throws Exception {
		producerDashboardGeneralPage.selectDivision(CucumberUtils.getValuesFromDataTable(dataTable, "Division"));
	}

	@When("user adds talent in the talent section")
	public void addTalent(DataTable dataTable) throws InterruptedException, Exception {
		producerDashboardGeneralPage.enterTalentValue(CucumberUtils.getValuesFromDataTable(dataTable, "Talent"));
	}

	@Then("user verifies added talent is displayed in the section")
	public void verifyAdditionOfTalent(DataTable dataTable) {
		prodRockCenterRequestFormPage.verifyAdditionOfTalent(CucumberUtils.getValuesFromDataTable(dataTable, "Talent"));
	}

	@When("user provides TPMorTM information in Rock Center Production form")
	public void TPMorTMSectionDetails(DataTable dataTable) throws InterruptedException {
		prodRockCenterRequestFormPage
				.TPMorTMSectionDetails(CucumberUtils.getValuesFromDataTable(dataTable, "TPM or TM"));

	}

	@When("user enters set location information for different location in Rock Center Production form")
	public void fillSetLocationDetails(DataTable dataTable) throws Exception {
		prodRockCenterRequestFormPage.fillSetLocationDetails(
				CucumberUtils.getValuesFromDataTable(dataTable, "Location"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Set Location"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Division"));
	}

	@When("user enters control room details in Rock Center Production form")
	public void fillControlRoomDetails(DataTable dataTable) throws Exception {
		prodRockCenterRequestFormPage.fillControlRoomDetails(
				CucumberUtils.getValuesFromDataTable(dataTable, "Control Room Location"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Control Room"));
	}

	@Then("user checks the default state of is staging needed buttons")
	public void checkDefaultState() {
		prodRockCenterRequestFormPage.checkDefaultState();
	}

	@Then("user verifies presence of flashcam crew section")
	public void verifyPresenceOfFlashCamSection(DataTable dataTable) throws Exception {
		prodRockCenterRequestFormPage.verifyPresenceOfFlashCamSection(
				CucumberUtils.getValuesFromDataTable(dataTable, "Location"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Set Location"),
				CucumberUtils.getValuesFromDataTable(dataTable, "Division"));
	}

}
