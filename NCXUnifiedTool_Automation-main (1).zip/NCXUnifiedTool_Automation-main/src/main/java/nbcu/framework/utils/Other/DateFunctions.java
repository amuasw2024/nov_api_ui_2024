package nbcu.framework.utils.Other;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateFunctions {

	/**
	 * To convert date string to date
	 * 
	 * @param dateString            - date string
	 * @param inputDateStringFormat - date format of date string
	 * @return - date
	 * @throws Exception
	 */
	public static Date convertDateStringToDate(String dateString, String inputDateStringFormat) throws Exception {
		Date convertedDate = null;
		try {
			convertedDate = new SimpleDateFormat(inputDateStringFormat).parse(dateString);
		} catch (Exception e) {
			System.out.println(e);
			throw e;
		}
		return convertedDate;
	}

	/**
	 * To generate add/subtract no of days from current date
	 * 
	 * @param dateFormat - date format
	 * @param days       - no of days to add or subtract
	 * @return
	 * @throws Exception
	 */
	public static String addOrMinusDateFromCurrentDate(String dateFormat, String days) throws Exception {
		String updatedDate = "";
		try {
			SimpleDateFormat fsimpleDateFormat = new SimpleDateFormat(dateFormat);
			Date currentDate = new Date();
			Calendar calender = Calendar.getInstance();
			calender.setTime(currentDate);
			calender.add(Calendar.DATE, Integer.parseInt(days));
			updatedDate = fsimpleDateFormat.format(calender.getTime());

		} catch (Exception e) {
			System.out.println(e);
			throw e;
		}
		return updatedDate;

	}

	/**
	 * To generate add/subtract no of hours from current time
	 * 
	 * @param timeFormat - time format
	 * @param hours      - no of hours to add or subtract
	 * @return
	 * @throws Exception
	 */
	public static String addOrMinusTimeFromCurrentTime(String timeFormat, String hours) throws Exception {
		String updatedTime = "";
		try {
			SimpleDateFormat fsimpleDateFormat = new SimpleDateFormat(timeFormat);
			Date currentDate = new Date();
			Calendar calender = Calendar.getInstance();
			calender.setTime(currentDate);
			calender.add(Calendar.HOUR, Integer.parseInt(hours));
			updatedTime = fsimpleDateFormat.format(calender.getTime());

		} catch (Exception e) {
			System.out.println(e);
			throw e;
		}
		return updatedTime;

	}
}
